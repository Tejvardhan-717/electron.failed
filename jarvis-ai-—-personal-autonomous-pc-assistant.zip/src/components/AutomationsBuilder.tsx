import React, { useState } from 'react';
import { AutomationRule } from '../types';
import { Zap, Plus, Trash2, Play, ToggleLeft, ToggleRight, CornerDownRight, Check } from 'lucide-react';

interface AutomationsBuilderProps {
  automations: AutomationRule[];
  onAddAutomation: (rule: Omit<AutomationRule, 'id' | 'createdAt'>) => void;
  onToggleAutomation: (id: string) => void;
  onDeleteAutomation: (id: string) => void;
  onRunAutomation: (rule: AutomationRule) => void;
}

export const AutomationsBuilder: React.FC<AutomationsBuilderProps> = ({
  automations,
  onAddAutomation,
  onToggleAutomation,
  onDeleteAutomation,
  onRunAutomation,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [triggerPhrase, setTriggerPhrase] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [actionInput, setActionInput] = useState('');
  const [actions, setActions] = useState<
    { toolName: string; params: Record<string, any>; description: string }[]
  >([]);

  const handleAddAction = (presetDesc?: string) => {
    const text = presetDesc || actionInput.trim();
    if (!text) return;

    // Detect action intent from short phrase
    let toolName = 'open_application';
    let params: Record<string, any> = { appName: text };

    if (text.toLowerCase().startsWith('open ') || text.toLowerCase().startsWith('launch ')) {
      const app = text.replace(/^(open|launch)\s+/i, '').trim();
      toolName = 'open_application';
      params = { appName: app };
    } else if (text.toLowerCase().startsWith('close ')) {
      const app = text.replace(/^close\s+/i, '').trim();
      toolName = 'close_application';
      params = { appName: app };
    } else if (text.toLowerCase().startsWith('search ') || text.toLowerCase().includes('youtube')) {
      toolName = 'browser_search';
      params = { query: text, engine: 'youtube' };
    }

    setActions((prev) => [
      ...prev,
      {
        toolName,
        params,
        description: text,
      },
    ]);
    setActionInput('');
  };

  const handleSaveAutomation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!triggerPhrase || actions.length === 0) return;

    onAddAutomation({
      name: name.trim() || triggerPhrase.trim(),
      triggerPhrase: triggerPhrase.trim().toLowerCase(),
      description: description.trim() || `Executes ${actions.length} automated steps`,
      enabled: true,
      actions,
    });

    setTriggerPhrase('');
    setName('');
    setDescription('');
    setActions([]);
    setIsCreating(false);
  };

  return (
    <div
      id="jarvis-automations-builder"
      className="bg-[#0b0f17]/90 border border-white/10 rounded-xl p-5 backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.45)] flex flex-col h-full overflow-hidden"
    >
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-slate-100 font-mono tracking-wide">
              CUSTOM VOICE AUTOMATIONS
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Chain multi-application routines triggered by custom speech commands.
          </p>
        </div>

        {!isCreating && (
          <button
            onClick={() => setIsCreating(true)}
            className="px-3 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" /> New Routine
          </button>
        )}
      </div>

      {isCreating ? (
        <form onSubmit={handleSaveAutomation} className="space-y-4 overflow-y-auto flex-1 pr-1">
          <div className="p-3.5 rounded-xl bg-[#070a10] border border-white/10 space-y-3">
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                WHEN I SAY (VOICE TRIGGER PHRASE):
              </label>
              <input
                type="text"
                placeholder='e.g. "Gaming Mode", "Start Work", "Night Routine"'
                value={triggerPhrase}
                onChange={(e) => setTriggerPhrase(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg bg-[#0c1322] border border-white/10 text-slate-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                ROUTINE NAME:
              </label>
              <input
                type="text"
                placeholder='e.g. "Launch Gaming Suite"'
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0c1322] border border-white/10 text-slate-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Actions list */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1">
                DO STEPS (IN SEQUENCE):
              </label>
              <div className="space-y-1.5 mb-2">
                {actions.map((act, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2 rounded-lg bg-[#0c1322] border border-white/5 text-xs font-mono text-slate-200"
                  >
                    <div className="flex items-center gap-2">
                      <CornerDownRight className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{act.description}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActions((prev) => prev.filter((_, i) => i !== idx))}
                      className="text-slate-500 hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add action input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder='e.g. "Open Discord", "Open Steam", "Open Spotify"'
                  value={actionInput}
                  onChange={(e) => setActionInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddAction();
                    }
                  }}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#0c1322] border border-white/10 text-slate-100 font-mono text-xs focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="button"
                  onClick={() => handleAddAction()}
                  className="px-3 py-1.5 rounded-lg bg-[#121a28] hover:bg-[#1a2538] text-slate-200 font-mono text-xs border border-white/5"
                >
                  Add Step
                </button>
              </div>

              {/* Quick presets */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap text-[10px] font-mono text-slate-400">
                <span>Quick add:</span>
                {['Open Discord', 'Open Steam', 'Open VS Code', 'Open Chrome', 'Open Spotify'].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleAddAction(preset)}
                    className="px-1.5 py-0.5 rounded bg-cyan-950/40 border border-cyan-500/20 text-cyan-300 hover:bg-cyan-900/50"
                  >
                    + {preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 rounded-lg bg-[#121a28] hover:bg-[#1a2538] text-slate-300 font-mono text-xs border border-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actions.length === 0}
              className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold disabled:opacity-50 shadow-md shadow-cyan-600/30"
            >
              Save Automation Routine
            </button>
          </div>
        </form>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
          {automations.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center h-48 text-slate-500 text-xs font-mono">
              <Zap className="w-8 h-8 mb-2 opacity-30" />
              <span>No custom automations configured yet.</span>
              <p className="text-[11px] text-slate-600 mt-1 max-w-xs">
                Create one like &ldquo;Gaming Mode&rdquo; to launch Discord, Steam, and Spotify in a single voice command.
              </p>
            </div>
          ) : (
            (automations || []).map((rule) => (
              <div
                key={rule.id}
                className="p-3.5 rounded-xl bg-[#070a10]/80 border border-white/5 hover:border-cyan-500/20 transition-all font-mono"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-100">{rule.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-semibold">
                        &ldquo;Hey Jarvis, {rule.triggerPhrase}&rdquo;
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{rule.description}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onRunAutomation(rule)}
                      title="Test run routine now"
                      className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/40 transition-colors"
                    >
                      <Play className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onToggleAutomation(rule.id)}
                      title={rule.enabled ? 'Disable routine' : 'Enable routine'}
                      className="text-slate-400 hover:text-slate-200"
                    >
                      {rule.enabled ? (
                        <ToggleRight className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <ToggleLeft className="w-5 h-5 text-slate-600" />
                      )}
                    </button>
                    <button
                      onClick={() => onDeleteAutomation(rule.id)}
                      title="Delete routine"
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Steps summary */}
                <div className="mt-3 pt-2.5 border-t border-white/5 space-y-1">
                  {(rule.actions || []).map((act, i) => (
                    <div key={i} className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="text-cyan-400">{i + 1}.</span>
                      <span>{act.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
