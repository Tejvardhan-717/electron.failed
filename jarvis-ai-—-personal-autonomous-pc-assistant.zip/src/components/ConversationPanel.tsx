import React, { useState } from 'react';
import { ActivityLogItem, AccentColor } from '../types';
import {
  MessageSquare,
  X,
  Trash2,
  Terminal,
  CornerDownRight,
  Sparkles,
  User,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';

interface ConversationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  logs: ActivityLogItem[];
  onClearLogs?: () => void;
  onExecuteCommand?: (cmd: string) => void;
  onUndoItem?: (undoId: string) => void;
  accentColor?: AccentColor;
}

export const ConversationPanel: React.FC<ConversationPanelProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs,
  onExecuteCommand,
  onUndoItem,
  accentColor = 'blue',
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const logList = Array.isArray(logs) ? logs : [];
  const filtered = logList.filter(
    (l) =>
      l.userCommand?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.assistantResponse?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <aside
      id="jarvis-conversation-panel"
      className="fixed inset-y-0 left-0 w-80 sm:w-96 z-40 bg-[#060a12]/90 backdrop-blur-xl border-r border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.8)] flex flex-col transition-all duration-300 animate-in slide-in-from-left"
    >
      {/* Top Header */}
      <div className="h-14 px-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#070d18]/60">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <MessageSquare className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="text-xs font-mono font-bold tracking-wider text-slate-100 uppercase">
              DIALOGUE STREAM
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              {logList.length} interactions logged
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {onClearLogs && logList.length > 0 && (
            <button
              onClick={onClearLogs}
              title="Clear transcript history"
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onClose}
            title="Close conversation panel"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-3 border-b border-white/10 bg-[#050811]/40">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0a1020] border border-white/10 text-xs font-mono text-slate-300">
          <Terminal className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <input
            type="text"
            placeholder="Search transcripts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent focus:outline-none placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Dialogue Message Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center h-48 text-slate-500 text-xs font-mono px-4">
            <Sparkles className="w-6 h-6 text-slate-600 mb-2" />
            <p>No dialogue recorded yet.</p>
            <p className="text-[11px] text-slate-600 mt-1">
              Speak or enter a command to initiate conversation with JARVIS.
            </p>
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="p-3 rounded-xl bg-[#090e1c]/80 border border-white/10 hover:border-cyan-500/30 transition-all space-y-2 group"
            >
              {/* User Command Line */}
              {item.userCommand && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span className="flex items-center gap-1.5 text-cyan-300 font-bold">
                      <User className="w-3 h-3 text-cyan-400" />
                      USER
                    </span>
                    <span className="flex items-center gap-1 text-slate-500">
                      <Clock className="w-2.5 h-2.5" />
                      {item.timestamp}
                    </span>
                  </div>
                  <div className="text-xs font-sans text-slate-200 pl-4 border-l border-cyan-500/30 py-0.5">
                    "{item.userCommand}"
                  </div>
                </div>
              )}

              {/* JARVIS Spoken / Executed Outcome */}
              <div className="space-y-1 pt-1">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="flex items-center gap-1.5 text-slate-400 font-semibold">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    JARVIS
                  </span>
                  {item.status === 'success' ? (
                    <span className="flex items-center gap-1 text-[9px] text-emerald-400 font-mono">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      VERIFIED
                    </span>
                  ) : item.status === 'error' ? (
                    <span className="flex items-center gap-1 text-[9px] text-rose-400 font-mono">
                      <AlertTriangle className="w-2.5 h-2.5" />
                      FAILED
                    </span>
                  ) : null}
                </div>
                <div className="text-xs font-sans text-slate-300 pl-4 border-l border-slate-700 py-0.5 leading-relaxed">
                  {item.assistantResponse || item.details}
                </div>
              </div>

              {/* Tool badge & Re-run action */}
              <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[10px] font-mono">
                {item.toolName ? (
                  <span className="text-[10px] text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                    {item.toolName}()
                  </span>
                ) : (
                  <span />
                )}

                <div className="flex items-center gap-2">
                  {item.reversible && item.undoId && onUndoItem && (
                    <button
                      onClick={() => onUndoItem(item.undoId!)}
                      className="text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
                    >
                      <RotateCcw className="w-3 h-3" />
                      Undo
                    </button>
                  )}
                  {onExecuteCommand && item.userCommand && (
                    <button
                      onClick={() => onExecuteCommand(item.userCommand!)}
                      title="Re-run command"
                      className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity"
                    >
                      <CornerDownRight className="w-3 h-3" />
                      Re-run
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-white/10 bg-[#070d18]/40 text-center">
        <span className="text-[10px] font-mono text-slate-500">
          Press <kbd className="text-cyan-400">Esc</kbd> to close panel
        </span>
      </div>
    </aside>
  );
};
