import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowDown,
  Volume2,
  CheckCircle2,
  Code2,
  FileText,
  Radio,
  Play,
  RotateCcw,
  Layers,
  Bot,
  Scissors,
  Check,
  Globe,
  ShieldAlert,
} from 'lucide-react';
import { voiceService } from '../services/voiceService';
import {
  runTtsPipeline,
  preprocessTtsSpeechText,
  userExplicitlyRequestedUrl,
  TtsPipelineStageResult,
  PipelineProgressEvent,
} from '../services/ttsPipeline';

interface TtsPipelineVisualizerProps {
  currentVoiceName?: string;
  speechSpeed?: number;
  speechPitch?: number;
}

const SAMPLE_PRESETS = [
  {
    label: 'YouTube Short URL',
    prompt: `Sure. You can watch it here:\nhttps://youtube.com/shorts/123456789`,
    userCommand: 'Show me that video',
  },
  {
    label: 'Open Website / Links',
    prompt: `I have navigated to https://github.com/trending and opened https://google.com. You can check the repository [Project Core](https://github.com/project/core).`,
    userCommand: 'Open GitHub trending',
  },
  {
    label: 'Explicit URL Command',
    prompt: `The target link is https://youtube.com/shorts/123456789.`,
    userCommand: 'Jarvis, read the URL',
  },
  {
    label: 'Technical Code & Stats',
    prompt: `Task finished. CPU at 42C with 15% load. Executed \`node server.ts\` with token sk-9283819283719827391827391. Available at https://example.com/docs`,
    userCommand: 'Check status',
  },
];

export const TtsPipelineVisualizer: React.FC<TtsPipelineVisualizerProps> = ({
  currentVoiceName,
  speechSpeed = 1.0,
  speechPitch = 0.92,
}) => {
  const [inputText, setInputText] = useState(SAMPLE_PRESETS[0].prompt);
  const [simulatedCommand, setSimulatedCommand] = useState(SAMPLE_PRESETS[0].userCommand);
  const [pipelineResult, setPipelineResult] = useState<TtsPipelineStageResult>(() =>
    runTtsPipeline(SAMPLE_PRESETS[0].prompt, { userCommand: SAMPLE_PRESETS[0].userCommand })
  );
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeStage, setActiveStage] = useState<PipelineProgressEvent['stage']>('IDLE');
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(0);
  const [activeSentence, setActiveSentence] = useState('');

  // Re-run pipeline calculation on input text or simulated command change
  useEffect(() => {
    const result = runTtsPipeline(inputText, { userCommand: simulatedCommand });
    setPipelineResult(result);
  }, [inputText, simulatedCommand]);

  // Subscribe to voiceService pipeline events
  useEffect(() => {
    const handleProgress = (event: PipelineProgressEvent) => {
      setActiveStage(event.stage);
      setCurrentSentenceIndex(event.currentSentenceIndex);
      setActiveSentence(event.activeSentence);
      if (event.stage === 'IDLE') {
        setIsPlaying(false);
      }
    };

    voiceService.onPipelineProgress(handleProgress);
  }, []);

  const handlePlayPipeline = async () => {
    if (isPlaying) {
      voiceService.stopSpeaking();
      setIsPlaying(false);
      setActiveStage('IDLE');
      return;
    }

    setIsPlaying(true);
    await voiceService.speak(inputText, {
      voiceName: currentVoiceName,
      rate: speechSpeed,
      pitch: speechPitch,
      userCommand: simulatedCommand,
      onSentenceStart: (sentence, index) => {
        setCurrentSentenceIndex(index);
        setActiveSentence(sentence);
      },
      onEnd: () => {
        setIsPlaying(false);
        setActiveStage('IDLE');
      },
    });
  };

  const isExplicitUrlAllowed = userExplicitlyRequestedUrl(simulatedCommand);

  return (
    <div className="p-4 rounded-xl bg-slate-950/90 border border-cyan-500/30 text-slate-200 space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h4 className="text-xs font-mono font-bold text-cyan-300 tracking-wider uppercase">
            TTS PREPROCESSOR & URL SANITIZER PIPELINE
          </h4>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
            RAW URL READING BLOCKED
          </span>
        </div>
      </div>

      <p className="text-[11px] text-slate-300 leading-relaxed">
        Guarantees that complete website URLs are <strong>never</strong> spelled aloud
        (e.g., prevents <em>"https colon slash slash www dot..."</em>). Spoken output is stripped and rewritten into natural cadence while the visual chat UI preserves the full, unaltered URL.
      </p>

      {/* Preset Quick Tests */}
      <div className="space-y-1.5">
        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
          Quick Test Scenarios:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {SAMPLE_PRESETS.map((preset, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setInputText(preset.prompt);
                setSimulatedCommand(preset.userCommand);
              }}
              className={`text-[10px] font-mono px-2.5 py-1 rounded-md border transition-all ${
                inputText === preset.prompt
                  ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-bold'
                  : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:border-slate-500'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Inputs: Simulated User Command & Raw AI Response */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        <div className="space-y-1">
          <label className="text-[10px] font-mono text-slate-400 flex items-center justify-between">
            <span>Simulated User Command:</span>
            {isExplicitUrlAllowed ? (
              <span className="text-amber-400 font-bold flex items-center gap-1 text-[9px]">
                <ShieldAlert className="w-3 h-3" /> EXPLICIT URL REQUEST
              </span>
            ) : (
              <span className="text-emerald-400 text-[9px]">URLs Stripped</span>
            )}
          </label>
          <input
            type="text"
            value={simulatedCommand}
            onChange={(e) => setSimulatedCommand(e.target.value)}
            className="w-full text-xs font-mono p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-cyan-400"
            placeholder="e.g. Show me that video (or 'Jarvis, read the URL')"
          />
        </div>

        <div className="space-y-1">
          <label className="text-[10px] font-mono text-slate-400">
            Raw AI Response (Kept in Visual UI):
          </label>
          <textarea
            rows={2}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="w-full text-xs font-mono p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-cyan-400"
            placeholder="AI text containing URLs, Markdown, code, or technical identifiers..."
          />
        </div>
      </div>

      {/* Pipeline Flow Stages Diagram:
          AI RESPONSE → TTS PREPROCESSOR → CLEAN SPEECH TEXT → TTS ENGINE */}
      <div className="space-y-2 pt-1">
        {/* Stage 1: AI RESPONSE */}
        <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900/70 border border-slate-800">
          <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-[10px] font-bold text-cyan-300 shrink-0 mt-0.5">
            1
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-300 font-mono">AI RESPONSE</span>
              <span className="text-[9px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded">
                VISUAL UI PRESERVES COMPLETE TEXT & URL
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate mt-0.5 font-mono">
              {inputText || '(Empty)'}
            </p>
          </div>
        </div>

        <div className="flex justify-center text-cyan-500/60 -my-1">
          <ArrowDown className="w-3.5 h-3.5" />
        </div>

        {/* Stage 2: TTS PREPROCESSOR */}
        <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900/70 border border-indigo-500/30">
          <div className="w-6 h-6 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-[10px] font-bold text-indigo-300 shrink-0 mt-0.5">
            2
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-300 font-mono">TTS PREPROCESSOR</span>
              <div className="flex items-center gap-2 text-[10px] font-mono">
                <span className="text-emerald-400">
                  {pipelineResult.metrics.urlsRemoved} URLs Sanitized
                </span>
                <span className="text-sky-400">
                  {pipelineResult.metrics.codeBlocksRemoved} Code Stripped
                </span>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 font-mono mt-0.5">
              • Removes raw URLs • Converts website names • Preserves visible link text • Removes HTML/Code/API keys • Normalizes punctuation
            </p>
          </div>
        </div>

        <div className="flex justify-center text-cyan-500/60 -my-1">
          <ArrowDown className="w-3.5 h-3.5" />
        </div>

        {/* Stage 3: CLEAN SPEECH TEXT */}
        <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-900/70 border border-emerald-500/30">
          <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-[10px] font-bold text-emerald-300 shrink-0 mt-0.5">
            3
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 font-mono">CLEAN SPEECH TEXT</span>
              <span className="text-[10px] font-mono text-emerald-400">
                {pipelineResult.sentences.length} Natural Sentence Units
              </span>
            </div>
            <div className="text-xs font-sans text-emerald-200 mt-1 p-2 rounded bg-emerald-950/20 border border-emerald-500/20 font-medium">
              "{pipelineResult.cleanedText}"
            </div>
          </div>
        </div>

        <div className="flex justify-center text-cyan-500/60 -my-1">
          <ArrowDown className="w-3.5 h-3.5" />
        </div>

        {/* Stage 4: TTS ENGINE & VOICE */}
        <div className="flex items-start gap-3 p-2.5 rounded-lg bg-gradient-to-r from-slate-950 via-cyan-950/30 to-slate-950 border border-cyan-500/40">
          <div className="w-6 h-6 rounded-full bg-cyan-500/30 border border-cyan-400 flex items-center justify-center text-[10px] font-bold text-cyan-300 shrink-0 mt-0.5">
            4
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-cyan-300 font-mono">TTS ENGINE</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                  Paul Bettany Voice
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                ~{pipelineResult.metrics.estimatedDurationSec}s cadence
              </span>
            </div>

            {isPlaying && (
              <div className="mt-2 p-2 rounded bg-cyan-950/70 border border-cyan-500/40 flex items-center gap-2 text-xs font-mono text-cyan-200">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping shrink-0" />
                <span className="truncate">
                  Speaking ({currentSentenceIndex + 1}/{pipelineResult.sentences.length}): "{activeSentence}"
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Action Play Button */}
      <div className="pt-1 flex items-center justify-between">
        <div className="text-[10px] font-mono text-slate-400">
          Spoken Output: <span className="text-slate-200">"{pipelineResult.cleanedText}"</span>
        </div>

        <button
          type="button"
          onClick={handlePlayPipeline}
          className={`px-4 py-2 rounded-lg font-mono font-bold text-xs flex items-center gap-2 transition-all shadow-md ${
            isPlaying
              ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-500/20'
              : 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-white shadow-cyan-500/20'
          }`}
        >
          {isPlaying ? (
            <>
              <Radio className="w-3.5 h-3.5 animate-pulse" />
              Stop Spoken Test
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              Test Clean Spoken Output
            </>
          )}
        </button>
      </div>
    </div>
  );
};
