import path from 'path';
import os from 'os';

export type ToolCategory =
  | 'system'
  | 'filesystem'
  | 'automation'
  | 'browser'
  | 'telemetry'
  | 'software'
  | 'power';

export type RiskLevel = 0 | 1 | 2 | 3 | 4;

export interface ToolParameterSchema {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  required: boolean;
  description: string;
  defaultValue?: any;
  allowedValues?: string[];
  pattern?: RegExp | string;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  sanitizePath?: boolean;
}

export interface ToolDefinition {
  name: string;
  category: ToolCategory;
  description: string;
  riskLevel: RiskLevel;
  requiresAdmin?: boolean;
  isDestructive?: boolean;
  undoSupported?: boolean;
  parameters: ToolParameterSchema[];
  customValidator?: (args: Record<string, any>) => { valid: boolean; errors: string[] };
}

export interface ValidationResult {
  valid: boolean;
  sanitizedArgs: Record<string, any>;
  errors: string[];
  warnings?: string[];
  tool?: ToolDefinition;
}

/**
 * Path Sanitizer & Guard
 * Protects against Directory Traversal attacks, resolves environment placeholders,
 * and guards sensitive operating system directories.
 */
export class PathSanitizer {
  private static readonly FORBIDDEN_WINDOWS_PATHS = [
    /^[a-z]:\\windows\\system32\\config/i,
    /^[a-z]:\\windows\\system32\\drivers\\etc\\hosts/i,
    /^[a-z]:\\pagefile\.sys/i,
    /^[a-z]:\\hiberfil\.sys/i,
    /^[a-z]:\\windows\\boot/i,
  ];

  private static readonly FORBIDDEN_UNIX_PATHS = [
    /^\/etc\/shadow/i,
    /^\/etc\/passwd/i,
    /^\/boot/i,
    /^\/dev/i,
    /^\/proc/i,
    /^\/sys/i,
  ];

  /**
   * Resolves environment variables and user shortcuts in path strings
   */
  public static resolvePlaceholders(inputPath: string): string {
    if (!inputPath || typeof inputPath !== 'string') return '';

    let resolved = inputPath.trim();
    const isWindows = process.platform === 'win32';
    const homeDir = os.homedir();
    const tempDir = os.tmpdir();
    const desktopDir = path.join(homeDir, 'Desktop');

    // Replace common user and system shorthands
    resolved = resolved
      .replace(/%USERPROFILE%/gi, homeDir)
      .replace(/%DESKTOP%/gi, desktopDir)
      .replace(/%TEMP%/gi, tempDir)
      .replace(/%TMP%/gi, tempDir)
      .replace(/%APPDATA%/gi, path.join(homeDir, 'AppData', 'Roaming'))
      .replace(/%LOCALAPPDATA%/gi, path.join(homeDir, 'AppData', 'Local'));

    if (resolved.startsWith('~/') || resolved === '~') {
      resolved = path.join(homeDir, resolved.slice(1));
    }

    // Handle relative "Desktop/Folder" format
    if (resolved.toLowerCase().startsWith('desktop/') || resolved.toLowerCase().startsWith('desktop\\')) {
      resolved = path.join(desktopDir, resolved.slice(8));
    }

    return resolved;
  }

  /**
   * Sanitizes a file path, checks for directory traversal, and blocks protected system files
   */
  public static sanitize(inputPath: string, options: { allowSystemPaths?: boolean } = {}): {
    valid: boolean;
    sanitizedPath: string;
    error?: string;
  } {
    if (!inputPath || typeof inputPath !== 'string') {
      return { valid: false, sanitizedPath: '', error: 'Path argument must be a non-empty string.' };
    }

    const resolved = this.resolvePlaceholders(inputPath);

    // Detect path traversal attacks (e.g., ../../../ or ..\..\..)
    // Checking both raw input and normalized path
    const hasTraversalSequence = /(?:^|[/\\])\.\.(?:[/\\]|$)/.test(inputPath);
    if (hasTraversalSequence && !path.isAbsolute(resolved)) {
      return {
        valid: false,
        sanitizedPath: '',
        error: `Security Violation: Directory traversal detected ("..") in path "${inputPath}".`,
      };
    }

    // Normalize path
    const normalized = path.normalize(resolved);

    // Check against forbidden operating system locations
    if (!options.allowSystemPaths) {
      for (const pattern of this.FORBIDDEN_WINDOWS_PATHS) {
        if (pattern.test(normalized)) {
          return {
            valid: false,
            sanitizedPath: normalized,
            error: `Access Denied: Path "${normalized}" targets a protected Windows operating system directory.`,
          };
        }
      }

      for (const pattern of this.FORBIDDEN_UNIX_PATHS) {
        if (pattern.test(normalized)) {
          return {
            valid: false,
            sanitizedPath: normalized,
            error: `Access Denied: Path "${normalized}" targets a protected system directory.`,
          };
        }
      }
    }

    return { valid: true, sanitizedPath: normalized };
  }
}

/**
 * JARVIS Central Tool Registry
 * Single source of truth for all tools, parameter schemas, risk levels, and validation logic.
 */
export class ToolRegistry {
  private static registry: Map<string, ToolDefinition> = new Map();

  static {
    this.initializeDefaultTools();
  }

  private static initializeDefaultTools() {
    // -------------------------------------------------------------
    // 1. APPLICATION & WINDOW MANAGEMENT
    // -------------------------------------------------------------
    this.register({
      name: 'open_application',
      category: 'system',
      description: 'Launches an application executable on Windows and verifies active process creation.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'application',
          type: 'string',
          required: true,
          description: 'Name or executable of the target application (e.g., "notepad", "chrome", "calc", "code").',
          minLength: 1,
          maxLength: 100,
        },
        {
          name: 'args',
          type: 'array',
          required: false,
          description: 'Optional command line arguments to pass to the application.',
        },
      ],
    });

    this.register({
      name: 'close_application',
      category: 'system',
      description: 'Terminates running process instances of an application and verifies removal from Windows process table.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'application',
          type: 'string',
          required: true,
          description: 'Name or executable of the application to terminate (e.g., "notepad", "chrome").',
          minLength: 1,
          maxLength: 100,
        },
        {
          name: 'force',
          type: 'boolean',
          required: false,
          description: 'Force immediate termination (/F flag) without waiting for graceful shutdown.',
          defaultValue: true,
        },
      ],
    });

    this.register({
      name: 'restart_application',
      category: 'system',
      description: 'Gracefully closes and restarts an application, verifying both termination and relaunch.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'application',
          type: 'string',
          required: true,
          description: 'Application executable or identifier to restart.',
          minLength: 1,
          maxLength: 100,
        },
      ],
    });

    // -------------------------------------------------------------
    // 2. FILESYSTEM OPERATIONS
    // -------------------------------------------------------------
    this.register({
      name: 'create_folder',
      category: 'filesystem',
      description: 'Creates a new directory on disk, ensuring parent paths exist, and verifies filesystem creation.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: true,
      parameters: [
        {
          name: 'path',
          type: 'string',
          required: true,
          description: 'Target directory path (e.g. "Desktop/JarvisTest" or "C:\\Users\\User\\Projects").',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'folderName',
          type: 'string',
          required: false,
          description: 'Optional base folder name if path is a parent directory.',
          maxLength: 100,
        },
      ],
    });

    this.register({
      name: 'delete_file',
      category: 'filesystem',
      description: 'Permanently deletes a file or directory. Requires user authorization under Level 2/3 protection.',
      riskLevel: 2,
      requiresAdmin: false,
      isDestructive: true,
      undoSupported: false,
      parameters: [
        {
          name: 'path',
          type: 'string',
          required: true,
          description: 'File or directory path to remove permanently.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'recursive',
          type: 'boolean',
          required: false,
          description: 'Whether to recursively delete contents if path is a directory.',
          defaultValue: true,
        },
      ],
    });

    this.register({
      name: 'move_file',
      category: 'filesystem',
      description: 'Moves or renames a file or folder from source to destination path with verification.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: true,
      parameters: [
        {
          name: 'source',
          type: 'string',
          required: true,
          description: 'Source file or directory path.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'destination',
          type: 'string',
          required: true,
          description: 'Destination file or directory path.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
      ],
    });

    this.register({
      name: 'copy_file',
      category: 'filesystem',
      description: 'Copies a file or folder to a new destination, preserving metadata where possible.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: true,
      parameters: [
        {
          name: 'source',
          type: 'string',
          required: true,
          description: 'Source file or directory path.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'destination',
          type: 'string',
          required: true,
          description: 'Destination file or directory path.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
      ],
    });

    this.register({
      name: 'read_file',
      category: 'filesystem',
      description: 'Reads text contents of a file on disk (up to 50KB) with encoding verification.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'path',
          type: 'string',
          required: true,
          description: 'Absolute or relative path to the file to read.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'maxBytes',
          type: 'number',
          required: false,
          description: 'Maximum bytes to read (default: 51200 / 50KB).',
          min: 1,
          max: 1048576,
          defaultValue: 51200,
        },
      ],
    });

    this.register({
      name: 'write_file',
      category: 'filesystem',
      description: 'Writes or appends text content to a file on disk with verification.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: true,
      parameters: [
        {
          name: 'path',
          type: 'string',
          required: true,
          description: 'Destination file path.',
          minLength: 1,
          maxLength: 260,
          sanitizePath: true,
        },
        {
          name: 'content',
          type: 'string',
          required: true,
          description: 'Text content to write into the file.',
          maxLength: 1000000,
        },
        {
          name: 'append',
          type: 'boolean',
          required: false,
          description: 'Whether to append to existing file instead of overwriting.',
          defaultValue: false,
        },
      ],
    });

    this.register({
      name: 'list_directory',
      category: 'filesystem',
      description: 'Lists files, folders, sizes, and timestamps within a target directory.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'path',
          type: 'string',
          required: false,
          description: 'Directory path to list (defaults to Desktop or current workspace).',
          defaultValue: 'Desktop',
          sanitizePath: true,
        },
        {
          name: 'maxResults',
          type: 'number',
          required: false,
          description: 'Maximum items to return in directory listing.',
          min: 1,
          max: 500,
          defaultValue: 100,
        },
      ],
    });

    this.register({
      name: 'search_files',
      category: 'filesystem',
      description: 'Recursively searches the filesystem for matching file names, patterns, or extensions.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'query',
          type: 'string',
          required: true,
          description: 'File name, keyword, or glob pattern to search (e.g. "report.docx", "*.pdf", "JarvisTest").',
          minLength: 1,
          maxLength: 100,
        },
        {
          name: 'folder',
          type: 'string',
          required: false,
          description: 'Starting folder location for the search (defaults to user Desktop and Documents).',
          sanitizePath: true,
        },
        {
          name: 'maxResults',
          type: 'number',
          required: false,
          description: 'Maximum matching files to return.',
          min: 1,
          max: 100,
          defaultValue: 20,
        },
      ],
    });

    // -------------------------------------------------------------
    // 3. UI AUTOMATION & KEYSTROKES
    // -------------------------------------------------------------
    this.register({
      name: 'type_text',
      category: 'automation',
      description: 'Simulates typing keystrokes into the currently focused window on the operating system.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'text',
          type: 'string',
          required: true,
          description: 'Text string to type into the active window (e.g. "hello world").',
          minLength: 1,
          maxLength: 5000,
        },
        {
          name: 'sendEnter',
          type: 'boolean',
          required: false,
          description: 'Whether to press Enter after typing the text.',
          defaultValue: false,
        },
      ],
    });

    this.register({
      name: 'take_screenshot',
      category: 'automation',
      description: 'Captures the active primary or virtual screen display frame and saves it to disk.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'savePath',
          type: 'string',
          required: false,
          description: 'Optional destination file path for the screenshot image (.png).',
          sanitizePath: true,
        },
      ],
    });

    // -------------------------------------------------------------
    // 4. BROWSER INTEGRATION
    // -------------------------------------------------------------
    this.register({
      name: 'open_url',
      category: 'browser',
      description: 'Opens a web URL safely in the default system browser (Chrome, Edge, Firefox).',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'url',
          type: 'string',
          required: true,
          description: 'Target web address (must start with http:// or https://).',
          minLength: 4,
          maxLength: 2048,
          pattern: /^https?:\/\/.+/i,
        },
      ],
      customValidator: (args) => {
        const urlStr = String(args.url || '').trim();
        try {
          const parsed = new URL(urlStr);
          if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
            return { valid: false, errors: ['URL protocol must be http: or https:'] };
          }
          return { valid: true, errors: [] };
        } catch {
          return { valid: false, errors: [`Invalid web URL format: "${urlStr}"`] };
        }
      },
    });

    // -------------------------------------------------------------
    // 5. SYSTEM HARDWARE & TELEMETRY
    // -------------------------------------------------------------
    this.register({
      name: 'get_system_information',
      category: 'telemetry',
      description: 'Queries real-time CPU utilization, RAM allocation, GPU metrics, disk space, and battery state.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [],
    });

    this.register({
      name: 'get_running_processes',
      category: 'telemetry',
      description: 'Retrieves active Windows process table with PID, process name, and memory consumption.',
      riskLevel: 0,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'filter',
          type: 'string',
          required: false,
          description: 'Optional process name filter (e.g. "chrome", "node").',
        },
        {
          name: 'limit',
          type: 'number',
          required: false,
          description: 'Maximum number of processes to return (default: 30).',
          min: 1,
          max: 200,
          defaultValue: 30,
        },
      ],
    });

    // -------------------------------------------------------------
    // 6. SOFTWARE & POWERSHELL EXECUTION
    // -------------------------------------------------------------
    this.register({
      name: 'install_application',
      category: 'software',
      description: 'Installs or updates software packages using Windows Package Manager (winget). Requires confirmation.',
      riskLevel: 2,
      requiresAdmin: true,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'package',
          type: 'string',
          required: true,
          description: 'Package identifier or application name in winget (e.g., "Git.Git", "Mozilla.Firefox").',
          minLength: 2,
          maxLength: 100,
        },
      ],
    });

    this.register({
      name: 'run_powershell',
      category: 'system',
      description: 'Executes a vetted PowerShell instruction under Level 2/3 safety controls with strict command blacklisting.',
      riskLevel: 2,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [
        {
          name: 'command',
          type: 'string',
          required: true,
          description: 'PowerShell command or script string to evaluate.',
          minLength: 1,
          maxLength: 2000,
        },
      ],
      customValidator: (args) => {
        const cmd = String(args.command || '');
        const banned = [
          /format\s+[c-z]:/i,
          /rmdir\s+\/s\s+\/q\s+c:\\windows/i,
          /Remove-Item\s+-Recurse\s+C:\\Windows/i,
          /disable\s+antivirus/i,
          /set-mppreference\s+-disablerealtimemonitoring\s+\$true/i,
          /mimikatz/i,
        ];
        for (const pattern of banned) {
          if (pattern.test(cmd)) {
            return {
              valid: false,
              errors: ['Security Violation: Command contains critical prohibited security directives (Level 4).'],
            };
          }
        }
        return { valid: true, errors: [] };
      },
    });

    this.register({
      name: 'lock_pc',
      category: 'power',
      description: 'Safely locks the Windows user workstation.',
      riskLevel: 1,
      requiresAdmin: false,
      isDestructive: false,
      undoSupported: false,
      parameters: [],
    });
  }

  /**
   * Registers a tool definition into the registry
   */
  public static register(tool: ToolDefinition): void {
    this.registry.set(tool.name, tool);
  }

  /**
   * Retrieves a tool definition by name
   */
  public static getTool(name: string): ToolDefinition | undefined {
    return this.registry.get(name);
  }

  /**
   * Lists all registered tools
   */
  public static getAllTools(): ToolDefinition[] {
    return Array.from(this.registry.values());
  }

  /**
   * Lists tools filtered by category
   */
  public static getToolsByCategory(category: ToolCategory): ToolDefinition[] {
    return this.getAllTools().filter((t) => t.category === category);
  }

  /**
   * Validates tool call arguments strictly against registered parameter schemas.
   * Performs type coercion, path sanitization, boundary checks, and custom rules.
   */
  public static validateToolCall(toolName: string, rawArgs: Record<string, any> = {}): ValidationResult {
    const tool = this.getTool(toolName);
    if (!tool) {
      return {
        valid: false,
        sanitizedArgs: {},
        errors: [`Tool "${toolName}" is not registered in the JARVIS Tool Registry.`],
      };
    }

    const errors: string[] = [];
    const warnings: string[] = [];
    const sanitized: Record<string, any> = {};

    // 1. Process each parameter schema
    for (const param of tool.parameters) {
      let val = rawArgs[param.name];

      // Handle common aliases (e.g. appName -> application, folderName -> path)
      if (val === undefined) {
        if (param.name === 'application') {
          val = rawArgs.appName || rawArgs.name;
        } else if (param.name === 'path') {
          val = rawArgs.folderPath || rawArgs.filePath || rawArgs.targetPath;
        }
      }

      // Check required
      if (val === undefined || val === null || val === '') {
        if (param.required) {
          errors.push(`Missing required parameter: "${param.name}".`);
          continue;
        } else {
          // Assign default value if defined
          if (param.defaultValue !== undefined) {
            sanitized[param.name] = param.defaultValue;
          }
          continue;
        }
      }

      // Type checking & sanitization
      switch (param.type) {
        case 'string': {
          if (typeof val !== 'string') {
            val = String(val);
          }
          const trimmed = val.trim();

          if (param.minLength !== undefined && trimmed.length < param.minLength) {
            errors.push(`Parameter "${param.name}" must be at least ${param.minLength} characters.`);
          }
          if (param.maxLength !== undefined && trimmed.length > param.maxLength) {
            errors.push(`Parameter "${param.name}" exceeds maximum length of ${param.maxLength} characters.`);
          }
          if (param.pattern) {
            const regex = typeof param.pattern === 'string' ? new RegExp(param.pattern) : param.pattern;
            if (!regex.test(trimmed)) {
              errors.push(`Parameter "${param.name}" does not match required format pattern.`);
            }
          }
          if (param.allowedValues && !param.allowedValues.includes(trimmed)) {
            errors.push(
              `Parameter "${param.name}" must be one of: ${param.allowedValues.join(', ')}. Got: "${trimmed}".`
            );
          }

          // Path sanitization if flag enabled
          if (param.sanitizePath) {
            const pathCheck = PathSanitizer.sanitize(trimmed);
            if (!pathCheck.valid) {
              errors.push(`Parameter "${param.name}" path validation failed: ${pathCheck.error}`);
            } else {
              sanitized[param.name] = pathCheck.sanitizedPath;
            }
          } else {
            sanitized[param.name] = trimmed;
          }
          break;
        }

        case 'number': {
          const num = Number(val);
          if (isNaN(num)) {
            errors.push(`Parameter "${param.name}" must be a valid number.`);
          } else {
            if (param.min !== undefined && num < param.min) {
              errors.push(`Parameter "${param.name}" must be at least ${param.min}. Got ${num}.`);
            }
            if (param.max !== undefined && num > param.max) {
              errors.push(`Parameter "${param.name}" cannot exceed ${param.max}. Got ${num}.`);
            }
            sanitized[param.name] = num;
          }
          break;
        }

        case 'boolean': {
          if (typeof val === 'boolean') {
            sanitized[param.name] = val;
          } else if (typeof val === 'string') {
            sanitized[param.name] = val.toLowerCase() === 'true' || val === '1';
          } else {
            sanitized[param.name] = Boolean(val);
          }
          break;
        }

        case 'array': {
          if (!Array.isArray(val)) {
            errors.push(`Parameter "${param.name}" must be an array.`);
          } else {
            sanitized[param.name] = val;
          }
          break;
        }

        case 'object': {
          if (typeof val !== 'object' || Array.isArray(val)) {
            errors.push(`Parameter "${param.name}" must be an object.`);
          } else {
            sanitized[param.name] = val;
          }
          break;
        }
      }
    }

    // 2. Run custom validator if specified
    if (errors.length === 0 && tool.customValidator) {
      const customRes = tool.customValidator(sanitized);
      if (!customRes.valid) {
        errors.push(...customRes.errors);
      }
    }

    return {
      valid: errors.length === 0,
      sanitizedArgs: sanitized,
      errors,
      warnings,
      tool,
    };
  }

  /**
   * Generates OpenAPI / Gemini JSON Schema representation of all registered tools
   */
  public static getToolSchemasForAI(): any[] {
    return this.getAllTools().map((tool) => {
      const properties: Record<string, any> = {};
      const required: string[] = [];

      for (const p of tool.parameters) {
        properties[p.name] = {
          type: p.type,
          description: p.description,
        };
        if (p.required) {
          required.push(p.name);
        }
      }

      return {
        name: tool.name,
        description: tool.description,
        parameters: {
          type: 'object',
          properties,
          required,
        },
      };
    });
  }
}
