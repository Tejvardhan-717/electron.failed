export type AIState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'PLANNING'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'SPEAKING'
  | 'SUCCESS'
  | 'ERROR';

export type AccentColor =
  | 'blue'
  | 'cyan'
  | 'purple'
  | 'green'
  | 'red'
  | 'white'
  | 'amber'
  | 'emerald'
  | 'crimson';

export type RiskLevel = 0 | 1 | 2 | 3 | 4;

export interface RiskLevelInfo {
  level: RiskLevel;
  name: string;
  badgeColor: string;
  badgeBg: string;
  description: string;
}

export const RISK_LEVELS: Record<RiskLevel, RiskLevelInfo> = {
  0: {
    level: 0,
    name: 'LEVEL 0 — SAFE',
    badgeColor: 'text-emerald-400',
    badgeBg: 'bg-emerald-500/10 border-emerald-500/30',
    description: 'Executes automatically with zero risk to system or data.'
  },
  1: {
    level: 1,
    name: 'LEVEL 1 — LOW RISK',
    badgeColor: 'text-sky-400',
    badgeBg: 'bg-sky-500/10 border-sky-500/30',
    description: 'Executes automatically and records detailed audit log.'
  },
  2: {
    level: 2,
    name: 'LEVEL 2 — MODERATE RISK',
    badgeColor: 'text-amber-400',
    badgeBg: 'bg-amber-500/10 border-amber-500/30',
    description: 'Requires user confirmation unless explicitly marked as trusted.'
  },
  3: {
    level: 3,
    name: 'LEVEL 3 — HIGH RISK',
    badgeColor: 'text-rose-400',
    badgeBg: 'bg-rose-500/10 border-rose-500/30',
    description: 'Mandatory explicit confirmation dialog required before proceeding.'
  },
  4: {
    level: 4,
    name: 'LEVEL 4 — CRITICAL / BLOCKED',
    badgeColor: 'text-red-500',
    badgeBg: 'bg-red-950/40 border-red-500/50',
    description: 'Strictly prohibited. Cannot be executed automatically or manually.'
  }
};

export type ToolCategory = 'applications' | 'files' | 'windows' | 'system' | 'browser' | 'software' | 'power';

export interface ToolDefinition {
  name: string;
  category: ToolCategory;
  description: string;
  riskLevel: RiskLevel;
  requiresAdmin?: boolean;
  reversible?: boolean;
  parameters: {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'array';
    required: boolean;
    description: string;
  }[];
}

export interface ToolExecutionRequest {
  id: string;
  toolName: string;
  params: Record<string, any>;
  riskLevel: RiskLevel;
  reason?: string;
  userApproved?: boolean;
}

export interface ToolExecutionResult {
  success: boolean;
  output: string;
  data?: any;
  undoable?: boolean;
  undoRecord?: UndoRecord;
  error?: string;
  durationMs: number;
}

export interface UndoRecord {
  id: string;
  timestamp: string;
  toolName: string;
  description: string;
  forwardAction: {
    tool: string;
    params: Record<string, any>;
  };
  reverseAction: {
    tool: string;
    params: Record<string, any>;
  };
}

export type TaskStateMachineState =
  | 'RECEIVED'
  | 'PLANNING'
  | 'WAITING_FOR_PERMISSION'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type WakeWordEngineState =
  | 'IDLE'
  | 'LISTENING_FOR_WAKE_WORD'
  | 'WAKE_WORD_DETECTED'
  | 'LISTENING_FOR_COMMAND'
  | 'PROCESSING'
  | 'SPEAKING';

export type ConversationState =
  | 'SLEEPING'
  | 'WAKE_WORD_DETECTED'
  | 'ACTIVATING'
  | 'ACTIVE_CONVERSATION'
  | 'LISTENING'
  | 'THINKING'
  | 'EXECUTING'
  | 'SPEAKING';

export type SessionMode = 'SLEEPING' | 'ACTIVE';

export interface DeveloperSessionStatus {
  microphoneStatus: MicrophoneStatus;
  wakeWordStatus: 'LISTENING' | 'TEMPORARILY_DISABLED' | 'OFF';
  sessionStatus: SessionMode;
  conversationState: ConversationState;
  inactivitySeconds: number;
  inactivityMaxSeconds: number;
  isTimerPaused: boolean;
  pauseReason?: string;
  lastSpokenText?: string;
  lastCommand?: string;
}

export type MicrophoneStatus =
  | 'CONNECTED'
  | 'DISCONNECTED'
  | 'PERMISSION_DENIED'
  | 'NO_DEVICE'
  | 'ERROR';

export type TaskStatus =
  | 'idle'
  | 'planning'
  | 'running'
  | 'paused'
  | 'waiting_approval'
  | 'completed'
  | 'cancelled'
  | 'error'
  | TaskStateMachineState;

export interface TaskStep {
  id: string;
  stepNumber: number;
  description: string;
  toolName: string;
  params: Record<string, any>;
  riskLevel: RiskLevel;
  status:
    | 'pending'
    | 'waiting_approval'
    | 'running'
    | 'verifying'
    | 'completed'
    | 'failed'
    | 'skipped';
  result?: string;
  verified?: boolean;
  verificationMessage?: string;
  durationMs?: number;
  reversible?: boolean;
  liveLogs?: string[];
}

export interface TaskPlan {
  id: string;
  title: string;
  userCommand: string;
  status: TaskStatus;
  state: TaskStateMachineState;
  progressPercent: number;
  currentStepIndex: number;
  steps: TaskStep[];
  startedAt?: string;
  completedAt?: string;
  errorMessage?: string;
  liveStatusLogs?: { timestamp: string; text: string; type: 'info' | 'success' | 'warning' | 'error' }[];
}

export interface ProcessItem {
  pid: number;
  name: string;
  cpuPercent: number;
  memoryMb: number;
  status: 'running' | 'sleeping' | 'suspended';
}

export interface SystemMetrics {
  cpu: number;
  ram: number;
  gpu: number;
  disk: number;
  networkInKb: number;
  networkOutKb: number;
  batteryPercent: number;
  isCharging: boolean;
  cpuTempC: number;
  topProcesses: ProcessItem[];
  uptimeSeconds: number;
}

export interface MemoryItem {
  id: string;
  key: string;
  category: 'preference' | 'automation' | 'frequent_app' | 'alias' | 'note';
  value: string;
  description?: string;
  createdAt: string;
  lastUsedAt?: string;
  useCount: number;
}

export interface AutomationRule {
  id: string;
  triggerPhrase: string;
  name: string;
  description: string;
  enabled: boolean;
  actions: {
    toolName: string;
    params: Record<string, any>;
    description: string;
  }[];
  createdAt: string;
}

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  userCommand?: string;
  assistantResponse?: string;
  toolName?: string;
  riskLevel: RiskLevel;
  status: 'success' | 'warning' | 'error' | 'blocked' | 'aborted';
  details: string;
  reversible?: boolean;
  undoId?: string;
}

export interface JarvisSettings {
  assistantName: string;
  personality: 'formal' | 'witty' | 'concise' | 'tactical';
  wakeWord: string;
  wakeWordEnabled: boolean;
  voiceName: string;
  speechSpeed: number; // 0.8 - 1.4
  speechPitch: number; // 0.8 - 1.2
  audioFeedback: boolean;
  continuousListening: boolean;
  hotkey: string; // e.g. "Control+Space"
  
  // Security
  protectedFolders: string[];
  protectedExtensions: string[];
  trustedApps: string[];
  allowTrustedAutoInstall: boolean;
  requireAdminApproval: boolean;
  maxAutomatedSteps: number;
  
  // Memory
  enableMemory: boolean;
  
  // UI
  accentColor: AccentColor;
  animationIntensity: 'high' | 'medium' | 'minimal';
  hudScanlines: boolean;
  startWithWindows: boolean;
  soundEffects: boolean;
}

export interface ConfirmationRequest {
  id: string;
  stepId?: string;
  title: string;
  toolName: string;
  params: Record<string, any>;
  riskLevel: RiskLevel;
  reason: string;
  warningDetails: string[];
  onConfirm: () => void;
  onReject: () => void;
}

export interface DiagnosticItem {
  id: string;
  stepNumber?: number;
  title: string;
  category:
    | 'Windows API'
    | 'Process control'
    | 'File system'
    | 'Application launch'
    | 'Application close'
    | 'Browser control'
    | 'Screenshot'
    | 'Microphone'
    | 'Wake word'
    | string;
  status?: 'pending' | 'running' | 'passed' | 'failed';
  passed?: boolean;
  message?: string;
  details?: string;
  error?: string;
  durationMs?: number;
}

export interface PcAccessTestReport {
  timestamp: string;
  overallPassed: boolean;
  categories?: {
    [key: string]: boolean;
  };
  categorySummary?: {
    [key: string]: boolean;
  };
  bridgeStatus?: BridgeStatus;
  tests?: DiagnosticItem[];
  steps?: DiagnosticItem[];
}

export interface BridgeStatus {
  connected: boolean;
  connectionType: 'native_windows' | 'bridge_agent' | 'sandbox_container';
  hostName?: string;
  osVersion?: string;
  username?: string;
  ipAddress?: string;
  lastPing?: string;
  latencyMs?: number;
}

