import React from 'react';
import { TaskPlan, TaskStep, RISK_LEVELS } from '../types';
import { Play, Pause, XCircle, RotateCcw, CheckCircle2, Loader2, AlertCircle, ShieldAlert, Layers } from 'lucide-react';

interface TaskEnginePanelProps {
  currentPlan: TaskPlan | null;
  onPause?: () => void;
  onResume?: () => void;
  onCancel?: () => void;
  onUndoLast?: () => void;
  canUndo?: boolean;
}

export const TaskEnginePanel: React.FC<TaskEnginePanelProps> = ({
  currentPlan,
  onPause,
  onResume,
  onCancel,
  onUndoLast,
  canUndo = false,
}) => {
  if (!currentPlan) {
    return (
      <div
        id="jarvis-task-panel-idle"
        className="bg-[#0b0f17]/90 border border-white/10 rounded-xl p-4 backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.45)] flex flex-col items-center justify-center text-center h-full min-h-[200px]"
      >
        <Layers className="w-8 h-8 text-cyan-400/40 mb-2 animate-pulse" />
        <span className="text-xs font-mono tracking-widest text-cyan-300/70 uppercase">
          AUTONOMOUS TASK ENGINE IDLE
        </span>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          Commands like &ldquo;Clean up my Downloads&rdquo; or &ldquo;Prepare PC for gaming&rdquo; will initiate multi-step execution plans here.
        </p>
        {canUndo && (
          <button
            onClick={onUndoLast}
            className="mt-3 px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono hover:bg-amber-500/20 flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Undo Last Action
          </button>
        )}
      </div>
    );
  }

  const isRunning = currentPlan.status === 'running';
  const isPaused = currentPlan.status === 'paused';
  const isWaitingApproval = currentPlan.status === 'waiting_approval';
  const isCompleted = currentPlan.status === 'completed';
  const isError = currentPlan.status === 'error';

  const planSteps = Array.isArray(currentPlan.steps) ? currentPlan.steps : [];
  const currentStep = planSteps[currentPlan.currentStepIndex];

  return (
    <div
      id="jarvis-task-panel-active"
      className="bg-[#0b0f17]/95 border border-white/10 rounded-xl p-4 backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.5)] flex flex-col h-full overflow-hidden"
    >
      {/* Task Header */}
      <div className="flex items-center justify-between pb-2.5 border-b border-white/10 mb-3">
        <div className="min-w-0 pr-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 uppercase tracking-widest">
              TASK: {currentPlan.status}
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              {currentPlan.currentStepIndex + 1} / {planSteps.length} Steps
            </span>
          </div>
          <h3 className="text-sm font-bold text-slate-100 truncate mt-1 tracking-wide">
            {currentPlan.title}
          </h3>
        </div>

        {/* Task Control Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          {isRunning && onPause && (
            <button
              onClick={onPause}
              title="Pause task execution"
              className="p-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 transition-colors"
            >
              <Pause className="w-4 h-4" />
            </button>
          )}

          {isPaused && onResume && (
            <button
              onClick={onResume}
              title="Resume task execution"
              className="p-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 transition-colors"
            >
              <Play className="w-4 h-4" />
            </button>
          )}

          {(isRunning || isPaused || isWaitingApproval) && onCancel && (
            <button
              onClick={onCancel}
              title="Cancel & abort task immediately"
              className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors"
            >
              <XCircle className="w-4 h-4" />
            </button>
          )}

          {canUndo && onUndoLast && (
            <button
              onClick={onUndoLast}
              title="Undo last reversible operation"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Futuristic Progress Bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs font-mono mb-1">
          <span className="text-slate-300">
            CURRENT: <span className="text-cyan-300 font-semibold">{currentStep ? currentStep.description : 'Finalizing task...'}</span>
          </span>
          <span className="font-bold text-cyan-400">{Math.round(currentPlan.progressPercent)}%</span>
        </div>
        <div className="w-full bg-[#070a10] rounded-full h-2.5 overflow-hidden border border-white/10 p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-sky-400 to-emerald-400 transition-all duration-300 shadow-[0_0_10px_rgba(0,210,255,0.4)]"
            style={{ width: `${Math.min(currentPlan.progressPercent, 100)}%` }}
          />
        </div>
      </div>

      {/* Step by step list */}
      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 min-h-0">
        {planSteps.map((step, idx) => {
          const riskInfo = RISK_LEVELS[step.riskLevel];
          const isStepActive = idx === currentPlan.currentStepIndex && isRunning;

          return (
            <div
              key={step.id}
              className={`p-2 rounded-lg border text-xs font-mono transition-all ${
                isStepActive
                  ? 'bg-[#081524] border-cyan-400/50 shadow-[0_0_10px_rgba(0,210,255,0.18)]'
                  : step.status === 'completed'
                  ? 'bg-emerald-950/20 border-emerald-500/30 text-slate-300'
                  : step.status === 'failed'
                  ? 'bg-rose-950/30 border-rose-500/40 text-rose-200'
                  : 'bg-[#070a10]/70 border-white/5 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  {step.status === 'completed' && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  )}
                  {step.status === 'verifying' && (
                    <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />
                  )}
                  {isStepActive && step.status !== 'verifying' && (
                    <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin shrink-0" />
                  )}
                  {step.status === 'pending' && (
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-600 flex items-center justify-center text-[9px] shrink-0">
                      {step.stepNumber}
                    </span>
                  )}
                  {step.status === 'waiting_approval' && (
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400 animate-bounce shrink-0" />
                  )}
                  {step.status === 'failed' && (
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  )}

                  <span className="truncate font-medium text-slate-200">
                    {step.stepNumber}. {step.description}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 ml-2">
                  {step.verified === true && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                      VERIFIED
                    </span>
                  )}
                  {step.verified === false && step.status === 'failed' && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold">
                      UNVERIFIED
                    </span>
                  )}
                  <span className={`text-[9px] px-1.5 py-0.5 rounded border ${riskInfo.badgeBg} ${riskInfo.badgeColor}`}>
                    L{step.riskLevel}
                  </span>
                  {step.durationMs && (
                    <span className="text-[9px] text-slate-400">
                      {(step.durationMs / 1000).toFixed(1)}s
                    </span>
                  )}
                </div>
              </div>

              {step.result && (
                <div className="mt-1 text-[11px] text-slate-300 pl-5 border-l-2 border-cyan-500/40 font-mono">
                  {step.result}
                </div>
              )}
              {step.verificationMessage && (
                <div className="mt-0.5 text-[10px] text-emerald-400 pl-5">
                  ✓ {step.verificationMessage}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
