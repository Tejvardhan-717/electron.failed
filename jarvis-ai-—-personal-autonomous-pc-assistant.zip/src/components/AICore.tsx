import React, { useEffect, useRef, useState, useMemo } from 'react';
import { AIState, AccentColor } from '../types';
import {
  Mic,
  Volume2,
  Cpu,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Search,
} from 'lucide-react';

interface AICoreProps {
  state: AIState;
  onClick?: () => void;
  accentColor?: AccentColor;
  subText?: string;
  isListening?: boolean;
  voiceLevel?: number; // 0 to 100
  fullscreen?: boolean;
}

// Color palette definitions matching Stark / JARVIS aesthetic
const ACCENT_THEMES: Record<
  AccentColor,
  {
    primary: string;
    secondary: string;
    glow: string;
    glowStrong: string;
    bgRgba: string;
    text: string;
    border: string;
    accentClass: string;
  }
> = {
  blue: {
    primary: '#00d2ff',
    secondary: '#0077ff',
    glow: 'rgba(0, 210, 255, 0.5)',
    glowStrong: 'rgba(0, 210, 255, 0.85)',
    bgRgba: 'rgba(0, 210, 255, 0.08)',
    text: 'text-cyan-400',
    border: 'border-cyan-500/40',
    accentClass: 'cyan',
  },
  cyan: {
    primary: '#06b6d4',
    secondary: '#0284c7',
    glow: 'rgba(6, 182, 212, 0.5)',
    glowStrong: 'rgba(6, 182, 212, 0.85)',
    bgRgba: 'rgba(6, 182, 212, 0.08)',
    text: 'text-cyan-400',
    border: 'border-cyan-500/40',
    accentClass: 'cyan',
  },
  purple: {
    primary: '#a855f7',
    secondary: '#7c3aed',
    glow: 'rgba(168, 85, 247, 0.5)',
    glowStrong: 'rgba(168, 85, 247, 0.85)',
    bgRgba: 'rgba(168, 85, 247, 0.08)',
    text: 'text-purple-400',
    border: 'border-purple-500/40',
    accentClass: 'purple',
  },
  green: {
    primary: '#10b981',
    secondary: '#059669',
    glow: 'rgba(16, 185, 129, 0.5)',
    glowStrong: 'rgba(16, 185, 129, 0.85)',
    bgRgba: 'rgba(16, 185, 129, 0.08)',
    text: 'text-emerald-400',
    border: 'border-emerald-500/40',
    accentClass: 'emerald',
  },
  emerald: {
    primary: '#10b981',
    secondary: '#059669',
    glow: 'rgba(16, 185, 129, 0.5)',
    glowStrong: 'rgba(16, 185, 129, 0.85)',
    bgRgba: 'rgba(16, 185, 129, 0.08)',
    text: 'text-emerald-400',
    border: 'border-emerald-500/40',
    accentClass: 'emerald',
  },
  red: {
    primary: '#f43f5e',
    secondary: '#e11d48',
    glow: 'rgba(244, 63, 94, 0.55)',
    glowStrong: 'rgba(244, 63, 94, 0.9)',
    bgRgba: 'rgba(244, 63, 94, 0.08)',
    text: 'text-rose-400',
    border: 'border-rose-500/40',
    accentClass: 'rose',
  },
  crimson: {
    primary: '#f43f5e',
    secondary: '#be123c',
    glow: 'rgba(244, 63, 94, 0.55)',
    glowStrong: 'rgba(244, 63, 94, 0.9)',
    bgRgba: 'rgba(244, 63, 94, 0.08)',
    text: 'text-rose-400',
    border: 'border-rose-500/40',
    accentClass: 'rose',
  },
  white: {
    primary: '#f8fafc',
    secondary: '#94a3b8',
    glow: 'rgba(248, 250, 252, 0.4)',
    glowStrong: 'rgba(248, 250, 252, 0.75)',
    bgRgba: 'rgba(248, 250, 252, 0.08)',
    text: 'text-slate-200',
    border: 'border-slate-300/40',
    accentClass: 'slate',
  },
  amber: {
    primary: '#f59e0b',
    secondary: '#d97706',
    glow: 'rgba(245, 158, 11, 0.5)',
    glowStrong: 'rgba(245, 158, 11, 0.85)',
    bgRgba: 'rgba(245, 158, 11, 0.08)',
    text: 'text-amber-400',
    border: 'border-amber-500/40',
    accentClass: 'amber',
  },
};

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  baseAlpha: number;
  angle: number;
  dist: number;
  angularSpeed: number;
  orbitRadius: number;
}

export const AICore: React.FC<AICoreProps> = ({
  state,
  onClick,
  accentColor = 'blue',
  subText,
  isListening = false,
  voiceLevel = 0,
  fullscreen = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const theme = ACCENT_THEMES[accentColor] || ACCENT_THEMES.blue;

  // Real voice spectrum bars (24 precision bars)
  const numBars = 24;
  const [waveHeights, setWaveHeights] = useState<number[]>(() =>
    new Array(numBars).fill(2)
  );

  // Update waveform strictly tied to actual audio (voiceLevel) or speaking state
  useEffect(() => {
    let frameId: number;
    let t = 0;

    const updateWave = () => {
      t += 0.08;
      // If no audio (voiceLevel === 0 and not speaking), waveform should be nearly still!
      const isVoiceActive = voiceLevel > 0 || state === 'SPEAKING';
      const effectiveVol = state === 'SPEAKING' ? Math.max(voiceLevel, 45) : voiceLevel;

      if (!isVoiceActive) {
        // Flat, calm resting baseline (2px-3px height) with very subtle ambient breath
        setWaveHeights(
          Array.from({ length: numBars }, (_, i) => {
            const subtleWave = Math.sin(t * 0.5 + i * 0.25) * 0.8;
            return Math.max(2, 2.5 + subtleWave);
          })
        );
      } else {
        // Proportional frequency bands based on true mic volume
        const maxH = fullscreen ? 48 : 36;
        setWaveHeights(
          Array.from({ length: numBars }, (_, i) => {
            // Bell curve factor centered around middle frequencies
            const centerDist = Math.abs(i - numBars / 2) / (numBars / 2);
            const freqFactor = Math.cos(centerDist * (Math.PI / 2));
            const harmonic = Math.sin(t * 1.8 + i * 0.6) * 0.35 + 0.65;
            const height = Math.min(
              maxH,
              Math.max(3, (effectiveVol / 100) * maxH * freqFactor * harmonic + 2)
            );
            return height;
          })
        );
      }

      frameId = requestAnimationFrame(updateWave);
    };

    frameId = requestAnimationFrame(updateWave);
    return () => cancelAnimationFrame(frameId);
  }, [voiceLevel, state, fullscreen, numBars]);

  // Particle engine around the core
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const count = fullscreen ? 60 : 45;
    const particles: Particle[] = [];

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const orbitRadius = 60 + Math.random() * (width * 0.38);
      particles.push({
        x: centerX + Math.cos(angle) * orbitRadius,
        y: centerY + Math.sin(angle) * orbitRadius,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        radius: Math.random() * 1.8 + 0.6,
        alpha: Math.random() * 0.6 + 0.2,
        baseAlpha: Math.random() * 0.6 + 0.2,
        angle,
        dist: orbitRadius,
        angularSpeed: (Math.random() * 0.008 + 0.002) * (Math.random() > 0.5 ? 1 : -1),
        orbitRadius,
      });
    }

    let t = 0;

    const render = () => {
      t += 0.015;
      ctx.clearRect(0, 0, width, height);

      // Speed multiplier based on AI state
      let speedMult = 1;
      let expandMult = 1;

      if (state === 'LISTENING') {
        speedMult = 1.3;
        expandMult = 1 + (voiceLevel / 100) * 0.25;
      } else if (state === 'THINKING') {
        speedMult = 3.2;
      } else if (state === 'PLANNING') {
        speedMult = 2.4;
      } else if (state === 'EXECUTING') {
        speedMult = 2.0;
        expandMult = 1.1;
      } else if (state === 'VERIFYING') {
        speedMult = 1.5;
      } else if (state === 'SPEAKING') {
        speedMult = 1.6;
        expandMult = 1.15;
      } else if (state === 'SUCCESS') {
        speedMult = 0.8;
      } else if (state === 'ERROR') {
        speedMult = 0.5;
      }

      particles.forEach((p) => {
        // Orbit around center
        p.angle += p.angularSpeed * speedMult;
        const targetRadius = p.orbitRadius * expandMult;
        p.dist += (targetRadius - p.dist) * 0.05;

        p.x = centerX + Math.cos(p.angle) * p.dist;
        p.y = centerY + Math.sin(p.angle) * p.dist;

        // Mouse avoidance/attraction
        if (isHovered) {
          const dx = p.x - mousePos.x;
          const dy = p.y - mousePos.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 80) {
            p.x += (dx / d) * 2;
            p.y += (dy / d) * 2;
          }
        }

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);

        let particleColor = theme.primary;
        if (state === 'SUCCESS') particleColor = '#10b981';
        if (state === 'ERROR') particleColor = '#f43f5e';

        ctx.fillStyle = particleColor;
        ctx.globalAlpha = p.alpha * (state === 'THINKING' ? 0.9 : 0.6);
        ctx.fill();
      });

      // Subtle connecting energy filaments for adjacent particles
      ctx.lineWidth = 0.5;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const p1 = particles[i];
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 42) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = state === 'ERROR' ? '#f43f5e' : theme.primary;
            ctx.globalAlpha = (1 - dist / 42) * 0.25;
            ctx.stroke();
          }
        }
      }

      ctx.globalAlpha = 1;
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [state, voiceLevel, fullscreen, theme, isHovered, mousePos]);

  // Handle mouse move over container for interactive particle reactions
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * (fullscreen ? 440 : 360);
    const y = ((e.clientY - rect.top) / rect.height) * (fullscreen ? 440 : 360);
    setMousePos({ x, y });
  };

  // State text, icon and colors
  const stateConfig = useMemo(() => {
    switch (state) {
      case 'LISTENING':
        return {
          label: 'LISTENING...',
          sub: subText || 'Listening for speech command...',
          color: theme.primary,
          glow: theme.glowStrong,
          badgeBg: 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300',
          icon: Mic,
          pulseSpeed: 'animate-pulse',
        };
      case 'THINKING':
        return {
          label: 'THINKING...',
          sub: subText || 'Analyzing intent and resolving logic...',
          color: theme.primary,
          glow: theme.glowStrong,
          badgeBg: 'bg-blue-500/15 border-blue-500/40 text-blue-300',
          icon: Cpu,
          pulseSpeed: 'animate-pulse-fast',
        };
      case 'PLANNING':
        return {
          label: 'PLANNING TASK...',
          sub: subText || 'Synthesizing verified multi-step sequence...',
          color: '#38bdf8',
          glow: 'rgba(56, 189, 248, 0.7)',
          badgeBg: 'bg-sky-500/15 border-sky-500/40 text-sky-300',
          icon: Layers,
          pulseSpeed: 'animate-pulse-subtle',
        };
      case 'EXECUTING':
        return {
          label: 'EXECUTING...',
          sub: subText || 'Autonomous execution in progress...',
          color: '#3b82f6',
          glow: 'rgba(59, 130, 246, 0.75)',
          badgeBg: 'bg-indigo-500/15 border-indigo-500/40 text-indigo-300',
          icon: Radio,
          pulseSpeed: 'animate-pulse',
        };
      case 'VERIFYING':
        return {
          label: 'VERIFYING...',
          sub: subText || 'Scanning system state & process outputs...',
          color: '#06b6d4',
          glow: 'rgba(6, 182, 212, 0.8)',
          badgeBg: 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300',
          icon: Search,
          pulseSpeed: 'animate-pulse',
        };
      case 'SPEAKING':
        return {
          label: 'SPEAKING...',
          sub: subText || 'JARVIS vocal feedback active...',
          color: theme.primary,
          glow: theme.glowStrong,
          badgeBg: 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300',
          icon: Volume2,
          pulseSpeed: 'animate-pulse',
        };
      case 'SUCCESS':
        return {
          label: 'TASK COMPLETED',
          sub: subText || 'Verified execution successful, sir.',
          color: '#10b981',
          glow: 'rgba(16, 185, 129, 0.8)',
          badgeBg: 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300',
          icon: CheckCircle2,
          pulseSpeed: '',
        };
      case 'ERROR':
        return {
          label: 'ACTION FAILED',
          sub: subText || 'Execution error encountered. Telemetry logged.',
          color: '#f43f5e',
          glow: 'rgba(244, 63, 94, 0.8)',
          badgeBg: 'bg-rose-500/15 border-rose-500/40 text-rose-300',
          icon: AlertTriangle,
          pulseSpeed: '',
        };
      case 'IDLE':
      default:
        return {
          label: 'AWAITING COMMAND',
          sub: subText || '"How may I assist you, sir?"',
          color: theme.primary,
          glow: theme.glow,
          badgeBg: 'bg-white/5 border-white/10 text-slate-300',
          icon: Sparkles,
          pulseSpeed: 'animate-pulse-subtle',
        };
    }
  }, [state, subText, theme]);

  const StatusIcon = stateConfig.icon;

  // Dynamically computed rotation classes based on active state
  const outerRingAnim =
    state === 'THINKING'
      ? 'animate-[spin-slow_4s_linear_infinite]'
      : state === 'PLANNING' || state === 'EXECUTING'
      ? 'animate-[spin-slow_8s_linear_infinite]'
      : state === 'LISTENING'
      ? 'animate-[spin-slow_12s_linear_infinite]'
      : 'animate-spin-slow';

  const innerRingAnim =
    state === 'THINKING'
      ? 'animate-[spin-reverse_3s_linear_infinite]'
      : state === 'PLANNING' || state === 'EXECUTING'
      ? 'animate-[spin-reverse_7s_linear_infinite]'
      : state === 'LISTENING'
      ? 'animate-[spin-reverse_10s_linear_infinite]'
      : 'animate-spin-reverse';

  // Responsive Core Size
  const sizeClass = fullscreen ? 'w-88 h-88 sm:w-96 sm:h-96' : 'w-72 h-72 sm:w-80 sm:h-80';
  const canvasSize = fullscreen ? 440 : 360;

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="flex flex-col items-center justify-center relative select-none"
    >
      {/* Central Interactive Orb Container */}
      <div
        id="jarvis-core-orb"
        onClick={onClick}
        title={isListening ? 'Click to pause microphone' : 'Click to activate voice listening'}
        className={`relative ${sizeClass} flex items-center justify-center cursor-pointer transition-transform duration-500 group ${
          isHovered ? 'scale-[1.03]' : 'scale-100'
        }`}
      >
        {/* Layer 8: Atmospheric Ambient Light Bloom */}
        <div
          className="absolute inset-0 rounded-full blur-3xl pointer-events-none transition-all duration-700 -z-10"
          style={{
            background: `radial-gradient(circle, ${stateConfig.glow} 0%, rgba(0,0,0,0) 72%)`,
            opacity: state === 'LISTENING' || state === 'SPEAKING' ? 0.85 : 0.45,
            transform: `scale(${1 + (voiceLevel / 100) * 0.35})`,
          }}
        />

        {/* Layer 3: Interactive Dynamic Canvas Particle Field */}
        <canvas
          ref={canvasRef}
          width={canvasSize}
          height={canvasSize}
          className="absolute inset-0 pointer-events-none z-0"
          style={{
            width: '100%',
            height: '100%',
          }}
        />

        {/* Layer 1: Outer Energy Ring (Pulsing SVG Path with Cardinal Ticks & Nodes) */}
        <div
          className={`absolute inset-0 z-10 pointer-events-none transition-transform duration-300 ${outerRingAnim}`}
        >
          <svg className="w-full h-full" viewBox="0 0 320 320">
            {/* Primary Calibrated Outer Ring */}
            <circle
              cx="160"
              cy="160"
              r="150"
              fill="none"
              stroke={stateConfig.color}
              strokeWidth="1.2"
              strokeDasharray="4 8"
              strokeOpacity="0.4"
            />

            {/* Segmented Energy Arc Overlays */}
            <circle
              cx="160"
              cy="160"
              r="150"
              fill="none"
              stroke={stateConfig.color}
              strokeWidth="2.5"
              strokeDasharray="90 150"
              strokeDashoffset="45"
              strokeLinecap="round"
              strokeOpacity="0.85"
              style={{
                filter: `drop-shadow(0 0 6px ${stateConfig.color})`,
              }}
            />

            {/* Cardinal Navigation Reticle Marks */}
            <line x1="160" y1="2" x2="160" y2="14" stroke={stateConfig.color} strokeWidth="2" strokeOpacity="0.8" />
            <line x1="160" y1="306" x2="160" y2="318" stroke={stateConfig.color} strokeWidth="2" strokeOpacity="0.8" />
            <line x1="2" y1="160" x2="14" y2="160" stroke={stateConfig.color} strokeWidth="2" strokeOpacity="0.8" />
            <line x1="306" y1="160" x2="318" y2="160" stroke={stateConfig.color} strokeWidth="2" strokeOpacity="0.8" />

            {/* Orbiting Orbital Nodes */}
            <circle cx="160" cy="10" r="3.5" fill={stateConfig.color} style={{ filter: `drop-shadow(0 0 4px ${stateConfig.color})` }} />
            <circle cx="310" cy="160" r="2.5" fill={stateConfig.color} />
            <circle cx="160" cy="310" r="3" fill={stateConfig.color} />
            <circle cx="10" cy="160" r="2" fill={stateConfig.color} />
          </svg>
        </div>

        {/* Layer 2: Counter-Rotating Ring (Mechanical Teeth & Laser Ticks) */}
        <div
          className={`absolute inset-4 z-10 pointer-events-none transition-transform duration-300 ${innerRingAnim}`}
        >
          <svg className="w-full h-full" viewBox="0 0 280 280">
            {/* Fine Precision Calibrations */}
            <circle
              cx="140"
              cy="140"
              r="130"
              fill="none"
              stroke={stateConfig.color}
              strokeWidth="1"
              strokeDasharray="2 6"
              strokeOpacity="0.35"
            />
            {/* Counter Segmented Arc */}
            <circle
              cx="140"
              cy="140"
              r="130"
              fill="none"
              stroke={stateConfig.color}
              strokeWidth="2"
              strokeDasharray="60 180"
              strokeDashoffset="120"
              strokeLinecap="round"
              strokeOpacity="0.7"
              style={{
                filter: `drop-shadow(0 0 4px ${stateConfig.color})`,
              }}
            />

            {/* Precision Angle Brackets */}
            <g stroke={stateConfig.color} strokeWidth="1.5" strokeOpacity="0.6">
              <path d="M 130 18 L 140 12 L 150 18" fill="none" />
              <path d="M 130 262 L 140 268 L 150 262" fill="none" />
              <path d="M 18 130 L 12 140 L 18 150" fill="none" />
              <path d="M 262 130 L 268 140 L 262 150" fill="none" />
            </g>
          </svg>
        </div>

        {/* Layer 4: Rotating Geometric Gimbal Rings (Gimbal Horizon & Reticle) */}
        <div
          className={`absolute inset-10 z-10 pointer-events-none transition-all duration-500 ${
            state === 'VERIFYING'
              ? 'animate-ping opacity-60'
              : state === 'PLANNING'
              ? 'scale-105 rotate-45 transition-transform'
              : 'animate-spin-slow'
          }`}
        >
          <svg className="w-full h-full" viewBox="0 0 220 220">
            <circle
              cx="110"
              cy="110"
              r="95"
              fill="none"
              stroke={stateConfig.color}
              strokeWidth="1"
              strokeDasharray="20 40 10 30"
              strokeOpacity="0.45"
            />
            {/* Center Crosshairs */}
            <circle cx="110" cy="110" r="80" fill="none" stroke={stateConfig.color} strokeWidth="0.8" strokeOpacity="0.25" />
          </svg>
        </div>

        {/* Layer 5: Deep Pulsing Center Reactor Iris */}
        <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full flex items-center justify-center z-20">
          {/* Glass Reactor Background */}
          <div
            className="absolute inset-0 rounded-full border transition-all duration-500 backdrop-blur-md"
            style={{
              borderColor: stateConfig.color,
              background: `radial-gradient(circle at center, ${theme.bgRgba} 0%, rgba(5,7,12,0.92) 80%)`,
              boxShadow: `inset 0 0 24px ${stateConfig.glow}, 0 0 18px ${stateConfig.glow}`,
              transform: `scale(${
                isListening
                  ? 1 + (voiceLevel / 100) * 0.18
                  : state === 'THINKING'
                  ? 1.08
                  : 1
              })`,
            }}
          />

          {/* Central Reactor Core Iris */}
          <div
            className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center transition-all duration-300"
            style={{
              background: `radial-gradient(circle, ${stateConfig.color} 0%, rgba(2,6,23,0.9) 75%)`,
              boxShadow: `0 0 28px ${stateConfig.glowStrong}`,
            }}
          >
            {/* Center State Icon / Core Symbol */}
            <div className="relative z-30 flex flex-col items-center justify-center text-white">
              <StatusIcon
                className={`w-7 h-7 sm:w-8 sm:h-8 transition-transform duration-300 drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] ${
                  state === 'LISTENING' ? 'animate-bounce' : ''
                }`}
                style={{ color: '#ffffff' }}
              />
            </div>

            {/* Glowing Core Lens Flare Ring */}
            <div
              className="absolute inset-1 rounded-full border border-white/40 pointer-events-none animate-pulse-subtle"
            />
          </div>
        </div>

        {/* Layer 6: Micro Telemetry HUD Annotations around the Core */}
        <div className="absolute top-2 left-4 font-mono text-[9px] text-slate-500 pointer-events-none hidden sm:block tracking-widest">
          SYS.STARK // MK85
        </div>
        <div className="absolute top-2 right-4 font-mono text-[9px] text-cyan-400/70 pointer-events-none hidden sm:block tracking-widest">
          AI // NEURAL
        </div>
        <div className="absolute bottom-2 left-4 font-mono text-[9px] text-slate-500 pointer-events-none hidden sm:block tracking-widest">
          {voiceLevel > 0 ? `VOL: ${voiceLevel}%` : 'VOL: 00%'}
        </div>
        <div className="absolute bottom-2 right-4 font-mono text-[9px] text-slate-500 pointer-events-none hidden sm:block tracking-widest">
          {state}
        </div>
      </div>

      {/* Layer 7: Dynamic Real-Time Voice Waveform */}
      {/* Positioned directly below the AI core, reacting ONLY to real audio or speaking */}
      <div className="w-full max-w-xs flex flex-col items-center mt-3 z-20">
        <div className="flex items-center justify-center gap-[3px] h-9 px-4">
          {waveHeights.map((h, i) => (
            <div
              key={i}
              className="w-1 rounded-full transition-all duration-75"
              style={{
                height: `${h}px`,
                backgroundColor: stateConfig.color,
                opacity: voiceLevel > 0 || state === 'SPEAKING' ? 0.95 : 0.35,
                boxShadow:
                  voiceLevel > 0 || state === 'SPEAKING'
                    ? `0 0 6px ${stateConfig.color}`
                    : 'none',
              }}
            />
          ))}
        </div>

        {/* State Badge with High-Tech Status Dot */}
        <div className="flex items-center gap-2 mt-2">
          <div
            className={`px-3 py-1 rounded-full text-[11px] font-mono font-bold tracking-widest border flex items-center gap-2 transition-all ${stateConfig.badgeBg}`}
          >
            <span
              className="w-2 h-2 rounded-full animate-ping shrink-0"
              style={{ backgroundColor: stateConfig.color }}
            />
            <span>{stateConfig.label}</span>
          </div>
        </div>

        {/* Spoken phrase / Assistant subtext */}
        <p className="text-sm font-sans font-medium text-slate-300 text-center mt-2.5 px-4 min-h-[1.5rem] tracking-wide transition-opacity duration-300">
          {stateConfig.sub}
        </p>
      </div>
    </div>
  );
};
