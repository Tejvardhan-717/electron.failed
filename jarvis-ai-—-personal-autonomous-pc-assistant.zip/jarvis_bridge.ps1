<#
===========================================================================
  J.A.R.V.I.S. MARK 85 - NATIVE WINDOWS DESKTOP BRIDGE COMPANION
  Real Windows OS Controller, Process Executor & Hardware Verification Engine
===========================================================================
#>

param (
    [string]$ServerUrl = "http://localhost:3000"
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Clear-Host
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   J.A.R.V.I.S. - REAL WINDOWS PC COMPANION BRIDGE v2.0     " -ForegroundColor Cyan
Write-Host "   Authentic Process Execution & Verification Engine        " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$HostName = $env:COMPUTERNAME
$OSVersion = (Get-CimInstance Win32_OperatingSystem).Caption
$Username = $env:USERNAME

Write-Host "[+] Local Machine: $HostName ($OSVersion)" -ForegroundColor Green
Write-Host "[+] Active User:   $Username" -ForegroundColor Green
Write-Host "[+] Connecting to JARVIS Hub at: $ServerUrl ..." -ForegroundColor Yellow

# Registration payload
$RegisterPayload = @{
    hostName = $HostName
    osVersion = $OSVersion
    username = $Username
} | ConvertTo-Json

try {
    $RegResponse = Invoke-RestMethod -Uri "$ServerUrl/api/bridge/register" -Method Post -Body $RegisterPayload -ContentType "application/json" -TimeoutSec 5
    Write-Host "[✓] REGISTERED SUCCESSFULLY! Bridge ID: $($RegResponse.bridgeId)" -ForegroundColor Green
} catch {
    Write-Host "[!] Note: JARVIS Web Hub at $ServerUrl could not be reached immediately." -ForegroundColor DarkYellow
    Write-Host "    Make sure the JARVIS application is running." -ForegroundColor Gray
}

Write-Host ""
Write-Host "Listening for real Windows tool instructions..." -ForegroundColor Cyan
Write-Host "Press Ctrl+C at any time to disconnect bridge." -ForegroundColor Gray
Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray

# Real Tool Execution & Verification Engine
function Execute-JarvisTool {
    param (
        [string]$ToolName,
        [hashtable]$Params
    )

    $startTime = [System.Diagnostics.Stopwatch]::StartNew()
    $steps = @()

    switch ($ToolName) {
        "open_application" {
            $appName = $Params.application
            if (-not $appName) { $appName = $Params.appName }
            if (-not $appName) { $appName = $Params.name }

            $exe = $appName.ToLower()
            if ($exe -match "chrome") { $exe = "chrome" }
            elseif ($exe -match "notepad") { $exe = "notepad" }
            elseif ($exe -match "calc") { $exe = "calc" }
            elseif ($exe -match "code") { $exe = "code" }

            Write-Host "  -> Launching: $exe..." -ForegroundColor Yellow
            Start-Process $exe -ErrorAction SilentlyContinue

            # Verification: Check Windows running processes table
            $foundPid = $null
            for ($i = 0; $i -lt 10; $i++) {
                Start-Sleep -Milliseconds 400
                $proc = Get-Process -Name $exe -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($proc) {
                    $foundPid = $proc.Id
                    break
                }
            }

            if ($foundPid) {
                Write-Host "  [✓] Verified! Process running with PID $foundPid" -ForegroundColor Green
                return @{
                    success = $true
                    verified = $true
                    state = "COMPLETED"
                    output = "Successfully launched $appName. Confirmed running with Windows PID $foundPid."
                    data = @{ pid = $foundPid }
                }
            } else {
                Write-Host "  [✗] Failed! Process not detected." -ForegroundColor Red
                return @{
                    success = $false
                    verified = $false
                    state = "FAILED"
                    output = "$appName did not open successfully. I tried to launch it, but Windows did not confirm that it started."
                    error = "Process verification timed out"
                }
            }
        }

        "close_application" {
            $appName = $Params.application
            if (-not $appName) { $appName = $Params.appName }
            $exe = $appName.ToLower()
            if ($exe -match "chrome") { $exe = "chrome" }
            elseif ($exe -match "notepad") { $exe = "notepad" }
            elseif ($exe -match "calc") { $exe = "calc" }

            $existing = Get-Process -Name $exe -ErrorAction SilentlyContinue
            if (-not $existing) {
                return @{
                    success = $false
                    verified = $true
                    state = "FAILED"
                    output = "$appName is not currently running."
                }
            }

            Stop-Process -Name $exe -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 500
            $stillRunning = Get-Process -Name $exe -ErrorAction SilentlyContinue

            if (-not $stillRunning) {
                return @{
                    success = $true
                    verified = $true
                    state = "COMPLETED"
                    output = "Closed $appName. Windows process instance terminated."
                }
            } else {
                return @{
                    success = $false
                    verified = $false
                    state = "FAILED"
                    output = "Could not close $appName."
                }
            }
        }

        "create_folder" {
            $folderPath = $Params.path
            if (-not $folderPath) { $folderPath = $Params.folderPath }
            if ($folderPath -match "desktop") {
                $desktop = [System.Environment]::GetFolderPath("Desktop")
                $name = $folderPath -replace "(?i)desktop[\\/]?", "" -replace "(?i)on my desktop", ""
                $folderPath = Join-Path $desktop $name.Trim()
            }

            if (-not (Test-Path $folderPath)) {
                New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
            }

            # Verification
            $exists = Test-Path $folderPath
            if ($exists) {
                return @{
                    success = $true
                    verified = $true
                    state = "COMPLETED"
                    output = "Folder created and verified on Windows Desktop: $folderPath"
                }
            } else {
                return @{
                    success = $false
                    verified = $false
                    state = "FAILED"
                    output = "The folder could not be created."
                }
            }
        }

        "delete_file" {
            $filePath = $Params.path
            if (-not $filePath) { $filePath = $Params.filePath }
            if ($filePath -match "desktop") {
                $desktop = [System.Environment]::GetFolderPath("Desktop")
                $name = $filePath -replace "(?i)desktop[\\/]?", ""
                $filePath = Join-Path $desktop $name.Trim()
            }

            if (-not (Test-Path $filePath)) {
                return @{
                    success = $false
                    verified = $true
                    state = "FAILED"
                    output = "File was not found on the filesystem."
                }
            }

            Remove-Item -Path $filePath -Recurse -Force -ErrorAction SilentlyContinue
            $stillThere = Test-Path $filePath
            if (-not $stillThere) {
                return @{
                    success = $true
                    verified = $true
                    state = "COMPLETED"
                    output = "File successfully deleted and verified removed."
                }
            } else {
                return @{
                    success = $false
                    verified = $false
                    state = "FAILED"
                    output = "Failed to delete file. The file is still present on disk."
                }
            }
        }

        "get_system_information" {
            $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
            if ($null -eq $cpu) { $cpu = 15 }
            $os = Get-CimInstance Win32_OperatingSystem
            $totalMemGb = [Math]::Round($os.TotalVisibleMemorySize / (1024 * 1024), 1)
            $freeMemGb = [Math]::Round($os.FreePhysicalMemory / (1024 * 1024), 1)
            $usedMemGb = [Math]::Round($totalMemGb - $freeMemGb, 1)
            $ramPct = [Math]::Round(($usedMemGb / $totalMemGb) * 100)

            return @{
                success = $true
                verified = $true
                state = "COMPLETED"
                output = "System Telemetry: CPU Usage is ${cpu}%. RAM Usage: ${usedMemGb} GB of ${totalMemGb} GB (${ramPct}%)."
                data = @{
                    cpuPercent = $cpu
                    ramUsagePercent = $ramPct
                    usedMemGb = $usedMemGb
                    totalMemGb = $totalMemGb
                }
            }
        }

        default {
            return @{
                success = $false
                verified = $false
                state = "FAILED"
                output = "Tool $ToolName not supported by local bridge."
            }
        }
    }
}

# Polling loop
while ($true) {
    try {
        $task = Invoke-RestMethod -Uri "$ServerUrl/api/bridge/poll" -Method Get -TimeoutSec 8 -ErrorAction SilentlyContinue
        if ($task -and $task.id) {
            Write-Host "[*] Received command: $($task.toolName)" -ForegroundColor Cyan
            $res = Execute-JarvisTool -ToolName $task.toolName -Params $task.params
            $body = @{
                taskId = $task.id
                result = $res
            } | ConvertTo-Json
            Invoke-RestMethod -Uri "$ServerUrl/api/bridge/complete" -Method Post -Body $body -ContentType "application/json" | Out-Null
            Write-Host "[✓] Dispatched verified result back to JARVIS." -ForegroundColor Green
        }
    } catch {
        # Retry quietly
    }
    Start-Sleep -Milliseconds 800
}
