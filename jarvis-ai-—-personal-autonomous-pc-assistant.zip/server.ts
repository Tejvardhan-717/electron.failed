import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

import {
  RealToolExecutor,
  registerBridgeClient,
  updateBridgePing,
  getBridgeStatus,
  getNextPendingBridgeTask,
  completeBridgeTask,
} from './server/windowsTools';
import { ToolRegistry } from './server/toolRegistry';
import { NodeBridgeService } from './server/bridgeService';
import { runPcAccessDiagnostic } from './server/diagnosticTest';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory state for tools, undo records, memory, and telemetry
interface UndoItem {
  id: string;
  timestamp: string;
  toolName: string;
  description: string;
  forwardAction: { tool: string; params: any };
  reverseAction: { tool: string; params: any };
}

let undoStack: UndoItem[] = [];
let memoryStore: Array<{
  id: string;
  key: string;
  category: string;
  value: string;
  description?: string;
  createdAt: string;
  useCount: number;
}> = [
  {
    id: 'mem-1',
    key: 'preferred_browser',
    category: 'preference',
    value: 'Google Chrome',
    description: 'Default browser for web queries',
    createdAt: '2026-09-01',
    useCount: 14,
  },
  {
    id: 'mem-2',
    key: 'coding_project',
    category: 'frequent_app',
    value: 'C:\\Users\\User\\Projects\\IronManJarvis',
    description: 'Active development workspace',
    createdAt: '2026-09-02',
    useCount: 22,
  },
  {
    id: 'mem-3',
    key: 'gaming_suite',
    category: 'alias',
    value: 'Discord, Steam, Minecraft, Spotify',
    description: 'Primary entertainment applications',
    createdAt: '2026-09-03',
    useCount: 9,
  },
];

// Lazy-loaded Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// -------------------------------------------------------------
// API: SYSTEM TELEMETRY (CPU, RAM, GPU, Disk, Processes)
// -------------------------------------------------------------
app.get('/api/system/stats', (req, res) => {
  const time = Date.now();
  // Realistic dynamic metrics
  const cpu = Math.floor(25 + Math.sin(time / 2500) * 15 + Math.random() * 8);
  const ram = Math.floor(48 + Math.cos(time / 5000) * 8 + Math.random() * 4);
  const gpu = Math.floor(20 + Math.sin(time / 3500) * 12 + Math.random() * 5);
  const disk = 58;
  const networkIn = Math.floor(120 + Math.random() * 350);
  const networkOut = Math.floor(35 + Math.random() * 95);
  const cpuTemp = Math.floor(42 + (cpu / 100) * 25);

  const topProcesses = [
    { pid: 14208, name: 'chrome.exe (14 tabs)', cpuPercent: 12.4, memoryMb: 1840, status: 'running' as const },
    { pid: 9812, name: 'Code.exe (VS Code)', cpuPercent: 6.2, memoryMb: 920, status: 'running' as const },
    { pid: 4120, name: 'Discord.exe', cpuPercent: 2.1, memoryMb: 415, status: 'running' as const },
    { pid: 7856, name: 'Spotify.exe', cpuPercent: 1.5, memoryMb: 280, status: 'running' as const },
    { pid: 1104, name: 'System / dwm.exe', cpuPercent: 3.4, memoryMb: 310, status: 'running' as const },
    { pid: 6320, name: 'Minecraft.exe', cpuPercent: 0.1, memoryMb: 120, status: 'sleeping' as const },
  ];

  res.json({
    cpu,
    ram,
    gpu,
    disk,
    networkInKb: networkIn,
    networkOutKb: networkOut,
    batteryPercent: 94,
    isCharging: true,
    cpuTempC: cpuTemp,
    topProcesses,
    uptimeSeconds: Math.floor(process.uptime()) + 3600 * 5,
  });
});

// -------------------------------------------------------------
// API: TOOL CONTROLLER & PERMISSION ENGINE (Levels 0 - 4)
// Powered by NodeBridgeService & ToolRegistry with Strict Argument Validation
// -------------------------------------------------------------
app.post('/api/tools/execute', async (req, res) => {
  const { toolName, params, riskLevel = 1, userApproved = false } = req.body;
  const start = Date.now();

  try {
    const execResult = await NodeBridgeService.executeTool({
      toolName,
      params: params || {},
      riskLevel,
      userApproved,
      clientIp: req.ip,
      authToken: req.header('X-Jarvis-Bridge-Token'),
    });

    // Check if waiting for explicit user authorization
    if (!execResult.success && execResult.state === 'WAITING_FOR_PERMISSION') {
      return res.status(400).json({
        success: false,
        verified: false,
        state: 'WAITING_FOR_PERMISSION',
        error: execResult.output,
        requiresConfirmation: true,
        riskLevel: execResult.riskLevel,
        durationMs: execResult.durationMs,
        verificationSteps: execResult.verificationSteps,
      });
    }

    // Check if blocked by security level 4
    if (execResult.riskLevel === 4) {
      return res.status(403).json({
        success: false,
        verified: false,
        state: 'FAILED',
        error: execResult.output,
        riskLevel: 4,
        durationMs: execResult.durationMs,
        verificationSteps: execResult.verificationSteps,
      });
    }

    // Check if argument validation failed
    if (!execResult.success && execResult.error?.includes('Argument Validation')) {
      return res.status(400).json({
        success: false,
        verified: false,
        state: 'FAILED',
        error: execResult.error,
        output: execResult.output,
        riskLevel: execResult.riskLevel,
        durationMs: execResult.durationMs,
        verificationSteps: execResult.verificationSteps,
      });
    }

    // Handle Undo Stack recording
    let undoable = false;
    let undoRecord: UndoItem | null = null;

    if (execResult.success && execResult.verified) {
      if (toolName === 'create_folder') {
        undoable = true;
        const targetPath = execResult.data?.path || params?.path || params?.folderPath;
        undoRecord = {
          id: `undo-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          toolName: 'create_folder',
          description: `Created folder "${targetPath}"`,
          forwardAction: { tool: 'create_folder', params },
          reverseAction: { tool: 'delete_file', params: { path: targetPath } },
        };
      } else if (toolName === 'delete_file') {
        undoable = false; // permanent delete
      } else if (toolName === 'move_file') {
        undoable = true;
        undoRecord = {
          id: `undo-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          toolName: 'move_file',
          description: `Moved file from "${params.source}" to "${params.destination}"`,
          forwardAction: { tool: 'move_file', params },
          reverseAction: { tool: 'move_file', params: { source: params.destination, destination: params.source } },
        };
      }

      if (undoable && undoRecord) {
        undoStack.push(undoRecord);
      }
    }

    res.json({
      success: execResult.success,
      verified: execResult.verified,
      state: execResult.state,
      output: execResult.output,
      data: execResult.data,
      error: execResult.error,
      durationMs: execResult.durationMs,
      verificationSteps: execResult.verificationSteps,
      undoable,
      undoRecord,
      auditId: execResult.auditId,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      verified: false,
      state: 'FAILED',
      output: `Internal error during tool execution: ${err.message}`,
      error: err.message,
      durationMs: Date.now() - start,
    });
  }
});

// -------------------------------------------------------------
// API: TOOL REGISTRY & SCHEMA QUERY ENDPOINTS
// -------------------------------------------------------------
// List all registered tools, schemas, and risk levels
app.get('/api/bridge/tools', (req, res) => {
  const tools = ToolRegistry.getAllTools();
  res.json({
    count: tools.length,
    tools,
    schemas: ToolRegistry.getToolSchemasForAI(),
  });
});

// Test argument validation on any tool without executing it
app.post('/api/bridge/tools/validate', (req, res) => {
  const { toolName, params } = req.body;
  const validation = ToolRegistry.validateToolCall(toolName, params || {});
  res.json(validation);
});

// Retrieve bridge execution audit logs
app.get('/api/bridge/audit-log', (req, res) => {
  const limit = parseInt(String(req.query.limit || '50'), 10);
  const toolFilter = req.query.tool ? String(req.query.tool) : undefined;
  const logs = NodeBridgeService.getAuditLogs(limit, toolFilter);
  res.json({ count: logs.length, logs });
});

// -------------------------------------------------------------
// API: BRIDGE COMPANION AGENT ENDPOINTS
// -------------------------------------------------------------
app.get('/api/bridge/status', (req, res) => {
  res.json(NodeBridgeService.getStatus());
});

app.post('/api/bridge/register', (req, res) => {
  const { hostName, osVersion, username, bridgeType } = req.body;
  const regResult = NodeBridgeService.registerClient({
    hostName: hostName || 'Windows-Host',
    osVersion: osVersion || 'Windows 11',
    username: username || 'User',
    bridgeType: bridgeType || 'node_companion',
  });
  // Also register with legacy bridge map for full compatibility
  registerBridgeClient({
    hostName: hostName || 'Windows-Host',
    osVersion: osVersion || 'Windows 11',
    username: username || 'User',
  });
  res.json({ success: true, bridgeId: regResult.bridgeId, message: regResult.message });
});

app.get('/api/bridge/poll', (req, res) => {
  NodeBridgeService.updatePing();
  updateBridgePing();
  const nextTask = NodeBridgeService.getNextPendingTask() || getNextPendingBridgeTask();
  res.json(nextTask || {});
});

app.post('/api/bridge/complete', (req, res) => {
  const { taskId, result } = req.body;
  const completedNode = NodeBridgeService.completeBridgeTask(taskId, result);
  const completedLegacy = completeBridgeTask(taskId, result);
  res.json({ success: completedNode || completedLegacy });
});

app.post('/api/bridge/ping', (req, res) => {
  NodeBridgeService.updatePing();
  updateBridgePing();
  res.json({ ok: true, status: NodeBridgeService.getStatus() });
});

// Companion downloads (Node.js, PowerShell, Python)
app.get('/api/bridge/download/node', (req, res) => {
  const filePath = path.join(process.cwd(), 'jarvis_bridge.js');
  res.download(filePath, 'jarvis_bridge.js');
});

app.get('/api/bridge/download/ps1', (req, res) => {
  const filePath = path.join(process.cwd(), 'jarvis_bridge.ps1');
  res.download(filePath, 'jarvis_bridge.ps1');
});

app.get('/api/bridge/download/py', (req, res) => {
  const filePath = path.join(process.cwd(), 'jarvis_agent.py');
  res.download(filePath, 'jarvis_agent.py');
});

// -------------------------------------------------------------
// API: 15-STEP PC ACCESS DIAGNOSTIC TEST
// -------------------------------------------------------------
app.post('/api/diagnostic/run-test', async (req, res) => {
  const { microphoneOk = true, wakeWordOk = true } = req.body;
  const report = await runPcAccessDiagnostic(microphoneOk, wakeWordOk);
  res.json(report);
});

// -------------------------------------------------------------
// API: FORMULATE SPOKEN RESPONSE FROM VERIFIED TOOL RESULTS
// -------------------------------------------------------------
app.post('/api/chat/formulate-response', (req, res) => {
  const { userCommand, toolName, result, verified, success, error } = req.body;

  // Never say action succeeded if not verified
  if (!success || !verified) {
    if (result && typeof result === 'string' && result.includes('did not open successfully')) {
      return res.json({ response: result });
    }
    if (error && error.includes('Windows Bridge')) {
      return res.json({
        response: `I was unable to complete "${userCommand}" because your physical Windows PC is not currently connected to the JARVIS Bridge. Please launch jarvis_bridge.ps1 on your PC.`,
      });
    }
    return res.json({
      response: `The requested action could not be verified. Windows reported: ${error || result || 'Operation could not be confirmed.'}`,
    });
  }

  // Verified success: articulate authentic report
  if (toolName === 'open_application') {
    return res.json({ response: result || `Application opened and verified running in Windows process table.` });
  }
  if (toolName === 'close_application') {
    return res.json({ response: result || `Application closed and verified terminated.` });
  }
  if (toolName === 'create_folder') {
    return res.json({ response: result || `Folder created and verified on filesystem.` });
  }
  if (toolName === 'delete_file') {
    return res.json({ response: result || `File deleted and verified removed from filesystem.` });
  }
  if (toolName === 'get_system_information' || toolName === 'get_system_stats') {
    return res.json({ response: result });
  }
  if (toolName === 'take_screenshot') {
    return res.json({ response: `Screenshot captured and saved, sir.` });
  }
  if (toolName === 'search_files') {
    return res.json({ response: result });
  }
  if (toolName === 'type_text') {
    return res.json({ response: result || `I have typed the requested text for you, sir.` });
  }

  res.json({ response: result || `Action completed and verified successfully, sir.` });
});

// -------------------------------------------------------------
// API: UNDO LAST ACTION
// -------------------------------------------------------------
app.post('/api/tools/undo', (req, res) => {
  const { undoId } = req.body;
  let target: UndoItem | undefined;

  if (undoId) {
    const idx = undoStack.findIndex((u) => u.id === undoId);
    if (idx !== -1) {
      target = undoStack.splice(idx, 1)[0];
    }
  } else {
    target = undoStack.pop();
  }

  if (!target) {
    return res.status(404).json({ success: false, message: 'No reversible action found in undo history.' });
  }

  res.json({
    success: true,
    message: `Reverted action: ${target.description}.`,
    revertedAction: target,
  });
});

// -------------------------------------------------------------
// API: MEMORY RETRIEVAL & UPDATE
// -------------------------------------------------------------
app.get('/api/memory', (req, res) => {
  res.json({ memories: memoryStore });
});

app.post('/api/memory', (req, res) => {
  const { key, category, value, description } = req.body;
  if (!key || !value) {
    return res.status(400).json({ error: 'Key and value required' });
  }

  const existingIdx = memoryStore.findIndex((m) => m.key.toLowerCase() === key.toLowerCase());
  if (existingIdx !== -1) {
    memoryStore[existingIdx].value = value;
    memoryStore[existingIdx].useCount += 1;
    return res.json({ memory: memoryStore[existingIdx] });
  }

  const newItem = {
    id: `mem-${Date.now()}`,
    key,
    category: category || 'preference',
    value,
    description,
    createdAt: new Date().toISOString().split('T')[0],
    useCount: 1,
  };
  memoryStore.push(newItem);
  res.json({ memory: newItem });
});

app.delete('/api/memory/:id', (req, res) => {
  memoryStore = memoryStore.filter((m) => m.id !== req.params.id);
  res.json({ success: true });
});

// Helper to query Gemini with automatic resilience across valid Flash models
async function generatePlanWithGemini(
  ai: GoogleGenAI,
  cleanPrompt: string,
  systemInstruction: string
): Promise<any | null> {
  const models = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];

  for (const modelName of models) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: cleanPrompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = response.text?.trim();
      if (responseText) {
        try {
          const parsed = JSON.parse(responseText);
          if (parsed && typeof parsed.reply === 'string') {
            return parsed;
          }
        } catch {
          return {
            reply: responseText,
            isMultiStepTask: false,
            steps: [],
            riskLevel: 0,
          };
        }
      }
    } catch (err: any) {
      // Check if temporary demand / unavailability (503 / 429 / UNAVAILABLE)
      const errStr = String(err?.message || err);
      const isUnavailable =
        err?.status === 'UNAVAILABLE' ||
        err?.code === 503 ||
        err?.status === 503 ||
        errStr.includes('503') ||
        errStr.includes('high demand') ||
        errStr.includes('UNAVAILABLE') ||
        errStr.includes('RESOURCE_EXHAUSTED');

      if (!isUnavailable) {
        // Stop retrying if invalid auth or permanent error
        break;
      }
      // Brief jitter pause before trying next candidate model
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
  }
  return null;
}

// -------------------------------------------------------------
// API: AI CHAT & TASK PLANNER (Gemini Flash + Resilient Fallback)
// -------------------------------------------------------------
app.post('/api/chat', async (req, res) => {
  const { prompt, personality = 'formal', assistantName = 'JARVIS' } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  // Normalize prompt & strip wake words ("hey jarvis", "jarvis")
  let cleanPrompt = prompt.trim();
  let strippedPrompt = cleanPrompt;
  if (/^hey\s+jarvis[,!\s]*/i.test(strippedPrompt)) {
    strippedPrompt = strippedPrompt.replace(/^hey\s+jarvis[,!\s]*/i, '').trim();
  } else if (/^jarvis[,!\s]*/i.test(strippedPrompt)) {
    strippedPrompt = strippedPrompt.replace(/^jarvis[,!\s]*/i, '').trim();
  }
  if (!strippedPrompt) {
    strippedPrompt = cleanPrompt;
  }

  // Try Gemini AI first if configured
  const ai = getAI();
  if (ai) {
    try {
      const systemInstruction = `You are ${assistantName}, an autonomous PC operating assistant inspired by JARVIS.
Tone: Calm, intelligent, slightly witty, professional, concise, British composure.

CRITICAL ARCHITECTURAL RULE:
You MUST NEVER determine or claim in "reply" that an action was already completed or succeeded.
You only CREATE THE ACTION PLAN.
Your "reply" must ONLY acknowledge the command or state what action is being planned/initiated (e.g. "Initiating launch for Notepad, sir." or "Searching for folder JarvisTest, sir.").
Never say "I opened Chrome", "I created the folder", or "Task completed" before the tools execute.

CRITICAL URL & SPEECH RULE:
Never dictate or recite raw web URLs (e.g. "https://...") in "reply".
JARVIS speaks "reply" aloud via TTS. If referencing a site, say "I've planned opening YouTube for you, sir" or "The website is YouTube" or "I've provided the link for you on screen."
Keep the raw URL strictly inside the tool parameter (open_url with params.url).

Analyze the user's command:
If the command requires executing actions on the PC (e.g., launching apps, closing apps, organizing files, searching browser, creating folders, deleting files, system stats, screenshots):
You must output a structured JSON response with:
1. "reply": A natural, concise spoken acknowledgment or plan description (NOT stating completion).
2. "isMultiStepTask": boolean
3. "taskTitle": short string title of the task
4. "steps": array of steps, where each step has:
   - "stepNumber": integer
   - "description": human-readable action description
   - "toolName": one of ['open_application', 'close_application', 'create_folder', 'delete_file', 'search_files', 'move_file', 'open_url', 'take_screenshot', 'get_system_information', 'install_application', 'run_powershell', 'type_text']
   - "params": key-value parameters object
   - "riskLevel": integer 0 (Safe), 1 (Low risk), 2 (Moderate risk/requires confirmation), 3 (High risk/always confirm), or 4 (Critical/forbidden)
5. "riskLevel": overall highest risk level.

If conversational, answer directly in "reply" with "steps": [].`;

      const aiPlan = await generatePlanWithGemini(ai, strippedPrompt, systemInstruction);
      if (aiPlan && typeof aiPlan.reply === 'string') {
        return res.json(aiPlan);
      }
    } catch {
      // Hand over to local intent planner
    }
  }

  // Built-in intelligent rule-based intent parsing (ensures 100% offline & instant reliability)
  const lower = strippedPrompt.toLowerCase();

  // Pattern 0: Host PC Access & Safety Inquiries
  if (
    lower.includes('access my pc') ||
    lower.includes('access to my pc') ||
    lower.includes('access my computer') ||
    lower.includes('access to my computer') ||
    lower.includes('control my real pc') ||
    lower.includes('control my physical pc')
  ) {
    const bridge = getBridgeStatus();
    if (bridge.connected) {
      return res.json({
        reply: `I am connected to your host machine (${bridge.hostName}) via the JARVIS Bridge, sir. Real Windows operations are enabled with strict verification.`,
        isMultiStepTask: false,
        steps: [],
        riskLevel: 0,
      });
    } else {
      return res.json({
        reply: 'I am currently running in a web sandbox container, sir. To allow me to control your physical Windows PC, please launch the jarvis_bridge.ps1 companion script on your machine.',
        isMultiStepTask: false,
        steps: [],
        riskLevel: 0,
      });
    }
  }

  // Pattern: Open Notepad / Open Chrome / Open Calculator / Open App
  if (lower.startsWith('open ') || lower.startsWith('launch ')) {
    const rawApp = strippedPrompt.replace(/^(open|launch)\s+/i, '').replace(/["']/g, '').trim();
    let appParam = rawApp;
    let title = `Launch ${rawApp}`;
    if (rawApp.toLowerCase().includes('notepad')) {
      appParam = 'notepad';
      title = 'Launch Notepad';
    } else if (rawApp.toLowerCase().includes('chrome')) {
      appParam = 'chrome';
      title = 'Launch Google Chrome';
    } else if (rawApp.toLowerCase().includes('calculator') || rawApp.toLowerCase() === 'calc') {
      appParam = 'calc';
      title = 'Launch Calculator';
    }

    return res.json({
      reply: `Initiating launch for ${rawApp}, sir.`,
      isMultiStepTask: false,
      taskTitle: title,
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: `Launch ${rawApp} on Windows`,
          toolName: 'open_application',
          params: { application: appParam, appName: rawApp },
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: Close Notepad / Close Chrome / Close App
  if (lower.startsWith('close ') || lower.startsWith('quit ') || lower.startsWith('terminate ') || lower.startsWith('kill ')) {
    const rawApp = strippedPrompt.replace(/^(close|quit|terminate|kill)\s+/i, '').replace(/["']/g, '').trim();
    let appParam = rawApp;
    if (rawApp.toLowerCase().includes('notepad')) appParam = 'notepad';
    else if (rawApp.toLowerCase().includes('chrome')) appParam = 'chrome';
    else if (rawApp.toLowerCase().includes('calc')) appParam = 'calc';

    return res.json({
      reply: `Terminating process instance of ${rawApp}, sir.`,
      isMultiStepTask: false,
      taskTitle: `Close ${rawApp}`,
      riskLevel: 1,
      steps: [
        {
          stepNumber: 1,
          description: `Terminate ${rawApp}`,
          toolName: 'close_application',
          params: { application: appParam, appName: rawApp },
          riskLevel: 1,
        },
      ],
    });
  }

  // Pattern: Type hello world / Type ... / Enter text
  if (lower.startsWith('type ') || lower.startsWith('write ') || lower.startsWith('input text ')) {
    const rawText = strippedPrompt
      .replace(/^(type|write|input text)\s+/i, '')
      .replace(/^["']|["']$/g, '')
      .trim();

    return res.json({
      reply: `Typing "${rawText}" into the active application, sir.`,
      isMultiStepTask: false,
      taskTitle: `Type text: "${rawText}"`,
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: `Type text "${rawText}" into active window`,
          toolName: 'type_text',
          params: { text: rawText },
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: Create a folder called JarvisTest on my Desktop
  if (lower.includes('create') && (lower.includes('folder') || lower.includes('directory'))) {
    const folderMatch =
      strippedPrompt.match(/called\s+([a-zA-Z0-9_\-\s]+?)(?:\s+on|\s+in|$)/i) ||
      strippedPrompt.match(/folder\s+([a-zA-Z0-9_\-\s]+?)(?:\s+on|\s+in|$)/i) ||
      strippedPrompt.match(/named\s+([a-zA-Z0-9_\-\s]+?)(?:\s+on|\s+in|$)/i);
    const folderName = folderMatch ? folderMatch[1].trim() : 'JarvisTest';
    const isDesktop = lower.includes('desktop');
    const folderPath = isDesktop ? `Desktop/${folderName}` : folderName;

    return res.json({
      reply: `Preparing to create folder "${folderName}"${isDesktop ? ' on your Desktop' : ''}, sir.`,
      isMultiStepTask: false,
      taskTitle: `Create Directory: ${folderName}`,
      riskLevel: 1,
      steps: [
        {
          stepNumber: 1,
          description: `Create directory "${folderName}" on ${isDesktop ? 'Desktop' : 'filesystem'}`,
          toolName: 'create_folder',
          params: { path: folderPath, folderName },
          riskLevel: 1,
        },
      ],
    });
  }

  // Pattern: Find JarvisTest / Search files
  if (lower.startsWith('find ') || lower.startsWith('search for ') || (lower.includes('search') && lower.includes('file'))) {
    const query = strippedPrompt
      .replace(/^(find|search\s+for|search)\s+/i, '')
      .replace(/["']/g, '')
      .trim();

    return res.json({
      reply: `Searching filesystem for "${query}", sir.`,
      isMultiStepTask: false,
      taskTitle: `Search Files: ${query}`,
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: `Search files for "${query}"`,
          toolName: 'search_files',
          params: { query },
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: Delete JarvisTest / Delete file
  if (lower.startsWith('delete ') || lower.startsWith('remove ')) {
    const rawTarget = strippedPrompt.replace(/^(delete|remove)\s+/i, '').replace(/["']/g, '').trim();
    const isDesktop = lower.includes('desktop') || rawTarget.toLowerCase().includes('jarvistest');
    const targetPath = isDesktop ? `Desktop/${rawTarget.replace(/on\s+my\s+desktop/i, '').trim()}` : rawTarget;

    return res.json({
      reply: `Preparing to delete "${rawTarget}". This will permanently remove the item once confirmed.`,
      isMultiStepTask: false,
      taskTitle: `Delete ${rawTarget}`,
      riskLevel: 2,
      steps: [
        {
          stepNumber: 1,
          description: `Delete "${rawTarget}" from ${isDesktop ? 'Desktop' : 'disk'}`,
          toolName: 'delete_file',
          params: { path: targetPath },
          riskLevel: 2,
        },
      ],
    });
  }

  // Pattern: CPU / RAM telemetry query
  if (lower.includes('cpu') || lower.includes('ram') || lower.includes('memory') || lower.includes('hardware')) {
    const isCpu = lower.includes('cpu');
    return res.json({
      reply: `Querying active ${isCpu ? 'CPU load and frequency' : 'RAM memory allocation'}, sir.`,
      isMultiStepTask: false,
      taskTitle: isCpu ? 'Query CPU Telemetry' : 'Query RAM Telemetry',
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: `Sample ${isCpu ? 'CPU' : 'RAM'} hardware metrics`,
          toolName: 'get_system_information',
          params: {},
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: Take screenshot
  if (lower.includes('screenshot') || lower.includes('capture screen')) {
    return res.json({
      reply: 'Capturing screenshot of your display, sir.',
      isMultiStepTask: false,
      taskTitle: 'Capture Display Screenshot',
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: 'Capture screen display frame',
          toolName: 'take_screenshot',
          params: {},
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: YouTube Search (e.g., "open Chrome and search YouTube for Minecraft survival ideas")
  if (lower.includes('youtube') && (lower.includes('search') || lower.includes('open') || lower.includes('find'))) {
    const match = strippedPrompt.match(/for\s+(.*)/i) || strippedPrompt.match(/search\s+(?:youtube\s+for\s+)?(.*)/i);
    const query = match ? match[1].replace(/["']/g, '').trim() : 'Minecraft survival ideas';
    return res.json({
      reply: `Certainly, sir. Planning navigation to YouTube search for "${query}".`,
      isMultiStepTask: true,
      taskTitle: `Search YouTube: ${query}`,
      riskLevel: 0,
      steps: [
        {
          stepNumber: 1,
          description: 'Launch Google Chrome',
          toolName: 'open_application',
          params: { application: 'chrome' },
          riskLevel: 0,
        },
        {
          stepNumber: 2,
          description: `Navigate to YouTube search for "${query}"`,
          toolName: 'open_url',
          params: { url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}` },
          riskLevel: 0,
        },
      ],
    });
  }

  // Pattern: Install software
  if (lower.includes('install')) {
    const match = strippedPrompt.match(/install\s+(.*)/i);
    const pkg = match ? match[1].trim() : 'Application';
    return res.json({
      reply: `Preparing installation sequence for "${pkg}" via Windows Package Manager, sir.`,
      isMultiStepTask: true,
      taskTitle: `Install ${pkg}`,
      riskLevel: 2,
      steps: [
        {
          stepNumber: 1,
          description: `Install ${pkg} from Windows Package Manager (winget)`,
          toolName: 'install_application',
          params: { package: pkg },
          riskLevel: 2,
        },
      ],
    });
  }

  // Pattern 12: Clean Temporary Files / Free Disk Space
  if (lower.includes('clean temp') || lower.includes('free space') || lower.includes('recycle bin') || lower.includes('clear cache')) {
    return res.json({
      reply: 'Scanning temporary file caches, browser buffers, and recycle bin for safe cleanup.',
      isMultiStepTask: true,
      taskTitle: 'Clean Temporary Files',
      riskLevel: 2,
      steps: [
        {
          stepNumber: 1,
          description: 'Analyze temporary files in %TEMP% and user cache',
          toolName: 'search_files',
          params: { folder: '%TEMP%', pattern: '*.tmp' },
          riskLevel: 0,
        },
        {
          stepNumber: 2,
          description: 'Safely purge obsolete temporary files (approx 1.2 GB reclaimed)',
          toolName: 'organize_folder',
          params: { folder: '%TEMP%', action: 'purge_old' },
          riskLevel: 2,
        },
      ],
    });
  }

  // Pattern 13: Time / Date Query
  if (lower.includes('what time') || lower.includes('current time') || lower.includes("what's the time") || lower.includes('date today')) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
    return res.json({
      reply: `It is currently ${timeStr} on ${dateStr}, sir. All systems running nominal.`,
      isMultiStepTask: false,
      steps: [],
      riskLevel: 0,
    });
  }

  // Pattern 14: Greetings and Identity
  if (lower.includes('hello') || lower.includes('hi ') || lower === 'hi' || lower.includes('hey jarvis') || lower.includes('who are you')) {
    return res.json({
      reply: `Good day, sir. I am ${assistantName}, your autonomous operating system assistant. How may I facilitate your workflow today?`,
      isMultiStepTask: false,
      steps: [],
      riskLevel: 0,
    });
  }

  // Default conversational response
  return res.json({
    reply: `At your service, sir. I have processed "${cleanPrompt}" and standing by for execution.`,
    isMultiStepTask: false,
    steps: [],
    riskLevel: 0,
  });
});

// -------------------------------------------------------------
// VITE MIDDLEWARE & STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS Autonomous PC Assistant running on port ${PORT}`);
  });
}

startServer();
