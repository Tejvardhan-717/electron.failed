import React, { useState } from 'react';
import { ActivityLogItem, RISK_LEVELS } from '../types';
import { History, Trash2, RotateCcw, CheckCircle2, AlertTriangle, XCircle, ShieldAlert, Filter } from 'lucide-react';

interface ActivityLogPanelProps {
  logs: ActivityLogItem[];
  onClearLogs?: () => void;
  onUndoItem?: (undoId: string) => void;
}

export const ActivityLogPanel: React.FC<ActivityLogPanelProps> = ({
  logs,
  onClearLogs,
  onUndoItem,
}) => {
  const [filter, setFilter] = useState<'all' | 'reversible' | 'warnings'>('all');

  const logList = Array.isArray(logs) ? logs : [];

  const filteredLogs = logList.filter((log) => {
    if (filter === 'reversible') return log.reversible && log.undoId;
    if (filter === 'warnings') return log.status === 'warning' || log.status === 'blocked';
    return true;
  });

  return (
    <div
      id="jarvis-activity-log-panel"
      className="bg-[#0b0f17]/90 border border-white/10 rounded-xl p-4 backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.45)] flex flex-col h-full overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase">
            ACTIVITY AUDIT TRAIL
          </span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#070a10] text-cyan-400 border border-cyan-500/20">
            {logList.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick filter pills */}
          <div className="flex items-center gap-1 bg-[#070a10] p-0.5 rounded-lg border border-white/10 text-[10px] font-mono">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-0.5 rounded ${filter === 'all' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              ALL
            </button>
            <button
              onClick={() => setFilter('reversible')}
              className={`px-2 py-0.5 rounded ${filter === 'reversible' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              UNDOABLE
            </button>
          </div>

          {onClearLogs && logs.length > 0 && (
            <button
              onClick={onClearLogs}
              title="Clear activity log"
              className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-[#070a10] transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Logs List */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-0">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center h-36 text-slate-500 text-xs font-mono">
            <History className="w-6 h-6 mb-1 opacity-30" />
            <span>No activity entries logged yet.</span>
          </div>
        ) : (
          filteredLogs.map((log) => {
            const risk = RISK_LEVELS[log.riskLevel];

            return (
              <div
                key={log.id}
                className="p-2.5 rounded-lg bg-[#070a10]/80 border border-white/5 hover:border-cyan-500/20 transition-all font-mono text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="text-cyan-400/80">{log.timestamp}</span>
                  <div className="flex items-center gap-1.5">
                    <span className={`px-1.5 py-0.2 rounded border ${risk.badgeBg} ${risk.badgeColor}`}>
                      L{log.riskLevel}
                    </span>
                    {log.status === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    {log.status === 'warning' && <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
                    {log.status === 'blocked' && <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />}
                    {log.status === 'error' && <XCircle className="w-3.5 h-3.5 text-rose-400" />}
                  </div>
                </div>

                {log.userCommand && (
                  <div className="text-slate-200">
                    <span className="text-slate-400 font-medium">User: </span>
                    &ldquo;{log.userCommand}&rdquo;
                  </div>
                )}

                <div className="text-slate-300 text-[11px] bg-[#0c1322]/70 p-1.5 rounded border border-white/5">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-300 font-semibold">{log.toolName ? `${log.toolName}()` : 'JARVIS:'}</span>
                    {log.reversible && log.undoId && onUndoItem && (
                      <button
                        onClick={() => onUndoItem(log.undoId!)}
                        className="flex items-center gap-1 text-[10px] text-amber-300 hover:text-amber-200 hover:underline"
                      >
                        <RotateCcw className="w-3 h-3" /> Undo
                      </button>
                    )}
                  </div>
                  <p className="mt-0.5 text-slate-300/90 leading-relaxed">{log.details}</p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
