import React from 'react';
import { SystemMetrics } from '../types';
import { Cpu, HardDrive, Wifi, Battery, Zap, Activity, Flame, ShieldAlert, Check } from 'lucide-react';

interface SystemMonitorProps {
  metrics: SystemMetrics;
  onKillProcess?: (pid: number) => void;
  accentColor?: 'cyan' | 'amber' | 'emerald' | 'crimson';
}

export const SystemMonitor: React.FC<SystemMonitorProps> = ({
  metrics,
  onKillProcess,
  accentColor = 'cyan',
}) => {
  const getLoadColor = (value: number) => {
    if (value > 85) return 'text-rose-400 bg-rose-500';
    if (value > 65) return 'text-amber-400 bg-amber-500';
    return 'text-sky-400 bg-sky-500';
  };

  return (
    <div
      id="jarvis-system-monitor-panel"
      className="bg-[#0b0f17]/90 border border-white/10 rounded-xl p-4 backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.45)] flex flex-col h-full overflow-hidden"
    >
      {/* Header with high-tech badge */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase">
            SYSTEM TELEMETRY
          </span>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span className="text-[9px] font-mono text-cyan-300 font-semibold uppercase">SANDBOX (NO PC ACCESS)</span>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5 mb-3">
        {/* CPU */}
        <div className="bg-[#070a10]/80 border border-white/5 hover:border-cyan-500/25 rounded-lg p-2.5 transition-all">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-1">
            <span className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" /> CPU LOAD
            </span>
            <span className="font-bold text-cyan-300">{metrics.cpu}%</span>
          </div>
          <div className="w-full bg-[#131b2b] rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${getLoadColor(metrics.cpu).split(' ')[1]}`}
              style={{ width: `${Math.min(metrics.cpu, 100)}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1 text-[9px] font-mono text-slate-400">
            <span>TEMP: {metrics.cpuTempC}°C</span>
            <span>UP: {Math.floor(metrics.uptimeSeconds / 3600)}h</span>
          </div>
        </div>

        {/* RAM */}
        <div className="bg-[#070a10]/80 border border-white/5 hover:border-cyan-500/25 rounded-lg p-2.5 transition-all">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-1">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-cyan-400" /> RAM USAGE
            </span>
            <span className="font-bold text-cyan-300">{metrics.ram}%</span>
          </div>
          <div className="w-full bg-[#131b2b] rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${getLoadColor(metrics.ram).split(' ')[1]}`}
              style={{ width: `${Math.min(metrics.ram, 100)}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1 text-[9px] font-mono text-slate-400">
            <span>USED: {((metrics.ram / 100) * 32).toFixed(1)} GB</span>
            <span>TOTAL: 32 GB</span>
          </div>
        </div>

        {/* GPU */}
        <div className="bg-[#070a10]/80 border border-white/5 hover:border-amber-500/25 rounded-lg p-2.5 transition-all">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-1">
            <span className="flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" /> GPU RTX
            </span>
            <span className="font-bold text-amber-300">{metrics.gpu}%</span>
          </div>
          <div className="w-full bg-[#131b2b] rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${getLoadColor(metrics.gpu).split(' ')[1]}`}
              style={{ width: `${Math.min(metrics.gpu, 100)}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1 text-[9px] font-mono text-slate-400">
            <span>VRAM: {((metrics.gpu / 100) * 16).toFixed(1)} GB</span>
            <span>DLSS: ON</span>
          </div>
        </div>

        {/* DISK */}
        <div className="bg-[#070a10]/80 border border-white/5 hover:border-emerald-500/25 rounded-lg p-2.5 transition-all">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-1">
            <span className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-emerald-400" /> NVMe C:
            </span>
            <span className="font-bold text-emerald-300">{metrics.disk}%</span>
          </div>
          <div className="w-full bg-[#131b2b] rounded-full h-1.5 overflow-hidden">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${Math.min(metrics.disk, 100)}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1 text-[9px] font-mono text-slate-400">
            <span>FREE: 412 GB</span>
            <span>HEALTH: 100%</span>
          </div>
        </div>
      </div>

      {/* Network & Battery Status Row */}
      <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-[#070a10]/70 border border-white/5 text-[11px] font-mono mb-3">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Wifi className="w-3.5 h-3.5 text-cyan-400" />
          <span>NET: ↓{metrics.networkInKb} KB/s ↑{metrics.networkOutKb} KB/s</span>
        </div>
        <div className="flex items-center gap-1.5 text-slate-300">
          <Battery className="w-3.5 h-3.5 text-emerald-400" />
          <span>BAT: {metrics.batteryPercent}% {metrics.isCharging ? '(AC)' : ''}</span>
        </div>
      </div>

      {/* Running Processes List */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-between text-[10px] font-mono text-cyan-400/80 uppercase pb-1 mb-1 border-b border-white/5">
          <span>ACTIVE PROCESS</span>
          <span>PID / CPU / RAM</span>
        </div>
        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
          {(metrics.topProcesses || []).map((proc) => (
            <div
              key={proc.pid}
              className="group flex items-center justify-between p-1.5 rounded bg-[#070a10]/60 hover:bg-[#0e1626]/80 border border-transparent hover:border-cyan-500/20 text-xs font-mono transition-colors"
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 group-hover:bg-cyan-400" />
                <span className="truncate text-slate-200 font-medium">{proc.name}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] text-slate-400">{proc.cpuPercent}%</span>
                <span className="text-[10px] text-cyan-300/80">{proc.memoryMb}MB</span>
                {onKillProcess && (
                  <button
                    onClick={() => onKillProcess(proc.pid)}
                    title={`End task ${proc.name} (PID ${proc.pid})`}
                    className="opacity-0 group-hover:opacity-100 text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white transition-opacity"
                  >
                    Kill
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
