import React from 'react';
import { SystemMetrics, AccentColor } from '../types';
import {
  Cpu,
  HardDrive,
  Activity,
  Battery,
  Zap,
  Wifi,
  X,
  XCircle,
  Thermometer,
  Shield,
  Clock,
} from 'lucide-react';

interface HolographicHudProps {
  metrics: SystemMetrics;
  isOpen: boolean;
  onClose: () => void;
  onKillProcess?: (pid: number) => void;
  accentColor?: AccentColor;
}

export const HolographicHud: React.FC<HolographicHudProps> = ({
  metrics,
  isOpen,
  onClose,
  onKillProcess,
  accentColor = 'blue',
}) => {
  if (!isOpen) return null;

  const topProcesses = Array.isArray(metrics?.topProcesses) ? metrics.topProcesses : [];

  const formatUptime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${hrs}h ${mins}m`;
  };

  return (
    <div
      id="jarvis-holographic-hud"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl rounded-2xl bg-[#060a12]/95 border border-cyan-500/30 p-6 shadow-[0_0_50px_rgba(0,210,255,0.15)] flex flex-col space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-mono font-bold tracking-wider text-slate-100 uppercase">
                HOLOGRAPHIC SYSTEM TELEMETRY
              </div>
              <div className="text-[11px] font-mono text-slate-400">
                HOST DIAGNOSTICS & HARDWARE SENSORS
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-cyan-400/80 hidden sm:inline">
              UPTIME: {formatUptime(metrics.uptimeSeconds || 3600)}
            </span>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Circular Radial Dials */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {/* CPU Gauge */}
          <div className="p-4 rounded-xl bg-[#090e1c] border border-white/10 flex flex-col items-center text-center space-y-2 relative overflow-hidden group">
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="8" fill="none" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#00d2ff"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="251.2"
                  strokeDashoffset={251.2 - (251.2 * (metrics.cpu || 0)) / 100}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xl font-mono font-bold text-slate-100">{metrics.cpu}%</span>
                <span className="text-[9px] font-mono text-slate-400">{metrics.cpuTempC}°C</span>
              </div>
            </div>
            <div className="text-xs font-mono font-semibold text-cyan-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" />
              <span>CPU LOAD</span>
            </div>
          </div>

          {/* RAM Gauge */}
          <div className="p-4 rounded-xl bg-[#090e1c] border border-white/10 flex flex-col items-center text-center space-y-2 relative overflow-hidden group">
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="8" fill="none" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#38bdf8"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="251.2"
                  strokeDashoffset={251.2 - (251.2 * (metrics.ram || 0)) / 100}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xl font-mono font-bold text-slate-100">{metrics.ram}%</span>
                <span className="text-[9px] font-mono text-slate-400">MEMORY</span>
              </div>
            </div>
            <div className="text-xs font-mono font-semibold text-sky-400 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              <span>RAM USAGE</span>
            </div>
          </div>

          {/* GPU Gauge */}
          <div className="p-4 rounded-xl bg-[#090e1c] border border-white/10 flex flex-col items-center text-center space-y-2 relative overflow-hidden group">
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="8" fill="none" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#818cf8"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="251.2"
                  strokeDashoffset={251.2 - (251.2 * (metrics.gpu || 0)) / 100}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xl font-mono font-bold text-slate-100">{metrics.gpu}%</span>
                <span className="text-[9px] font-mono text-slate-400">CORE</span>
              </div>
            </div>
            <div className="text-xs font-mono font-semibold text-indigo-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              <span>GPU ENGINE</span>
            </div>
          </div>

          {/* DISK Gauge */}
          <div className="p-4 rounded-xl bg-[#090e1c] border border-white/10 flex flex-col items-center text-center space-y-2 relative overflow-hidden group">
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="8" fill="none" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#34d399"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="251.2"
                  strokeDashoffset={251.2 - (251.2 * (metrics.disk || 0)) / 100}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xl font-mono font-bold text-slate-100">{metrics.disk}%</span>
                <span className="text-[9px] font-mono text-slate-400">NVMe</span>
              </div>
            </div>
            <div className="text-xs font-mono font-semibold text-emerald-400 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5" />
              <span>STORAGE</span>
            </div>
          </div>
        </div>

        {/* Secondary Telemetry Strip: Network & Battery */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-3.5 rounded-xl bg-[#090e1c] border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                <Wifi className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-mono font-bold text-slate-200">NETWORK FLUX</div>
                <div className="text-[10px] font-mono text-slate-400">
                  IN: {metrics.networkInKb || 124} KB/s · OUT: {metrics.networkOutKb || 48} KB/s
                </div>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              ACTIVE
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#090e1c] border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <Battery className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-mono font-bold text-slate-200">POWER CELLS</div>
                <div className="text-[10px] font-mono text-slate-400">
                  {metrics.batteryPercent}% Remaining {metrics.isCharging ? '(CHARGING)' : '(DISCHARGING)'}
                </div>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-300">
              {metrics.batteryPercent}%
            </span>
          </div>
        </div>

        {/* Top Active Processes */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span className="font-bold uppercase tracking-wider text-slate-300">Top Active PC Processes</span>
            <span>{topProcesses.length} Detected</span>
          </div>

          <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
            {topProcesses.length === 0 ? (
              <div className="text-xs font-mono text-slate-500 text-center py-4">
                No telemetry available
              </div>
            ) : (
              topProcesses.slice(0, 6).map((proc) => (
                <div
                  key={proc.pid}
                  className="p-2 rounded-lg bg-[#080d1a] border border-white/5 flex items-center justify-between text-xs font-mono"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 text-[10px] w-12 truncate">PID {proc.pid}</span>
                    <span className="font-bold text-slate-200">{proc.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-cyan-400 text-[11px]">{proc.cpuPercent}% CPU</span>
                    <span className="text-slate-400 text-[11px]">{proc.memoryMb} MB</span>
                    {onKillProcess && (
                      <button
                        onClick={() => onKillProcess(proc.pid)}
                        title={`Terminate ${proc.name} (${proc.pid})`}
                        className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Close Button */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-bold transition-colors"
          >
            DISMISS HUD
          </button>
        </div>
      </div>
    </div>
  );
};
