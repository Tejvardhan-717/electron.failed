import React, { useState } from 'react';
import { MemoryItem } from '../types';
import { Brain, Plus, Trash2, Edit2, Check, X, Bookmark, Folder, Laptop, Sparkles } from 'lucide-react';

interface MemoryManagerProps {
  memories: MemoryItem[];
  enabled: boolean;
  onToggleMemory: (enabled: boolean) => void;
  onAddMemory: (item: Omit<MemoryItem, 'id' | 'createdAt' | 'useCount'>) => void;
  onDeleteMemory: (id: string) => void;
  onClearAll: () => void;
}

export const MemoryManager: React.FC<MemoryManagerProps> = ({
  memories,
  enabled,
  onToggleMemory,
  onAddMemory,
  onDeleteMemory,
  onClearAll,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [key, setKey] = useState('');
  const [value, setValue] = useState('');
  const [category, setCategory] = useState<MemoryItem['category']>('preference');
  const [description, setDescription] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!key.trim() || !value.trim()) return;

    onAddMemory({
      key: key.trim(),
      value: value.trim(),
      category,
      description: description.trim() || undefined,
    });

    setKey('');
    setValue('');
    setDescription('');
    setIsAdding(false);
  };

  const getCategoryIcon = (cat: MemoryItem['category']) => {
    switch (cat) {
      case 'preference':
        return <Bookmark className="w-3.5 h-3.5 text-sky-400" />;
      case 'frequent_app':
        return <Laptop className="w-3.5 h-3.5 text-emerald-400" />;
      case 'alias':
        return <Sparkles className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <Folder className="w-3.5 h-3.5 text-purple-400" />;
    }
  };

  return (
    <div
      id="jarvis-memory-manager"
      className="bg-[#0b0f17]/90 border border-white/10 rounded-xl p-5 backdrop-blur-md shadow-[0_4px_24px_rgba(0,0,0,0.45)] flex flex-col h-full overflow-hidden"
    >
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-slate-100 font-mono tracking-wide">
              JARVIS LONG-TERM MEMORY
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Persisted preferences, preferred directories, and contextual knowledge across sessions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs font-mono text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={enabled}
              onChange={(e) => onToggleMemory(e.target.checked)}
              className="rounded bg-[#0c1322] border-cyan-500/40 text-cyan-500 focus:ring-0"
            />
            <span>Memory Active</span>
          </label>

          {enabled && !isAdding && (
            <button
              onClick={() => setIsAdding(true)}
              className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Remember Fact
            </button>
          )}

          {memories.length > 0 && (
            <button
              onClick={onClearAll}
              title="Clear all stored memories"
              className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-[#121a28] transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="mb-4 p-3.5 rounded-xl bg-[#070a10] border border-white/10 space-y-2.5 font-mono text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-slate-400 mb-1">FACT KEY / TOPIC:</label>
              <input
                type="text"
                placeholder="e.g. coding_project_path"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 rounded bg-[#0c1322] border border-white/10 text-slate-100 focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">CATEGORY:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-2.5 py-1.5 rounded bg-[#0c1322] border border-white/10 text-slate-100 focus:outline-none focus:border-cyan-400"
              >
                <option value="preference">Preference</option>
                <option value="frequent_app">Frequently Used App</option>
                <option value="alias">Command Alias</option>
                <option value="note">Contextual Note</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">STORED VALUE / PATH / PREFERENCE:</label>
            <input
              type="text"
              placeholder="e.g. C:\Users\Admin\Projects\IronManJarvis"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              required
              className="w-full px-2.5 py-1.5 rounded bg-[#0c1322] border border-white/10 text-slate-100 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 rounded bg-[#121a28] text-slate-300 border border-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold shadow-md shadow-cyan-600/30"
            >
              Save Fact
            </button>
          </div>
        </form>
      )}

      {/* Memory items grid */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-0">
        {!enabled ? (
          <div className="flex flex-col items-center justify-center text-center h-48 text-slate-500 text-xs font-mono">
            <Brain className="w-8 h-8 mb-2 opacity-20" />
            <span>Long-term memory is currently disabled in settings.</span>
          </div>
        ) : (!memories || memories.length === 0) ? (
          <div className="flex flex-col items-center justify-center text-center h-48 text-slate-500 text-xs font-mono">
            <Brain className="w-8 h-8 mb-2 opacity-30" />
            <span>Memory is clean. No items saved yet.</span>
            <span className="text-[11px] text-slate-600 mt-1">
              JARVIS automatically learns your favorite apps, project paths, and preferences as you speak.
            </span>
          </div>
        ) : (
          (memories || []).map((mem) => (
            <div
              key={mem.id}
              className="p-3 rounded-xl bg-[#070a10]/80 border border-white/5 hover:border-cyan-500/20 transition-all font-mono text-xs flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  {getCategoryIcon(mem.category)}
                  <span className="font-bold text-cyan-300">{mem.key}</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#0c1322] text-slate-400 uppercase border border-white/5">
                    {mem.category}
                  </span>
                </div>
                <div className="text-slate-200 mt-1 font-mono text-[11px] truncate max-w-md">
                  {mem.value}
                </div>
                <div className="text-[9px] text-slate-500 mt-0.5">
                  Added: {mem.createdAt} • Used: {mem.useCount} times
                </div>
              </div>

              <button
                onClick={() => onDeleteMemory(mem.id)}
                title="Forget this fact"
                className="p-1 text-slate-500 hover:text-rose-400 transition-colors shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
