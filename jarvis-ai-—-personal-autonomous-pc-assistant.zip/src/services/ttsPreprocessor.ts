/**
 * J.A.R.V.I.S. DEDICATED TTS PREPROCESSOR
 *
 * Sits directly between AI RESPONSE and the TTS Speech Engine:
 * AI RESPONSE
 *     ↓
 * TTS PREPROCESSOR
 *     ↓
 * CLEAN SPEECH TEXT
 *     ↓
 * TTS ENGINE
 *
 * CRITICAL SPECIFICATIONS:
 * 1. Detect URLs and completely eliminate raw URL spelling
 *    (Never speak "https colon slash slash www dot...")
 * 2. If the AI tells the user about a website, speak:
 *    "I've opened the website for you." or "The website is [Service]."
 * 3. Never read raw URLs unless explicitly commanded: "Jarvis, read the URL."
 * 4. Remove Markdown links while preserving visible link text.
 * 5. Remove raw HTML tags and entities.
 * 6. Remove fenced code blocks and programming code.
 * 7. Remove unnecessary technical identifiers, internal tool calls, IDs,
 *    hex addresses, API keys, passwords, tokens, and debug information.
 * 8. Remove excessive punctuation (trailing colons, dangling prepositions).
 * 9. Convert symbols into natural spoken language (%, &, +, =, $, °C).
 * 10. Preserve normal conversational sentences.
 * 11. NEVER alter the visual UI text stored in logs/chat/transcripts.
 */

export interface TtsPreprocessorOptions {
  userCommand?: string;
  assistantName?: string;
  personality?: 'formal' | 'witty' | 'concise' | 'technical';
  allowRawUrlExplicit?: boolean;
}

export interface TtsCleanedSpeechResult {
  rawAiResponse: string;
  cleanSpeechText: string;
  sentences: string[];
  metrics: {
    urlsDetected: number;
    urlsRemoved: number;
    markdownStripped: boolean;
    codeBlocksRemoved: number;
    htmlTagsRemoved: number;
    sensitiveTokensScrubbed: number;
  };
}

/**
 * Domain-to-spoken-name mapping for natural speech
 */
const KNOWN_DOMAINS: Record<string, string> = {
  'youtube.com': 'YouTube',
  'youtu.be': 'YouTube',
  'google.com': 'Google',
  'github.com': 'GitHub',
  'wikipedia.org': 'Wikipedia',
  'reddit.com': 'Reddit',
  'twitter.com': 'Twitter',
  'x.com': 'X',
  'facebook.com': 'Facebook',
  'instagram.com': 'Instagram',
  'linkedin.com': 'LinkedIn',
  'netflix.com': 'Netflix',
  'spotify.com': 'Spotify',
  'amazon.com': 'Amazon',
  'apple.com': 'Apple',
  'microsoft.com': 'Microsoft',
  'stackoverflow.com': 'Stack Overflow',
  'openai.com': 'OpenAI',
  'bing.com': 'Bing',
  'twitch.tv': 'Twitch',
};

/**
 * Checks if the user explicitly requested JARVIS to read the raw URL aloud.
 * Example: "Jarvis, read the URL", "Can you read the link", "Speak the URL"
 */
export function userExplicitlyRequestedUrl(command?: string): boolean {
  if (!command || typeof command !== 'string') return false;
  const lower = command.toLowerCase().trim();
  return (
    /\b(read|speak|say|tell me|dictate)\s+(the\s+)?(raw\s+)?(url|link|web\s+address|website\s+url|website\s+link)\b/i.test(
      lower
    ) ||
    lower.includes('read url') ||
    lower.includes('read the url') ||
    lower.includes('speak the url')
  );
}

/**
 * Extract clean website name from a URL if appropriate
 */
export function extractWebsiteNameFromUrl(url: string): string | null {
  try {
    const clean = url
      .replace(/^[<([{'"]+/, '')
      .replace(/[>)}\]'".;,]+$/, '')
      .trim();
    const fullUrl = clean.startsWith('http') ? clean : `https://${clean}`;
    const parsed = new URL(fullUrl);
    const host = parsed.hostname.toLowerCase().replace(/^www\./, '').replace(/\.$/, '');

    for (const [domain, spokenName] of Object.entries(KNOWN_DOMAINS)) {
      if (host === domain || host.endsWith(`.${domain}`)) {
        return spokenName;
      }
    }

    // Generic domain: e.g. "example.com" -> "example"
    const parts = host.split('.');
    if (parts.length >= 2) {
      const name = parts[parts.length - 2];
      if (name && name.length > 2 && !/^\d+$/.test(name)) {
        return name.charAt(0).toUpperCase() + name.slice(1);
      }
    }
  } catch {
    // URL parsing failed
  }
  return null;
}

/**
 * PRIMARY PREPROCESSOR PIPELINE
 * Converts any AI response into clean, natural spoken speech.
 */
export function preprocessTtsSpeechText(
  rawAiResponse: string,
  options: TtsPreprocessorOptions = {}
): TtsCleanedSpeechResult {
  if (!rawAiResponse || typeof rawAiResponse !== 'string') {
    return {
      rawAiResponse: '',
      cleanSpeechText: '',
      sentences: [],
      metrics: {
        urlsDetected: 0,
        urlsRemoved: 0,
        markdownStripped: false,
        codeBlocksRemoved: 0,
        htmlTagsRemoved: 0,
        sensitiveTokensScrubbed: 0,
      },
    };
  }

  const raw = rawAiResponse.trim();
  let text = raw;

  let urlsDetected = 0;
  let urlsRemoved = 0;
  let markdownStripped = false;
  let codeBlocksRemoved = 0;
  let htmlTagsRemoved = 0;
  let sensitiveTokensScrubbed = 0;

  const allowRawUrl =
    options.allowRawUrlExplicit || userExplicitlyRequestedUrl(options.userCommand);

  // 1. STRIP INTERNAL JSON RESPONSES & THINKING TAGS
  if (text.startsWith('{') && text.endsWith('}')) {
    try {
      const parsed = JSON.parse(text);
      if (parsed.reply) text = String(parsed.reply);
      else if (parsed.response) text = String(parsed.response);
      else if (parsed.message) text = String(parsed.message);
    } catch {
      // Not JSON
    }
  }

  // Remove <think>...</think> tags or internal reflections
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

  // 2. REMOVE SENSITIVE CREDENTIALS, API KEYS, TOKENS, PASSWORDS, INTERNAL TOOL CALLS
  const sensitivePatterns = [
    /AIzaSy[A-Za-z0-9_-]{33}/g,
    /\b(sk-[a-zA-Z0-9]{20,})\b/g,
    /\bBearer\s+[a-zA-Z0-9_.-]{20,}\b/gi,
    /\b(api_key|apikey|password|secret|token|auth_token)\s*[:=]\s*['"][^'"]+['"]/gi,
    /\btool_call:\s*\w+\([^)]*\)/gi,
    /\[TOOL CALL:[^\]]+\]/gi,
    /\[DEBUG:[^\]]+\]/gi,
    /\[INFO:[^\]]+\]/gi,
    /\{"toolName":[\s\S]*?\}/g,
    /\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g, // UUIDs
    /\b0x[0-9a-fA-F]{6,16}\b/g, // Hex memory addresses
  ];

  sensitivePatterns.forEach((pat) => {
    if (pat.test(text)) {
      sensitiveTokensScrubbed++;
      text = text.replace(pat, ' ');
    }
  });

  // 3. REMOVE FENCED CODE BLOCKS AND PROGRAMMING CODE
  const codeBlockMatch = text.match(/```[\s\S]*?```/g);
  if (codeBlockMatch) {
    codeBlocksRemoved += codeBlockMatch.length;
    text = text.replace(/```[\s\S]*?```/g, ' ');
    markdownStripped = true;
  }

  // Inline backticks `code`:
  if (/`[^`]+`/.test(text)) {
    text = text.replace(/`([^`]+)`/g, (_m, codeContent) => {
      // If code contains programming syntax (e.g. (), {}, =>, semicolons, const/let), strip it
      if (/[(){};=><]|const|let|var|function|import|class/i.test(codeContent)) {
        return ' ';
      }
      // Simple word or app name like `notepad.exe` -> notepad
      return codeContent.replace(/\.(exe|bat|ps1|sh|json|ts|js)/gi, '').trim();
    });
    markdownStripped = true;
  }

  // 4. REMOVE RAW HTML TAGS & DECODE ENTITIES
  if (/<[^>]+>/.test(text)) {
    const htmlMatches = text.match(/<[^>]+>/g);
    if (htmlMatches) htmlTagsRemoved += htmlMatches.length;

    // Preserve text inside anchor tags <a href="...">Anchor Text</a> -> Anchor Text
    text = text.replace(/<a\s+[^>]*href="[^"]*"[^>]*>(.*?)<\/a>/gi, '$1');
    // Remove all remaining tags
    text = text.replace(/<[^>]+>/g, ' ');
  }

  // Decode common HTML entities
  text = text
    .replace(/&amp;/gi, 'and')
    .replace(/&lt;/gi, 'less than')
    .replace(/&gt;/gi, 'greater than')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&nbsp;/gi, ' ');

  // 5. REMOVE MARKDOWN LINKS WHILE PRESERVING VISIBLE LINK TEXT
  // Example: [Watch on YouTube](https://youtube.com/...) -> Watch on YouTube
  text = text.replace(/\[([^\]]+)\]\((?:https?:\/\/[^\s)]+)\)/g, (_m, linkText) => {
    markdownStripped = true;
    // If link text is itself a URL, remove or replace with website name
    if (/^https?:\/\//i.test(linkText.trim()) || /^www\./i.test(linkText.trim())) {
      const siteName = extractWebsiteNameFromUrl(linkText);
      return siteName || 'the website';
    }
    return linkText.trim();
  });

  // Reference-style links: [1]: https://...
  text = text.replace(/^\[\d+\]:\s*https?:\/\/\S+/gm, '');

  // 6. DETECT & HANDLE RAW URLS
  // Regex to match URLs including http://, https://, www., and common domain paths
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"')]+(?:\([^\s<>"')]+\)|[^\s`!@#$%^&*()_=+\[\]{};:'",.<>?])+/gi;

  const foundUrls = text.match(urlRegex) || [];
  urlsDetected = foundUrls.length;

  if (urlsDetected > 0 && !allowRawUrl) {
    urlsRemoved += urlsDetected;

    // Case A: Entire response is just a URL or "Opening [URL]"
    const strippedOnlyUrl = text.replace(urlRegex, '').trim();
    if (
      !strippedOnlyUrl ||
      strippedOnlyUrl === ':' ||
      strippedOnlyUrl === '.' ||
      /^(opening|launching|navigating to|here is|here's|visit|check out)[\s:.]*$/i.test(strippedOnlyUrl)
    ) {
      const firstUrl = foundUrls[0];
      const siteName = extractWebsiteNameFromUrl(firstUrl);
      if (siteName) {
        text = `I've opened ${siteName} for you, sir.`;
      } else {
        text = `I've opened the website for you, sir.`;
      }
    } else {
      // Case B: Sentences stating "The website is [URL]" or "The URL is [URL]"
      text = text.replace(
        /(the\s+(?:website|link|address|site|page)\s+is(?:\s*:)?)\s+((?:https?:\/\/[^\s]+|www\.[^\s]+))/gi,
        (_match, _prefix, url) => {
          const siteName = extractWebsiteNameFromUrl(url);
          if (siteName) {
            return `The website is ${siteName}.`;
          }
          return `I've provided the link for you on screen.`;
        }
      );

      // Case C: Preceding phrases with colons or connectors:
      // "You can watch it here:\nhttps://youtube.com/..." -> "You can watch it here."
      // "Available at https://..." -> "Available on the website."
      // "Check it out at https://..." -> "Check it out on the website."
      text = text.replace(
        /(watch(?:\s+it)?\s+here|find(?:\s+it)?\s+here|view(?:\s+it)?\s+here|see(?:\s+it)?\s+here|listen(?:\s+it)?\s+here|check(?:\s+it)?\s+out\s+here|read(?:\s+it)?\s+here)\s*:\s*(?:https?:\/\/|www\.)\S+/gi,
        '$1.'
      );

      text = text.replace(
        /(here\s+is\s+the\s+(?:link|video|site|article|page|result))\s*:\s*(?:https?:\/\/|www\.)\S+/gi,
        '$1 on screen.'
      );

      // "available at https://..." -> "available on the website."
      text = text.replace(
        /\b(available|accessible|found|posted|hosted)\s+(?:at|on)\s+((?:https?:\/\/|www\.)\S+)/gi,
        (_match, verb, url) => {
          const siteName = extractWebsiteNameFromUrl(url);
          return siteName ? `${verb} on ${siteName}.` : `${verb} on the website.`;
        }
      );

      // "visit https://..." -> "visit YouTube." or "visit the website."
      text = text.replace(
        /\b(visit|go\s+to|navigate\s+to|see|check(?:\s+out)?|view|inspect)\s+((?:https?:\/\/|www\.)\S+)/gi,
        (_match, verb, url) => {
          const siteName = extractWebsiteNameFromUrl(url);
          return siteName ? `${verb} ${siteName}.` : `${verb} the website.`;
        }
      );

      // Remove any remaining raw URLs
      text = text.replace(urlRegex, ' ');

      // Fix colon or hyphen immediately before where a URL was removed:
      // e.g. "here: " -> "here. "
      text = text.replace(/([a-zA-Z0-9])\s*:\s*(?=[.!?\s]|$)/g, '$1. ');
      text = text.replace(/([a-zA-Z0-9])\s*-\s*(?=[.!?\s]|$)/g, '$1. ');
    }
  } else if (allowRawUrl) {
    // If the user explicitly commanded "Jarvis, read the URL":
    // Pronounce URL phonetically without symbols: "w w w dot youtube dot com slash..."
    text = text.replace(/https?:\/\//gi, '');
    text = text.replace(/\./g, ' dot ');
    text = text.replace(/\//g, ' slash ');
  }

  // 7. STRIP MARKDOWN FORMATTING SYNTAX
  // Headers: # Header
  text = text.replace(/^#{1,6}\s+/gm, '');

  // Bold & Italic: **bold**, *italic*, __bold__, _italic_
  text = text.replace(/\*\*\*([^*]+)\*\*\*/g, '$1');
  text = text.replace(/\*\*([^*]+)\*\*/g, '$1');
  text = text.replace(/\*([^*]+)\*/g, '$1');
  text = text.replace(/___([^_]+)___/g, '$1');
  text = text.replace(/__([^_]+)__/g, '$1');
  text = text.replace(/_([^_]+)_/g, '$1');

  // Strikethrough ~~text~~
  text = text.replace(/~~([^~]+)~~/g, '$1');

  // Blockquotes: > quote
  text = text.replace(/^\s*>\s*/gm, '');

  // Bullet points and numbered lists: - item, * item, 1. item
  text = text.replace(/^\s*[-*+]\s+/gm, '');
  text = text.replace(/^\s*\d+\.\s+/gm, '');

  // Tables: | col | col |
  text = text.replace(/\|[^\n]+\|/g, ' ');
  text = text.replace(/[-:]{2,}\s*\|\s*[-:]{2,}/g, ' ');

  // 8. SIMPLIFY DEEP FILE PATHS UNLESS EXPLICITLY REQUESTED
  const isFilePathExplicit =
    options.userCommand &&
    /\b(file\s+path|full\s+path|exact\s+path|directory\s+path|where\s+is\s+the\s+file)\b/i.test(
      options.userCommand
    );

  if (!isFilePathExplicit) {
    // C:\Users\...\document.pdf -> "document.pdf" or "file document"
    text = text.replace(
      /[a-zA-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)+([^\\/:*?"<>|\r\n\s]+)/g,
      (_match, filename) => {
        return `the file ${filename.replace(/\.[a-zA-Z0-9]+$/, '')}`;
      }
    );
    // Unix paths: /home/user/.../file.ext -> "file.ext"
    text = text.replace(
      /(?:\/[a-zA-Z0-9._-]+){2,}\/([a-zA-Z0-9._-]+\.[a-zA-Z0-9]+)/g,
      (_match, filename) => {
        return `the file ${filename.replace(/\.[a-zA-Z0-9]+$/, '')}`;
      }
    );
  }

  // 9. CONVERT SYMBOLS INTO NATURAL SPOKEN LANGUAGE
  text = text
    .replace(/(\d+)\s*%/g, '$1 percent')
    .replace(/(\d+)\s*°\s*C\b/gi, '$1 degrees Celsius')
    .replace(/(\d+)\s*°\s*F\b/gi, '$1 degrees Fahrenheit')
    .replace(/(\d+)\s*C\b/g, '$1 degrees Celsius')
    .replace(/\$(\d+(?:\.\d{1,2})?)/g, '$1 dollars')
    .replace(/£(\d+(?:\.\d{1,2})?)/g, '$1 pounds')
    .replace(/€(\d+(?:\.\d{1,2})?)/g, '$1 euros')
    .replace(/#(\d+)\b/g, 'number $1')
    .replace(/\s+&\s+/g, ' and ')
    .replace(/\s*\+\s*/g, ' plus ')
    .replace(/\s*=\s*/g, ' equals ')
    .replace(/\bvs\.\b/gi, 'versus')
    .replace(/\be\.g\.,?\b/gi, 'for example')
    .replace(/\bi\.e\.,?\b/gi, 'that is')
    .replace(/\betc\.\b/gi, 'et cetera');

  // Spoken technical acronyms
  text = text
    .replace(/\bCPU\b/g, 'C P U')
    .replace(/\bRAM\b/g, 'RAM')
    .replace(/\bGPU\b/g, 'G P U')
    .replace(/\bOS\b/g, 'O S')
    .replace(/\bAPI\b/g, 'A P I')
    .replace(/\bUI\b/g, 'U I')
    .replace(/\bPC\b/g, 'P C')
    .replace(/\bPID\b/g, 'P I D')
    .replace(/\bKB\/s\b/gi, 'kilobytes per second')
    .replace(/\bMB\/s\b/gi, 'megabytes per second')
    .replace(/\bGB\b/gi, 'gigabytes')
    .replace(/\bMB\b/gi, 'megabytes')
    .replace(/\bKB\b/gi, 'kilobytes');

  // Strip emojis & unpronounceable unicode symbols
  text = text.replace(
    /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}]/gu,
    ''
  );

  // Strip residual punctuation noise
  text = text.replace(/[$^~_={}|\\<>]/g, ' ');
  text = text.replace(/([.!?])\s*([.!?])+/g, '$1');
  text = text.replace(/\s+/g, ' ').trim();

  // If text became empty after stripping URLs/code, provide a polite spoken acknowledgment
  if (!text || text === '.' || text === '!') {
    text = "I've completed that request for you, sir.";
  }

  // 10. SPLIT INTO NATURAL SPOKEN SENTENCES
  const sentences = splitNaturalSentences(text);

  return {
    rawAiResponse: raw,
    cleanSpeechText: text,
    sentences,
    metrics: {
      urlsDetected,
      urlsRemoved,
      markdownStripped,
      codeBlocksRemoved,
      htmlTagsRemoved,
      sensitiveTokensScrubbed,
    },
  };
}

/**
 * Splits clean text into natural, spoken-cadence sentences without breaking on
 * abbreviations or titles.
 */
function splitNaturalSentences(cleanText: string): string[] {
  if (!cleanText || !cleanText.trim()) return [];

  let text = cleanText.trim();
  const protectedMap = new Map<string, string>();
  let tokenCounter = 0;

  const abbreviations = [
    /\bMr\./gi,
    /\bMrs\./gi,
    /\bMs\./gi,
    /\bDr\./gi,
    /\bProf\./gi,
    /\bSr\./gi,
    /\bJr\./gi,
    /\bSt\./gi,
    /\bNo\./gi,
    /\bFig\./gi,
    /\bv\d+\.\d+\b/gi,
    /\b\d+\.\d+\b/g, // decimal numbers
  ];

  abbreviations.forEach((regex) => {
    text = text.replace(regex, (match) => {
      const token = `__TTS_TOKEN_${tokenCounter++}__`;
      protectedMap.set(token, match);
      return token;
    });
  });

  const rawSentences = text
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const finalSentences: string[] = [];

  rawSentences.forEach((sentence) => {
    let restored = sentence;
    protectedMap.forEach((original, token) => {
      restored = restored.replace(new RegExp(token, 'g'), original);
    });

    restored = restored.trim();
    if (!restored) return;

    // If a sentence is long (>140 chars) and contains clauses, split at natural pauses
    if (restored.length > 140 && (restored.includes(';') || restored.includes(', '))) {
      const subClauses = restored
        .split(/(?<=[;,])\s+/)
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      if (subClauses.length > 1) {
        let chunk = '';
        subClauses.forEach((cl) => {
          if ((chunk + ' ' + cl).trim().length > 120 && chunk.length > 0) {
            finalSentences.push(ensurePunctuation(chunk.trim()));
            chunk = cl;
          } else {
            chunk = chunk ? `${chunk} ${cl}` : cl;
          }
        });
        if (chunk.trim()) {
          finalSentences.push(ensurePunctuation(chunk.trim()));
        }
        return;
      }
    }

    finalSentences.push(ensurePunctuation(restored));
  });

  return finalSentences;
}

function ensurePunctuation(s: string): string {
  const trimmed = s.trim();
  if (!trimmed) return '';
  const lastChar = trimmed[trimmed.length - 1];
  if (['.', '!', '?', ';', ':'].includes(lastChar)) {
    return trimmed;
  }
  return `${trimmed}.`;
}
