import React, { useState, useEffect, useRef } from 'react';
import {
  AIState,
  SystemMetrics,
  TaskPlan,
  TaskStep,
  ActivityLogItem,
  ConfirmationRequest,
  JarvisSettings,
  AutomationRule,
  MemoryItem,
  WakeWordEngineState,
  MicrophoneStatus,
  AccentColor,
} from './types';
import { AICore } from './components/AICore';
import { ConversationPanel } from './components/ConversationPanel';
import { LiveTaskDrawer } from './components/LiveTaskDrawer';
import { HolographicHud } from './components/HolographicHud';
import { CommandPalette } from './components/CommandPalette';
import { FloatingControlBar } from './components/FloatingControlBar';
import { MinimizedOrb } from './components/MinimizedOrb';
import { ConfirmationModal } from './components/ConfirmationModal';
import { AutomationsBuilder } from './components/AutomationsBuilder';
import { MemoryManager } from './components/MemoryManager';
import { SettingsModal } from './components/SettingsModal';
import { BrowserPreviewModal } from './components/BrowserPreviewModal';
import { BridgeAndDiagnosticsPanel } from './components/BridgeAndDiagnosticsPanel';
import { DeveloperStatusPanel } from './components/DeveloperStatusPanel';
import { SoundEffects } from './services/soundEffects';
import { voiceService } from './services/voiceService';
import { preprocessTtsSpeechText } from './services/ttsPreprocessor';
import { DeveloperSessionStatus } from './types';
import {
  Mic,
  MicOff,
  Terminal,
  Settings as SettingsIcon,
  Shield,
  Zap,
  Brain,
  Layers,
  Sparkles,
  Maximize2,
  Minimize2,
  Minus,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Activity,
  ShieldAlert,
  X,
} from 'lucide-react';

const DEFAULT_SETTINGS: JarvisSettings = {
  assistantName: 'JARVIS',
  personality: 'formal',
  wakeWord: 'Jarvis',
  wakeWordEnabled: true,
  voiceName: '',
  speechSpeed: 1.0,
  speechPitch: 0.92,
  audioFeedback: true,
  continuousListening: false,
  hotkey: 'Control+Space',
  protectedFolders: ['C:\\Users\\User\\Documents', 'C:\\Users\\User\\Desktop', 'Projects'],
  protectedExtensions: ['*.key', '*.pem', '*.env', 'credentials.json', 'id_rsa'],
  trustedApps: ['Google Chrome', 'VS Code', 'Discord', 'Spotify', 'Steam'],
  allowTrustedAutoInstall: false,
  requireAdminApproval: true,
  maxAutomatedSteps: 12,
  enableMemory: true,
  accentColor: 'blue',
  animationIntensity: 'high',
  hudScanlines: false,
  startWithWindows: true,
  soundEffects: true,
};

export default function App() {
  // AI Core & UI States
  const [aiState, setAiState] = useState<AIState>('IDLE');
  const [activeView, setActiveView] = useState<'hud' | 'automations' | 'memory'>('hud');
  const [isListening, setIsListening] = useState(false);
  const [voiceLevel, setVoiceLevel] = useState<number>(0);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [subText, setSubText] = useState('"How may I assist you, sir?"');
  const [commandInput, setCommandInput] = useState('');

  // Drawers & Overlays
  const [isConversationOpen, setIsConversationOpen] = useState(false);
  const [isTasksOpen, setIsTasksOpen] = useState(false);
  const [isHudOpen, setIsHudOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showAcceptancePills, setShowAcceptancePills] = useState(false);

  // Settings & System Modals
  const [settings, setSettings] = useState<JarvisSettings>(DEFAULT_SETTINGS);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPcNoticeOpen, setIsPcNoticeOpen] = useState(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [isDevStatusOpen, setIsDevStatusOpen] = useState(false);
  const [devStatus, setDevStatus] = useState<DeveloperSessionStatus>(voiceService.getDeveloperStatus());
  const [wakeWordEngineState, setWakeWordEngineState] = useState<WakeWordEngineState>('IDLE');
  const [micStatus, setMicStatus] = useState<MicrophoneStatus>('DISCONNECTED');
  const [bridgeConnected, setBridgeConnected] = useState<boolean>(false);

  // Hardware Telemetry & Metrics
  const [metrics, setMetrics] = useState<SystemMetrics>({
    cpu: 28,
    ram: 52,
    gpu: 24,
    disk: 58,
    networkInKb: 180,
    networkOutKb: 45,
    batteryPercent: 94,
    isCharging: true,
    cpuTempC: 46,
    topProcesses: [],
    uptimeSeconds: 18400,
  });

  // Task & Planning Engine
  const [currentPlan, setCurrentPlan] = useState<TaskPlan | null>(null);
  const taskCancellationRef = useRef<boolean>(false);
  const taskPausedRef = useRef<boolean>(false);

  // Safety Confirmation Request
  const [confirmationReq, setConfirmationReq] = useState<ConfirmationRequest | null>(null);

  // Audit Logs & Undo Stack
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>([
    {
      id: 'init-1',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      assistantResponse: 'JARVIS Neural Core initialized. System operational.',
      riskLevel: 0,
      status: 'success',
      details: 'Operating in secure sandboxed OS layer with hardware verification active.',
    },
  ]);
  const [undoStack, setUndoStack] = useState<string[]>([]);

  // Automations & Memory
  const [automations, setAutomations] = useState<AutomationRule[]>([
    {
      id: 'auto-1',
      triggerPhrase: 'gaming mode',
      name: 'Launch Gaming Suite',
      description: 'Prepares memory and opens Discord, Steam, and Spotify',
      enabled: true,
      actions: [
        { toolName: 'open_application', params: { appName: 'Discord' }, description: 'Open Discord' },
        { toolName: 'open_application', params: { appName: 'Steam' }, description: 'Open Steam' },
        { toolName: 'open_application', params: { appName: 'Spotify' }, description: 'Open Spotify' },
      ],
      createdAt: '2026-09-01',
    },
    {
      id: 'auto-2',
      triggerPhrase: 'start work',
      name: 'Coding Environment',
      description: 'Launches VS Code, Chrome dev tabs, and Docker',
      enabled: true,
      actions: [
        { toolName: 'open_application', params: { appName: 'VS Code' }, description: 'Open VS Code' },
        { toolName: 'open_application', params: { appName: 'Google Chrome' }, description: 'Open Chrome' },
      ],
      createdAt: '2026-09-02',
    },
  ]);

  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Browser Preview State
  const [browserPreview, setBrowserPreview] = useState<{
    isOpen: boolean;
    url: string;
    pageTitle: string;
    actionLog: string[];
    activeTab: string;
    tabs: string[];
  }>({
    isOpen: false,
    url: 'https://youtube.com',
    pageTitle: 'YouTube - Broadcast Yourself',
    actionLog: [],
    activeTab: 'YouTube Search',
    tabs: ['YouTube Search', 'GitHub', 'System Dashboard'],
  });

  // Fetch telemetry regularly
  useEffect(() => {
    const fetchTelemetry = async () => {
      try {
        const res = await fetch('/api/system/stats');
        if (res.ok) {
          const data = await res.json();
          setMetrics((prev) => ({
            ...prev,
            ...data,
            topProcesses: Array.isArray(data?.topProcesses) ? data.topProcesses : prev.topProcesses || [],
          }));
        }
      } catch {
        // use local dynamic generator if offline
      }
    };

    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3500);
    return () => clearInterval(interval);
  }, []);

  // Fetch memory store
  useEffect(() => {
    const fetchMemory = async () => {
      try {
        const res = await fetch('/api/memory');
        if (res.ok) {
          const data = await res.json();
          setMemories(data.memories || []);
        }
      } catch {
        // ignore
      }
    };
    fetchMemory();
  }, []);

  // Load available voices
  useEffect(() => {
    const updateVoices = () => {
      const v = voiceService.getAvailableVoices();
      if (v.length > 0) setAvailableVoices(v);
    };
    updateVoices();
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  // Bridge status polling
  useEffect(() => {
    const checkBridge = async () => {
      try {
        const res = await fetch('/api/bridge/status');
        if (res.ok) {
          const data = await res.json();
          setBridgeConnected(data.connected);
        }
      } catch {
        // ignore
      }
    };
    checkBridge();
    const interval = setInterval(checkBridge, 3000);
    return () => clearInterval(interval);
  }, []);

  // Register Voice Service listeners
  useEffect(() => {
    voiceService.setWakeWord(settings.wakeWord);

    voiceService.onCommand((command) => {
      SoundEffects.playWakeChime(settings.audioFeedback);
      if (isMinimized) setIsMinimized(false);
      handleExecuteCommand(command);
    });

    voiceService.onInterim((interim) => {
      setVoiceTranscript(interim);
      setSubText(`"${interim}..."`);
    });

    voiceService.onMicStatus((status) => {
      setMicStatus(status);
    });

    // Real audio volume monitoring from hardware mic / speech cadence
    voiceService.onVolumeChange((vol) => {
      setVoiceLevel(vol);
    });

    // Developer Session Status Stream
    voiceService.onDeveloperStatus((newDevStatus) => {
      setDevStatus({ ...newDevStatus });
    });

    // 30-Second Inactivity Timeout notification
    voiceService.onSessionTimeout(() => {
      setAiState('IDLE');
      setSubText('Session timed out (30s inactivity). Waiting for "Hey Jarvis"...');
      SoundEffects.playTaskComplete(settings.audioFeedback);
    });

    voiceService.onSessionState((convState, sessionMode) => {
      if (sessionMode === 'ACTIVE') {
        if (convState === 'ACTIVE_CONVERSATION' || convState === 'LISTENING') {
          setAiState('LISTENING');
          setSubText('Active Conversation — Listening (No wake word required)...');
          setIsListening(true);
        } else if (convState === 'THINKING') {
          setAiState('THINKING');
          setSubText('Analyzing command intent...');
        } else if (convState === 'EXECUTING') {
          setAiState('EXECUTING');
        } else if (convState === 'SPEAKING') {
          setAiState('SPEAKING');
        }
      } else {
        // SLEEPING
        setIsListening(false);
        if (aiState !== 'EXECUTING' && aiState !== 'SPEAKING') {
          setAiState('IDLE');
          setSubText('"How may I assist you, sir?" (Waiting for "Jarvis")');
        }
      }
    });

    voiceService.onStateChange((state) => {
      setWakeWordEngineState(state);
      const isCapturing =
        state === 'WAKE_WORD_DETECTED' ||
        state === 'LISTENING_FOR_COMMAND' ||
        voiceService.getSessionStatus() === 'ACTIVE';
      setIsListening(isCapturing);

      if (state === 'LISTENING_FOR_WAKE_WORD') {
        if (aiState !== 'EXECUTING' && aiState !== 'SPEAKING') {
          setAiState('IDLE');
          setSubText('"How may I assist you, sir?" (Waiting for "Jarvis")');
        }
      } else if (state === 'WAKE_WORD_DETECTED') {
        setAiState('LISTENING');
        setSubText('"Wake word detected! Activating session..."');
        SoundEffects.playWakeChime(settings.audioFeedback);
        if (isMinimized) setIsMinimized(false);
      } else if (state === 'LISTENING_FOR_COMMAND') {
        setAiState('LISTENING');
        setSubText('Listening for command (no wake word required)...');
      } else if (state === 'PROCESSING') {
        setAiState('THINKING');
        setSubText('"Analyzing command intent..."');
      } else if (state === 'SPEAKING') {
        setAiState('SPEAKING');
      } else if (state === 'IDLE') {
        setAiState('IDLE');
        setSubText('"How may I assist you, sir?"');
      }
    });

    // Automatically start continuous wake-word detection
    if (settings.wakeWordEnabled) {
      voiceService.startContinuousWakeWord();
    }
  }, [settings.wakeWord, settings.wakeWordEnabled, settings.audioFeedback, isMinimized]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + Space: toggle voice listening
      if (e.ctrlKey && e.code === 'Space') {
        e.preventDefault();
        toggleVoiceListening();
      }
      // Slash: open command palette if not typing in input
      if (e.key === '/' && !isCommandPaletteOpen && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault();
        setIsCommandPaletteOpen(true);
      }
      // Esc: close drawers or palettes
      if (e.key === 'Escape') {
        if (isCommandPaletteOpen) setIsCommandPaletteOpen(false);
        else if (isConversationOpen) setIsConversationOpen(false);
        else if (isTasksOpen) setIsTasksOpen(false);
        else if (isHudOpen) setIsHudOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isListening, isCommandPaletteOpen, isConversationOpen, isTasksOpen, isHudOpen, settings.audioFeedback]);

  // Toggle voice recognition
  const toggleVoiceListening = () => {
    if (isListening) {
      voiceService.stopListening();
      setIsListening(false);
      setAiState('IDLE');
      setSubText('"How may I assist you, sir?"');
    } else {
      SoundEffects.playWakeChime(settings.audioFeedback);
      const success = voiceService.startListening(settings.continuousListening);
      if (success) {
        setIsListening(true);
        setAiState('LISTENING');
        setSubText('Listening... Speak your command.');
      } else {
        setSubText('Microphone active. You may also type your command below.');
      }
    }
  };

  // Speaks response via SpeechSynthesis with TTS pipeline
  const speakJarvisResponse = async (text: string, userCommand?: string) => {
    setAiState('SPEAKING');

    // Dedicated TTS preprocessor: ensures subtitle does not flash raw URLs
    const preprocessed = preprocessTtsSpeechText(text, { userCommand });
    const initialSubtitle = preprocessed.sentences[0] || preprocessed.cleanSpeechText || text;
    setSubText(`"${initialSubtitle}"`);

    await voiceService.speak(text, {
      voiceName: settings.voiceName,
      rate: settings.speechSpeed,
      pitch: settings.speechPitch,
      assistantName: settings.assistantName || 'JARVIS',
      personality: settings.personality,
      userCommand,
      onSentenceStart: (sentence) => {
        setSubText(`"${sentence}"`);
      },
      onEnd: () => {
        if (voiceService.getSessionStatus() === 'ACTIVE') {
          setAiState('LISTENING');
          setSubText('Active Conversation — Listening (No wake word required)...');
          voiceService.setConversationState('LISTENING');
          voiceService.resumeInactivityTimer();
        } else if (!currentPlan || currentPlan.status === 'completed') {
          setAiState('IDLE');
          setSubText('"How may I assist you, sir?"');
        }
      },
    });
  };

  // Main Command Handler (Voice or Text)
  const handleExecuteCommand = async (command: string) => {
    if (!command.trim()) return;

    const userCmd = command.trim();
    setCommandInput('');
    setVoiceTranscript('');
    setAiState('THINKING');
    setSubText(`Processing: "${userCmd}"`);

    // Check for custom automations first (e.g. "gaming mode")
    const matchedAutomation = automations.find(
      (a) => a.enabled && a.triggerPhrase.toLowerCase() === userCmd.toLowerCase()
    );
    if (matchedAutomation) {
      runCustomAutomation(matchedAutomation);
      return;
    }

    // Check for "Undo that" / "Undo"
    if (/^(undo\s+that|undo|revert)$/i.test(userCmd)) {
      handleUndoLastAction();
      return;
    }

    // Check for "Stop" / "Cancel"
    if (/^(stop|cancel|abort)$/i.test(userCmd)) {
      if (currentPlan && currentPlan.status === 'running') {
        taskCancellationRef.current = true;
        setCurrentPlan((prev) => (prev ? { ...prev, status: 'cancelled' } : null));
        setAiState('IDLE');
        speakJarvisResponse('Task cancelled, sir. System remains unchanged.');
        return;
      }
    }

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userCmd,
          personality: settings.personality,
          assistantName: settings.assistantName,
        }),
      });

      if (!res.ok) {
        throw new Error('AI Orchestrator returned an error');
      }

      const data = await res.json();
      const reply = data.reply || 'Understood, sir.';

      // Record Activity Log
      const logEntry: ActivityLogItem = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        userCommand: userCmd,
        assistantResponse: reply,
        toolName: data.steps?.[0]?.toolName,
        riskLevel: data.riskLevel || 0,
        status: 'success',
        details: reply,
      };

      setActivityLogs((prev) => [logEntry, ...prev]);

      // Speak back to user immediately (spoken text cleaned by dedicated TTS preprocessor)
      await speakJarvisResponse(reply, userCmd);

      // Multi-step task execution
      const rawSteps = Array.isArray(data?.steps) ? data.steps : [];
      if (rawSteps.length > 0) {
        setAiState('PLANNING');
        setSubText(`Synthesizing execution sequence for "${data.taskTitle || userCmd}"`);

        const plan: TaskPlan = {
          id: `plan-${Date.now()}`,
          title: data.taskTitle || userCmd,
          userCommand: userCmd,
          status: 'running',
          state: 'EXECUTING',
          progressPercent: 0,
          currentStepIndex: 0,
          steps: rawSteps.map((s: any, idx: number) => ({
            id: `step-${idx}`,
            stepNumber: s.stepNumber || idx + 1,
            description: s.description,
            toolName: s.toolName,
            params: s.params || {},
            riskLevel: s.riskLevel ?? 1,
            status: 'pending',
          })),
          startedAt: new Date().toLocaleTimeString(),
        };

        setCurrentPlan(plan);
        setIsTasksOpen(true); // Automatically open live task drawer
        executeTaskPlan(plan);
      } else {
        if (voiceService.getSessionStatus() === 'ACTIVE') {
          setAiState('LISTENING');
          setSubText('Active Conversation — Listening (No wake word required)...');
          voiceService.setConversationState('LISTENING');
          voiceService.resumeInactivityTimer();
        } else {
          setAiState('IDLE');
          setSubText('"How may I assist you, sir?"');
        }
      }
    } catch (err: any) {
      setAiState('ERROR');
      const errReply = "I encountered an issue processing that command, sir. I've logged the telemetry.";
      speakJarvisResponse(errReply);
      setActivityLogs((prev) => [
        {
          id: `err-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          userCommand: userCmd,
          riskLevel: 1,
          status: 'error',
          details: err?.message || 'Execution error',
        },
        ...prev,
      ]);
    }
  };

  // Autonomous Multi-step Executor with Safety Checks
  const executeTaskPlan = async (plan: TaskPlan) => {
    taskCancellationRef.current = false;
    taskPausedRef.current = false;
    setAiState('EXECUTING');
    voiceService.setConversationState('EXECUTING');
    // Long-running task: pause 30-second timer
    voiceService.pauseInactivityTimer(`Executing: ${plan.title}`);

    for (let i = 0; i < plan.steps.length; i++) {
      if (taskCancellationRef.current) {
        setCurrentPlan((prev) => (prev ? { ...prev, status: 'cancelled' } : null));
        setAiState('IDLE');
        return;
      }

      // Check if paused
      while (taskPausedRef.current) {
        await new Promise((r) => setTimeout(r, 500));
        if (taskCancellationRef.current) return;
      }

      const step = plan.steps[i];

      // Update current step to running
      setCurrentPlan((prev) => {
        if (!prev) return null;
        const updated = [...prev.steps];
        updated[i].status = 'running';
        return {
          ...prev,
          currentStepIndex: i,
          progressPercent: (i / plan.steps.length) * 100,
          steps: updated,
        };
      });

      // SAFETY ENGINE CHECK: LEVEL 2 or LEVEL 3 confirmation
      const requiresConfirmation =
        step.riskLevel === 3 ||
        (step.riskLevel === 2 && !settings.allowTrustedAutoInstall);

      if (requiresConfirmation) {
        SoundEffects.playAlertWarning(settings.audioFeedback);
        setCurrentPlan((prev) => {
          if (!prev) return null;
          const updated = [...prev.steps];
          updated[i].status = 'waiting_approval';
          return { ...prev, steps: updated };
        });

        const approved = await new Promise<boolean>((resolve) => {
          setConfirmationReq({
            id: `conf-${Date.now()}`,
            stepId: step.id,
            title: `Safety Authorization: ${step.description}`,
            toolName: step.toolName,
            params: step.params,
            riskLevel: step.riskLevel,
            reason: `Autonomous action requires Level ${step.riskLevel} confirmation to ensure system integrity.`,
            warningDetails: [
              `Target Tool: ${step.toolName}()`,
              step.riskLevel >= 3
                ? 'High Risk: Action involves system state, permanent modification, or elevation.'
                : 'Moderate Risk: Action involves file movement or software installation.',
              'Audit log will record this action under your authorization.',
            ],
            onConfirm: () => {
              setConfirmationReq(null);
              resolve(true);
            },
            onReject: () => {
              setConfirmationReq(null);
              resolve(false);
            },
          });
        });

        if (!approved) {
          setCurrentPlan((prev) => {
            if (!prev) return null;
            const updated = [...prev.steps];
            updated[i].status = 'failed';
            updated[i].result = 'Aborted by user in safety authorization.';
            return { ...prev, status: 'cancelled', steps: updated };
          });
          speakJarvisResponse('Operation aborted by your command, sir.');
          setAiState('IDLE');
          return;
        }
      }

      // Execute Tool via Backend API
      try {
        SoundEffects.playExecuteChirp(settings.audioFeedback);

        // Show verifying state
        setAiState('VERIFYING');
        setSubText(`Verifying output for: ${step.description}`);

        setCurrentPlan((prev) => {
          if (!prev) return null;
          const updated = [...prev.steps];
          updated[i].status = 'verifying';
          return { ...prev, steps: updated };
        });

        const res = await fetch('/api/tools/execute', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            toolName: step.toolName,
            params: step.params,
            riskLevel: step.riskLevel,
            userApproved: true,
          }),
        });

        const resultData = await res.json();
        const isSuccessAndVerified = resultData.success && resultData.verified;

        // Browser preview trigger if browser search tool
        if (step.toolName === 'browser_search') {
          const q = step.params.query || 'Minecraft tutorials';
          const eng = step.params.engine || 'youtube';
          const url =
            eng === 'youtube'
              ? `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`
              : `https://www.google.com/search?q=${encodeURIComponent(q)}`;

          setBrowserPreview({
            isOpen: true,
            url,
            pageTitle: `${q} - ${eng.toUpperCase()} Search`,
            actionLog: [
              'Initialized Playwright browser context',
              `Navigated to ${url}`,
              'Verified page DOM ready state (complete)',
              'Extracted top video results and title metadata',
            ],
            activeTab: `${eng.toUpperCase()}: ${q}`,
            tabs: [`${eng.toUpperCase()}: ${q}`, 'GitHub', 'System Dashboard'],
          });
        }

        // Record undoable actions
        if (resultData.undoable && resultData.undoRecord) {
          setUndoStack((prev) => [resultData.undoRecord.id, ...prev]);
        }

        // Update step status with verification result
        setCurrentPlan((prev) => {
          if (!prev) return null;
          const updated = [...prev.steps];
          updated[i].status = isSuccessAndVerified ? 'completed' : 'failed';
          updated[i].verified = resultData.verified;
          updated[i].result = resultData.output;
          updated[i].verificationMessage = resultData.verificationMessage;
          updated[i].durationMs = resultData.durationMs;
          return {
            ...prev,
            progressPercent: ((i + 1) / plan.steps.length) * 100,
            steps: updated,
          };
        });

        // Formulate spoken verified outcome
        let verifiedSpokenResponse = resultData.output;
        try {
          const formRes = await fetch('/api/chat/formulate-response', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userCommand: plan.userCommand,
              toolName: step.toolName,
              result: resultData.output,
              verified: resultData.verified,
              success: resultData.success,
              error: resultData.error,
            }),
          });
          if (formRes.ok) {
            const formData = await formRes.json();
            if (formData.response) {
              verifiedSpokenResponse = formData.response;
            }
          }
        } catch {
          // fallback
        }

        await speakJarvisResponse(verifiedSpokenResponse);

        if (!isSuccessAndVerified) {
          setCurrentPlan((prev) => (prev ? { ...prev, status: 'error' } : null));
          setAiState('ERROR');
          return;
        }

        // Realistic execution pacing
        await new Promise((r) => setTimeout(r, 650));
      } catch (stepErr: any) {
        setCurrentPlan((prev) => {
          if (!prev) return null;
          const updated = [...prev.steps];
          updated[i].status = 'failed';
          updated[i].result = stepErr?.message || 'Tool execution failed';
          return { ...prev, status: 'error', steps: updated };
        });
        setAiState('ERROR');
        speakJarvisResponse(`An error occurred on step ${i + 1}. The task has been paused.`);
        return;
      }
    }

    // Task finished successfully!
    SoundEffects.playTaskComplete(settings.audioFeedback);
    setAiState('SUCCESS');
    setCurrentPlan((prev) => (prev ? { ...prev, status: 'completed', progressPercent: 100 } : null));
    setTimeout(() => {
      if (voiceService.getSessionStatus() === 'ACTIVE') {
        setAiState('LISTENING');
        setSubText('Active Conversation — Listening (No wake word required)...');
        voiceService.setConversationState('LISTENING');
        voiceService.resumeInactivityTimer();
      } else {
        setAiState('IDLE');
        setSubText('"How may I assist you, sir?"');
      }
    }, 2500);
  };

  // Reversible Undo Action Handler
  const handleUndoLastAction = async (undoId?: string) => {
    try {
      const res = await fetch('/api/tools/undo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ undoId }),
      });
      const data = await res.json();
      if (data.success) {
        SoundEffects.playExecuteChirp(settings.audioFeedback);
        speakJarvisResponse(data.message);
        setActivityLogs((prev) => [
          {
            id: `undo-log-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            assistantResponse: data.message,
            riskLevel: 1,
            status: 'warning',
            details: `Rollback completed: ${data.message}`,
          },
          ...prev,
        ]);
      } else {
        speakJarvisResponse(data.message || 'No reversible operations in undo buffer.');
      }
    } catch {
      speakJarvisResponse('Unable to revert operation at this time, sir.');
    }
  };

  // Run Custom Automation Routine
  const runCustomAutomation = (rule: AutomationRule) => {
    const rawActions = Array.isArray(rule.actions) ? rule.actions : [];
    const plan: TaskPlan = {
      id: `auto-run-${Date.now()}`,
      title: rule.name,
      userCommand: rule.triggerPhrase,
      status: 'running',
      state: 'EXECUTING',
      progressPercent: 0,
      currentStepIndex: 0,
      steps: rawActions.map((a, idx) => ({
        id: `auto-step-${idx}`,
        stepNumber: idx + 1,
        description: a.description,
        toolName: a.toolName,
        params: a.params,
        riskLevel: 1,
        status: 'pending',
      })),
      startedAt: new Date().toLocaleTimeString(),
    };

    setCurrentPlan(plan);
    setIsTasksOpen(true);
    speakJarvisResponse(`Executing routine "${rule.name}", sir.`);
    executeTaskPlan(plan);
  };

  // If Minimized Mode is active, render only the floating interactive orb
  if (isMinimized) {
    return (
      <div className="fixed inset-0 pointer-events-none z-50">
        <div className="pointer-events-auto">
          <MinimizedOrb
            state={aiState}
            onExpand={() => setIsMinimized(false)}
            accentColor={settings.accentColor}
            isListening={isListening}
            voiceLevel={voiceLevel}
          />
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen bg-[#03060a] text-slate-100 flex flex-col relative select-none cyber-grid overflow-hidden transition-all duration-500 ${
        isFullscreen ? 'fixed inset-0 z-50' : ''
      }`}
    >
      {/* Optional Futuristic HUD Scanlines Overlay */}
      {settings.hudScanlines && (
        <div className="fixed inset-0 scanlines-overlay pointer-events-none z-40 opacity-30" />
      )}

      {/* TOP DESKTOP WINDOW / HUD BAR */}
      <header className="h-14 border-b border-white/10 bg-[#060a12]/80 backdrop-blur-xl px-5 flex items-center justify-between z-30 shrink-0">
        {/* Left: OS Title & Wake Word Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="font-orbitron font-bold text-sm tracking-[0.2em] text-slate-100">
              JARVIS
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-semibold tracking-wider hidden sm:inline">
              OS v4.8
            </span>
          </div>

          <div className="h-4 w-[1px] bg-white/10 hidden sm:block" />

          {/* Wake Word Status */}
          <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
            <span
              className={`w-2 h-2 rounded-full ${
                isListening
                  ? 'bg-rose-500 animate-ping'
                  : settings.wakeWordEnabled
                  ? 'bg-emerald-400 animate-pulse'
                  : 'bg-slate-500'
              }`}
            />
            <span className="hidden md:inline">
              {isListening
                ? 'LISTENING ACTIVE'
                : settings.wakeWordEnabled
                ? 'WAKE WORD: ACTIVE (Say "Hey Jarvis")'
                : 'VOICE STANDBY'}
            </span>
          </div>
        </div>

        {/* Center: Host PC Bridge Status */}
        <div className="hidden lg:flex items-center gap-2 text-xs font-mono">
          <button
            onClick={() => setIsDiagnosticsOpen(true)}
            className={`px-3 py-1 rounded-full border flex items-center gap-2 transition-all ${
              bridgeConnected
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/30'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                bridgeConnected ? 'bg-emerald-400' : 'bg-cyan-400'
              }`}
            />
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              {bridgeConnected ? 'WINDOWS HOST BRIDGE CONNECTED' : 'PHYSICAL PC ISOLATED · SANDBOX MODE'}
            </span>
          </button>
        </div>

        {/* Right: Window Controls */}
        <div className="flex items-center gap-2">
          {/* View Mode Switcher (HUD / Routines / Memory) */}
          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10 text-[11px] font-mono mr-1">
            <button
              onClick={() => setActiveView('hud')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                activeView === 'hud'
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CORE
            </button>
            <button
              onClick={() => setActiveView('automations')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                activeView === 'automations'
                  ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ROUTINES
            </button>
            <button
              onClick={() => setActiveView('memory')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                activeView === 'memory'
                  ? 'bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              MEMORY
            </button>
          </div>

          {/* Developer Session Status Panel Trigger */}
          <button
            onClick={() => setIsDevStatusOpen(!isDevStatusOpen)}
            title="Open Developer Status Panel (Session, Wake-Word, 30s Inactivity Timer)"
            className={`px-2.5 py-1 rounded-xl border flex items-center gap-1.5 transition-all font-mono text-[11px] ${
              devStatus.sessionStatus === 'ACTIVE'
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-cyan-300'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                devStatus.sessionStatus === 'ACTIVE'
                  ? 'bg-emerald-400 animate-pulse'
                  : 'bg-slate-500'
              }`}
            />
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              {devStatus.sessionStatus === 'ACTIVE'
                ? `DEV STATUS: ACTIVE (${devStatus.inactivitySeconds}s)`
                : 'DEV STATUS: SLEEPING'}
            </span>
          </button>

          {/* Minimize button */}
          <button
            onClick={() => setIsMinimized(true)}
            title="Minimize to floating AI Orb in corner"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>

          {/* Fullscreen toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Cinema / Fullscreen Mode'}
            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-white/10 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Settings */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            title="Settings"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN SCREEN WORKSPACE */}
      <main className="flex-1 flex flex-col justify-center items-center relative overflow-y-auto px-4 pb-28 pt-4 z-20">
        {activeView === 'hud' ? (
          <div className="w-full max-w-4xl flex flex-col items-center justify-center space-y-2 animate-in fade-in duration-500">
            {/* Title above Core: J A R V I S */}
            <div className="flex flex-col items-center text-center space-y-1 mb-2">
              <h1 className="font-orbitron font-black text-2xl sm:text-3xl tracking-[0.4em] text-slate-100 uppercase select-none drop-shadow-[0_0_18px_rgba(0,210,255,0.45)]">
                J A R V I S
              </h1>
              <div className="text-[10px] font-mono tracking-[0.25em] text-cyan-400/80 uppercase">
                // NEURAL OPERATING SYSTEM · MARK 85
              </div>
            </div>

            {/* Prominent Multi-Layer AI Core */}
            <AICore
              state={aiState}
              onClick={toggleVoiceListening}
              accentColor={settings.accentColor}
              subText={subText}
              isListening={isListening}
              voiceLevel={voiceLevel}
              fullscreen={isFullscreen}
            />

            {/* Glowing Center Horizontal Divider */}
            <div className="w-64 sm:w-80 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent my-3" />

            {/* HUD Telemetry Readout Strip (CPU, RAM, GPU, NET) */}
            <div
              id="jarvis-telemetry-readout"
              onClick={() => setIsHudOpen(true)}
              title="Click to view full Holographic Telemetry HUD"
              className="flex items-center gap-6 sm:gap-10 py-2.5 px-6 rounded-2xl bg-[#060a12]/80 border border-white/5 hover:border-cyan-500/40 hover:bg-[#090f1d] backdrop-blur-md shadow-lg shadow-black/40 cursor-pointer transition-all duration-300 group"
            >
              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-500 tracking-wider">CPU</span>
                <span className="text-sm font-mono font-bold text-cyan-300 group-hover:text-cyan-200 transition-colors">
                  {metrics.cpu}%
                </span>
              </div>

              <div className="h-6 w-[1px] bg-white/10" />

              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-500 tracking-wider">RAM</span>
                <span className="text-sm font-mono font-bold text-sky-300 group-hover:text-sky-200 transition-colors">
                  {metrics.ram}%
                </span>
              </div>

              <div className="h-6 w-[1px] bg-white/10" />

              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-500 tracking-wider">GPU</span>
                <span className="text-sm font-mono font-bold text-indigo-300 group-hover:text-indigo-200 transition-colors">
                  {metrics.gpu}%
                </span>
              </div>

              <div className="h-6 w-[1px] bg-white/10" />

              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-500 tracking-wider">NET</span>
                <span className="text-sm font-mono font-bold text-emerald-400 group-hover:text-emerald-300 transition-colors">
                  ACTIVE
                </span>
              </div>
            </div>

            {/* Quick Action Center Buttons: [ MICROPHONE ]  [ COMMAND ] */}
            <div className="flex items-center gap-3 sm:gap-4 pt-2">
              <button
                onClick={toggleVoiceListening}
                className={`px-6 py-2.5 rounded-xl font-mono text-xs font-bold tracking-wider flex items-center gap-2.5 transition-all duration-300 ${
                  isListening
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-[0_0_24px_rgba(244,63,94,0.65)] animate-pulse'
                    : 'bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 shadow-[0_0_15px_rgba(0,210,255,0.2)] hover:shadow-[0_0_20px_rgba(0,210,255,0.35)]'
                }`}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>{isListening ? 'STOP LISTENING' : 'MICROPHONE'}</span>
              </button>

              <button
                onClick={() => setIsCommandPaletteOpen(true)}
                className="px-6 py-2.5 rounded-xl font-mono text-xs font-bold tracking-wider flex items-center gap-2.5 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-500/40 text-slate-200 hover:text-cyan-300 transition-all duration-300"
              >
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>COMMAND</span>
              </button>
            </div>

            {/* Collapsible 10-Step Verified Acceptance Suite */}
            <div className="pt-2 flex flex-col items-center">
              <button
                onClick={() => setShowAcceptancePills(!showAcceptancePills)}
                className="text-[11px] font-mono text-slate-500 hover:text-cyan-400 flex items-center gap-1.5 transition-colors py-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>10-Step Verified Windows Acceptance Suite</span>
                {showAcceptancePills ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {showAcceptancePills && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 pt-2 max-w-2xl animate-in fade-in">
                  {[
                    'Jarvis, open Notepad.',
                    'Jarvis, close Notepad.',
                    'Jarvis, open Chrome.',
                    'Jarvis, create a folder called JarvisTest on my Desktop.',
                    'Jarvis, find JarvisTest.',
                    'Jarvis, delete JarvisTest.',
                    'Hey Jarvis, open Calculator.',
                    'Jarvis, tell me my CPU usage.',
                    'Jarvis, tell me how much RAM I\'m using.',
                    'Jarvis, take a screenshot.',
                  ].map((phrase, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleExecuteCommand(phrase)}
                      className="p-2 rounded-lg bg-[#070b14]/70 border border-white/5 hover:border-cyan-500/40 hover:bg-[#0c1424] text-slate-300 text-left transition-all truncate text-[11px] font-mono"
                      title={phrase}
                    >
                      <span className="text-cyan-400 font-bold mr-1">#{idx + 1}</span>
                      {phrase}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : activeView === 'automations' ? (
          <div className="w-full max-w-4xl animate-in fade-in">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setActiveView('hud')}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5"
              >
                ← Return to AI Core
              </button>
            </div>
            <AutomationsBuilder
              automations={automations}
              onAddAutomation={(newRule) => {
                setAutomations((prev) => [
                  ...prev,
                  {
                    ...newRule,
                    id: `auto-${Date.now()}`,
                    createdAt: new Date().toISOString().split('T')[0],
                  },
                ]);
                speakJarvisResponse(`New voice automation "${newRule.name}" saved, sir.`);
              }}
              onToggleAutomation={(id) => {
                setAutomations((prev) =>
                  prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
                );
              }}
              onDeleteAutomation={(id) => {
                setAutomations((prev) => prev.filter((a) => a.id !== id));
              }}
              onRunAutomation={runCustomAutomation}
            />
          </div>
        ) : (
          <div className="w-full max-w-4xl animate-in fade-in">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setActiveView('hud')}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5"
              >
                ← Return to AI Core
              </button>
            </div>
            <MemoryManager
              memories={memories}
              enabled={settings.enableMemory}
              onToggleMemory={(enabled) => setSettings({ ...settings, enableMemory: enabled })}
              onAddMemory={async (item) => {
                try {
                  const res = await fetch('/api/memory', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(item),
                  });
                  if (res.ok) {
                    const data = await res.json();
                    setMemories((prev) => [data.memory, ...prev]);
                    speakJarvisResponse(`I have committed that to long-term memory, sir.`);
                  }
                } catch {
                  // ignore
                }
              }}
              onDeleteMemory={async (id) => {
                try {
                  await fetch(`/api/memory/${id}`, { method: 'DELETE' });
                  setMemories((prev) => prev.filter((m) => m.id !== id));
                } catch {
                  // ignore
                }
              }}
              onClearAll={() => setMemories([])}
            />
          </div>
        )}
      </main>

      {/* FLOATING FUTURISTIC CONTROL BAR */}
      <FloatingControlBar
        isListening={isListening}
        onToggleMic={toggleVoiceListening}
        onOpenCommand={() => setIsCommandPaletteOpen(true)}
        onToggleTasks={() => setIsTasksOpen(!isTasksOpen)}
        isTasksOpen={isTasksOpen}
        hasActiveTask={Boolean(currentPlan && currentPlan.status === 'running')}
        onToggleConversation={() => setIsConversationOpen(!isConversationOpen)}
        isConversationOpen={isConversationOpen}
        onToggleHud={() => setIsHudOpen(!isHudOpen)}
        isHudOpen={isHudOpen}
        onOpenMemory={() => setActiveView(activeView === 'memory' ? 'hud' : 'memory')}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        accentColor={settings.accentColor}
      />

      {/* COLLAPSIBLE LEFT PANEL: CONVERSATION STREAM */}
      <ConversationPanel
        isOpen={isConversationOpen}
        onClose={() => setIsConversationOpen(false)}
        logs={activityLogs}
        onClearLogs={() => setActivityLogs([])}
        onExecuteCommand={handleExecuteCommand}
        onUndoItem={handleUndoLastAction}
        accentColor={settings.accentColor}
      />

      {/* COLLAPSIBLE RIGHT PANEL: LIVE TASK EXECUTION DRAWER */}
      <LiveTaskDrawer
        isOpen={isTasksOpen}
        onClose={() => setIsTasksOpen(false)}
        currentPlan={currentPlan}
        onPause={() => {
          taskPausedRef.current = true;
          setCurrentPlan((prev) => (prev ? { ...prev, status: 'paused' } : null));
        }}
        onResume={() => {
          taskPausedRef.current = false;
          setCurrentPlan((prev) => (prev ? { ...prev, status: 'running' } : null));
        }}
        onCancel={() => {
          taskCancellationRef.current = true;
          setCurrentPlan((prev) => (prev ? { ...prev, status: 'cancelled' } : null));
          speakJarvisResponse('Task has been stopped.');
        }}
        onUndoLast={handleUndoLastAction}
        canUndo={undoStack.length > 0}
        accentColor={settings.accentColor}
      />

      {/* HOLOGRAPHIC SYSTEM TELEMETRY HUD MODAL */}
      <HolographicHud
        metrics={metrics}
        isOpen={isHudOpen}
        onClose={() => setIsHudOpen(false)}
        onKillProcess={(pid) => handleExecuteCommand(`kill process ${pid}`)}
        accentColor={settings.accentColor}
      />

      {/* FLOATING COMMAND INPUT PALETTE */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        input={commandInput}
        onInputChange={setCommandInput}
        onSubmit={handleExecuteCommand}
        isListening={isListening}
        onToggleMic={toggleVoiceListening}
        accentColor={settings.accentColor}
      />

      {/* SAFETY AUTHORIZATION MODAL FOR LEVEL 2/3 ACTIONS */}
      <ConfirmationModal
        request={confirmationReq}
        onConfirm={() => confirmationReq?.onConfirm()}
        onReject={() => confirmationReq?.onReject()}
      />

      {/* BROWSER AUTOMATION VIEWPORT SIMULATION */}
      <BrowserPreviewModal
        isOpen={browserPreview.isOpen}
        onClose={() => setBrowserPreview((prev) => ({ ...prev, isOpen: false }))}
        url={browserPreview.url}
        pageTitle={browserPreview.pageTitle}
        actionLog={browserPreview.actionLog}
        activeTab={browserPreview.activeTab}
        tabs={browserPreview.tabs}
      />

      {/* COMPREHENSIVE SETTINGS MODAL */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          voiceService.setWakeWord(newSettings.wakeWord);
          speakJarvisResponse('System configuration updated.');
        }}
        availableVoices={availableVoices}
      />

      {/* HOST PC BRIDGE & 15-STEP DIAGNOSTIC SUITE MODAL */}
      <BridgeAndDiagnosticsPanel
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        onRunCommand={handleExecuteCommand}
      />

      {/* DEDICATED PERSISTENT SESSION & WAKE WORD DEVELOPER STATUS PANEL */}
      <DeveloperStatusPanel
        isOpen={isDevStatusOpen}
        onClose={() => setIsDevStatusOpen(false)}
        onExecuteCommand={handleExecuteCommand}
      />
    </div>
  );
}
