import React from 'react';
import { TaskPlan, AccentColor } from '../types';
import {
  Layers,
  X,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ShieldCheck,
  Ban,
  Search,
} from 'lucide-react';

interface LiveTaskDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TaskPlan | null;
  onPause?: () => void;
  onResume?: () => void;
  onCancel?: () => void;
  onUndoLast?: () => void;
  canUndo?: boolean;
  accentColor?: AccentColor;
}

export const LiveTaskDrawer: React.FC<LiveTaskDrawerProps> = ({
  isOpen,
  onClose,
  currentPlan,
  onPause,
  onResume,
  onCancel,
  onUndoLast,
  canUndo = false,
  accentColor = 'blue',
}) => {
  if (!isOpen) return null;

  const planSteps = Array.isArray(currentPlan?.steps) ? currentPlan!.steps : [];
  const isRunning = currentPlan?.status === 'running';
  const isPaused = currentPlan?.status === 'paused';
  const isCompleted = currentPlan?.status === 'completed';

  const progress = currentPlan?.progressPercent ?? 0;

  return (
    <aside
      id="jarvis-live-task-drawer"
      className="fixed inset-y-0 right-0 w-80 sm:w-96 z-40 bg-[#060a12]/90 backdrop-blur-xl border-l border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.8)] flex flex-col transition-all duration-300 animate-in slide-in-from-right"
    >
      {/* Top Header */}
      <div className="h-14 px-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#070d18]/60">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Layers className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="text-xs font-mono font-bold tracking-wider text-slate-100 uppercase">
              LIVE TASK ENGINE
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              {currentPlan ? `STATUS: ${currentPlan.status.toUpperCase()}` : 'ENGINE IDLE'}
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          title="Close live task panel"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
        {!currentPlan ? (
          <div className="flex flex-col items-center justify-center text-center h-64 text-slate-500 text-xs font-mono px-4">
            <Layers className="w-8 h-8 text-slate-600 mb-3 animate-pulse-subtle" />
            <div className="text-slate-300 font-semibold uppercase tracking-wider mb-1">
              No Active Task
            </div>
            <p className="text-slate-500 text-[11px] leading-relaxed">
              When you ask JARVIS to execute actions, autonomous multi-step sequences will stream here with real-time verification.
            </p>

            {canUndo && (
              <button
                onClick={onUndoLast}
                className="mt-4 px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center gap-1.5 hover:bg-amber-500/25 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo Reversible Action</span>
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Active Task Card */}
            <div className="p-3.5 rounded-xl bg-[#090e1c] border border-cyan-500/30 shadow-[0_0_20px_rgba(0,210,255,0.1)] space-y-3">
              <div className="flex items-center justify-between text-[10px] font-mono">
                <span className="text-cyan-400 font-bold uppercase tracking-widest">
                  CURRENT TASK
                </span>
                <span className="text-slate-400">
                  {currentPlan.currentStepIndex + 1} / {planSteps.length}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-100 font-mono tracking-wide leading-snug">
                {currentPlan.title}
              </h3>

              {/* Progress Bar with High-Tech Percentage */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">Execution Progress</span>
                  <span className="text-cyan-300 font-bold">{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
                    style={{ width: `${Math.max(4, Math.min(100, progress))}%` }}
                  />
                </div>
              </div>

              {/* Action Controls: Pause, Resume, Cancel */}
              <div className="flex items-center gap-2 pt-1">
                {isRunning && onPause && (
                  <button
                    onClick={onPause}
                    className="flex-1 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause</span>
                  </button>
                )}

                {isPaused && onResume && (
                  <button
                    onClick={onResume}
                    className="flex-1 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Resume</span>
                  </button>
                )}

                {onCancel && (isRunning || isPaused) && (
                  <button
                    onClick={onCancel}
                    className="flex-1 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>Cancel Task</span>
                  </button>
                )}
              </div>
            </div>

            {/* Sequence Steps List */}
            <div className="space-y-2">
              <div className="text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider px-1">
                Execution Steps
              </div>

              <div className="space-y-1.5">
                {planSteps.map((step, idx) => {
                  const isDone = step.status === 'completed';
                  const isCur = step.status === 'running';
                  const isVerifying = step.status === 'verifying';
                  const isWait = step.status === 'waiting_approval';
                  const isFail = step.status === 'failed';
                  const isPending = step.status === 'pending';

                  return (
                    <div
                      key={step.id || idx}
                      className={`p-2.5 rounded-lg border text-xs font-mono transition-all flex items-start gap-2.5 ${
                        isDone
                          ? 'bg-emerald-500/5 border-emerald-500/20 text-slate-300'
                          : isCur || isVerifying
                          ? 'bg-cyan-500/15 border-cyan-500/40 text-slate-100 shadow-[0_0_12px_rgba(0,210,255,0.15)]'
                          : isWait
                          ? 'bg-amber-500/15 border-amber-500/40 text-amber-200'
                          : isFail
                          ? 'bg-rose-500/10 border-rose-500/30 text-rose-200'
                          : 'bg-[#070b14]/60 border-white/5 text-slate-500'
                      }`}
                    >
                      {/* Step Icon */}
                      <div className="mt-0.5 shrink-0">
                        {isDone ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : isCur ? (
                          <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                        ) : isVerifying ? (
                          <Search className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
                        ) : isWait ? (
                          <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                        ) : isFail ? (
                          <Ban className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <span className="w-3.5 h-3.5 rounded-full border border-slate-700 flex items-center justify-center text-[9px] text-slate-600">
                            {idx + 1}
                          </span>
                        )}
                      </div>

                      {/* Step Description & Status */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-semibold truncate">
                            {step.description}
                          </span>
                          <span className="text-[9px] text-slate-400 shrink-0 uppercase">
                            {step.status}
                          </span>
                        </div>

                        {step.toolName && (
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            Tool: <span className="text-cyan-400/80">{step.toolName}()</span>
                          </div>
                        )}

                        {step.verificationMessage && (
                          <div className="text-[10px] text-emerald-400/90 mt-1 pl-2 border-l border-emerald-500/40">
                            ✓ {step.verificationMessage}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Task Completed Banner */}
            {isCompleted && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Task finished and verified with physical host parameters.</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-white/10 bg-[#070d18]/40 text-center">
        <span className="text-[10px] font-mono text-slate-500">
          Safety Level 0-4 Guardrails Active
        </span>
      </div>
    </aside>
  );
};
