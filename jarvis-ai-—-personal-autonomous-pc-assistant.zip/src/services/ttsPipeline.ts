/**
 * J.A.R.V.I.S. SPEECH & TTS PIPELINE
 *
 * Implements the required pipeline:
 * AI RESPONSE
 *     ↓
 * Response Formatter
 *     ↓
 * TTS Text Cleaner
 *     ↓
 * Remove URLs / Markdown / Code
 *     ↓
 * Split into natural sentences
 *     ↓
 * TTS
 *     ↓
 * Voice
 */

import {
  preprocessTtsSpeechText,
  TtsPreprocessorOptions,
  TtsCleanedSpeechResult,
  userExplicitlyRequestedUrl,
  extractWebsiteNameFromUrl,
} from './ttsPreprocessor';

export {
  preprocessTtsSpeechText,
  userExplicitlyRequestedUrl,
  extractWebsiteNameFromUrl,
};
export type { TtsPreprocessorOptions, TtsCleanedSpeechResult };

export interface TtsPipelineStageResult {
  rawAiResponse: string;
  formattedText: string;
  cleanedText: string;
  sentences: string[];
  metrics: {
    urlsRemoved: number;
    codeBlocksRemoved: number;
    markdownStripped: boolean;
    sentenceCount: number;
    estimatedDurationSec: number;
  };
}

export interface PipelineProgressEvent {
  stage: 'AI_RESPONSE' | 'FORMATTER' | 'CLEANER' | 'URL_MD_CODE_REMOVER' | 'SENTENCE_SPLITTER' | 'TTS_DISPATCH' | 'VOICE_OUTPUT' | 'IDLE';
  currentSentenceIndex: number;
  totalSentences: number;
  activeSentence: string;
  progressPercent: number;
}

/**
 * 1. RESPONSE FORMATTER
 * Normalizes raw AI responses, formats polite executive responses,
 * removes JSON fragments, fixes capitalization and expands spoken abbreviations.
 */
export function formatAiResponse(
  rawText: string,
  options: {
    assistantName?: string;
    personality?: 'formal' | 'witty' | 'concise' | 'technical';
  } = {}
): string {
  if (!rawText || typeof rawText !== 'string') return '';

  let text = rawText.trim();

  // Strip JSON wrapper remnants if AI accidentally output raw JSON
  if (text.startsWith('{') && text.endsWith('}')) {
    try {
      const parsed = JSON.parse(text);
      if (parsed.reply) text = String(parsed.reply);
      else if (parsed.response) text = String(parsed.response);
      else if (parsed.message) text = String(parsed.message);
    } catch {
      // Not JSON, continue
    }
  }

  // Strip leading/trailing surrounding quotes
  if ((text.startsWith('"') && text.endsWith('"')) || (text.startsWith("'") && text.endsWith("'"))) {
    text = text.slice(1, -1).trim();
  }

  // Strip model thinking tokens or tags like <think>...</think>
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

  // Expand common technical acronyms into spoken phonetics
  text = text
    .replace(/\bCPU\b/g, 'C P U')
    .replace(/\bRAM\b/g, 'RAM')
    .replace(/\bGPU\b/g, 'G P U')
    .replace(/\bOS\b/g, 'O S')
    .replace(/\bAPI\b/g, 'A P I')
    .replace(/\bUI\b/g, 'U I')
    .replace(/\bPC\b/g, 'P C')
    .replace(/\bPID\b/g, 'P I D')
    .replace(/\bKB\/s\b/gi, 'kilobytes per second')
    .replace(/\bMB\/s\b/gi, 'megabytes per second')
    .replace(/\bGB\b/gi, 'gigabytes')
    .replace(/\bMB\b/gi, 'megabytes')
    .replace(/\bKB\b/gi, 'kilobytes')
    .replace(/\bTemp\b/g, 'Temperature')
    .replace(/\bvs\.\b/gi, 'versus')
    .replace(/\be\.g\.,?\b/gi, 'for example')
    .replace(/\bi\.e\.,?\b/gi, 'that is');

  // Polish spacing and punctuation
  text = text.replace(/\s+/g, ' ').trim();

  return text;
}

/**
 * 2 & 3. TTS TEXT CLEANER + REMOVE URLS / MARKDOWN / CODE
 * Strips all elements that should not be spoken aloud by TTS:
 * - URLs (or converts to clean site names like "YouTube" or "Google")
 * - Markdown tokens (bold, italics, headers, lists, blockquotes, tables)
 * - Code fences, inline backticks, scripts, file system hashes, UUIDs
 * - Emojis and unpronounceable symbols
 */
export function cleanTtsText(
  formattedText: string
): { cleanText: string; urlsRemoved: number; codeBlocksRemoved: number; markdownStripped: boolean } {
  if (!formattedText) {
    return { cleanText: '', urlsRemoved: 0, codeBlocksRemoved: 0, markdownStripped: false };
  }

  let text = formattedText;
  let urlsRemoved = 0;
  let codeBlocksRemoved = 0;
  let markdownStripped = false;

  // 1. Remove multi-line code blocks: ```lang ... ```
  const codeBlockMatch = text.match(/```[\s\S]*?```/g);
  if (codeBlockMatch) {
    codeBlocksRemoved = codeBlockMatch.length;
    text = text.replace(/```[\s\S]*?```/g, ' ');
    markdownStripped = true;
  }

  // 2. Remove inline code snippets: `code`
  if (/`[^`]+`/.test(text)) {
    // If it looks like a function call or command, simplify
    text = text.replace(/`([^`]+)`/g, (_match, codeContent) => {
      // Remove symbols from code
      return codeContent.replace(/[()[\]{}$;]/g, ' ').trim();
    });
    markdownStripped = true;
  }

  // 3. Remove/Sanitize URLs
  // Convert standard markdown links [text](url) -> text
  text = text.replace(/\[([^\]]+)\]\((?:https?:\/\/[^\s)]+)\)/g, '$1');

  // Replace prominent known domains with spoken words
  text = text.replace(/https?:\/\/(?:www\.)?youtube\.com\S*/gi, () => {
    urlsRemoved++;
    return 'YouTube';
  });
  text = text.replace(/https?:\/\/(?:www\.)?google\.com\S*/gi, () => {
    urlsRemoved++;
    return 'Google';
  });
  text = text.replace(/https?:\/\/(?:www\.)?github\.com\S*/gi, () => {
    urlsRemoved++;
    return 'GitHub';
  });

  // Strip any remaining raw URLs (http://, https://, www.)
  const rawUrls = text.match(/https?:\/\/[^\s]+/gi) || [];
  urlsRemoved += rawUrls.length;
  text = text.replace(/https?:\/\/[^\s]+/gi, ' ');
  text = text.replace(/www\.[a-z0-9-]+\.[a-z]{2,}[^\s]*/gi, ' ');

  // 4. Strip Markdown Syntax
  // Headers: # Header
  if (/#{1,6}\s+/m.test(text)) {
    text = text.replace(/^#{1,6}\s+/gm, '');
    markdownStripped = true;
  }

  // Bold & Italic: **bold**, *italic*, __bold__, _italic_
  text = text.replace(/\*\*\*([^*]+)\*\*\*/g, '$1');
  text = text.replace(/\*\*([^*]+)\*\*/g, '$1');
  text = text.replace(/\*([^*]+)\*/g, '$1');
  text = text.replace(/___([^_]+)___/g, '$1');
  text = text.replace(/__([^_]+)__/g, '$1');
  text = text.replace(/_([^_]+)_/g, '$1');

  // Strikethrough ~~text~~
  text = text.replace(/~~([^~]+)~~/g, '$1');

  // Blockquotes: > quote
  text = text.replace(/^\s*>\s*/gm, '');

  // Bullet points and numbering: - item, * item, 1. item
  text = text.replace(/^\s*[-*+]\s+/gm, '');
  text = text.replace(/^\s*\d+\.\s+/gm, '');

  // Markdown tables: | col | col |
  text = text.replace(/\|[^\n]+\|/g, ' ');
  text = text.replace(/[-:]{2,}\s*\|\s*[-:]{2,}/g, ' ');

  // 5. Clean technical artifacts & long paths
  // Windows paths: C:\Users\...\file.ext -> simplify
  text = text.replace(/[a-zA-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)+([^\\/:*?"<>|\r\n]+)/g, (_match, filename) => {
    return `file ${filename}`;
  });

  // HTML tags <tag>...</tag>
  text = text.replace(/<[^>]+>/g, ' ');

  // 6. Strip Emojis and unpronounceable Unicode glyphs
  text = text.replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}]/gu, '');

  // 7. Strip stray symbols like @, #, $, %, ^, &, ~, _, {, }, |, \, <, >
  // but preserve standard punctuation (. , ! ? ' " :) and percent numbers
  text = text.replace(/(\d+)\s*%/g, '$1 percent');
  text = text.replace(/[$^&~_={}|\\<>]/g, ' ');

  // Normalize excessive spaces and punctuation artifacts
  text = text.replace(/\s+/g, ' ');
  text = text.replace(/([.!?])\s*([.!?])+/g, '$1');
  text = text.trim();

  return {
    cleanText: text,
    urlsRemoved,
    codeBlocksRemoved,
    markdownStripped,
  };
}

/**
 * 4. SPLIT INTO NATURAL SENTENCES
 * Splits cleaned text into natural, spoken-cadence sentences.
 * Protects abbreviations and titles so they don't cause premature splits,
 * and breaks long compound sentences at natural pause points.
 */
export function splitIntoNaturalSentences(cleanText: string): string[] {
  if (!cleanText || !cleanText.trim()) return [];

  let text = cleanText.trim();

  // Map of abbreviations to protect with unique tokens
  const protectedMap = new Map<string, string>();
  let tokenCounter = 0;

  const abbreviations = [
    /\bMr\./gi,
    /\bMrs\./gi,
    /\bMs\./gi,
    /\bDr\./gi,
    /\bProf\./gi,
    /\bSr\./gi,
    /\bJr\./gi,
    /\bvs\./gi,
    /\betc\./gi,
    /\be\.g\./gi,
    /\bi\.e\./gi,
    /\bapprox\./gi,
    /\bdept\./gi,
    /\bFig\./gi,
    /\bNo\./gi,
    /\bSt\./gi,
    /\bv\d+\.\d+\b/gi, // e.g. v4.8
    /\b\d+\.\d+\b/g,   // decimal numbers like 3.14
  ];

  abbreviations.forEach((regex) => {
    text = text.replace(regex, (match) => {
      const token = `__PROTECTED_TOKEN_${tokenCounter++}__`;
      protectedMap.set(token, match);
      return token;
    });
  });

  // Split on sentence terminators (. ! ?) followed by whitespace or end of string,
  // or newline boundaries
  const rawSentences = text
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const finalSentences: string[] = [];

  rawSentences.forEach((sentence) => {
    // Restore protected tokens
    let restored = sentence;
    protectedMap.forEach((original, token) => {
      restored = restored.replace(new RegExp(token, 'g'), original);
    });

    restored = restored.trim();
    if (!restored) return;

    // If a sentence is very long (> 140 chars) and contains a semicolon or comma clause,
    // split it at the clause boundary for natural breathing cadence
    if (restored.length > 140 && (restored.includes(';') || restored.includes(', '))) {
      const subClauses = restored
        .split(/(?<=[;,])\s+/)
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      if (subClauses.length > 1) {
        let currentChunk = '';
        subClauses.forEach((clause) => {
          if ((currentChunk + ' ' + clause).trim().length > 120 && currentChunk.length > 0) {
            finalSentences.push(ensurePunctuation(currentChunk.trim()));
            currentChunk = clause;
          } else {
            currentChunk = currentChunk ? `${currentChunk} ${clause}` : clause;
          }
        });
        if (currentChunk.trim()) {
          finalSentences.push(ensurePunctuation(currentChunk.trim()));
        }
        return;
      }
    }

    finalSentences.push(ensurePunctuation(restored));
  });

  return finalSentences;
}

/**
 * Ensures a sentence terminates in natural spoken punctuation.
 */
function ensurePunctuation(s: string): string {
  const trimmed = s.trim();
  if (!trimmed) return '';
  const lastChar = trimmed[trimmed.length - 1];
  if (['.', '!', '?', ';', ':'].includes(lastChar)) {
    return trimmed;
  }
  return `${trimmed}.`;
}

/**
 * COMPLETE PIPELINE RUNNER
 * Executes the dedicated TTS Preprocessor:
 * AI RESPONSE → TTS PREPROCESSOR → CLEAN SPEECH TEXT → TTS ENGINE
 */
export function runTtsPipeline(
  rawAiResponse: string,
  options: {
    assistantName?: string;
    personality?: 'formal' | 'witty' | 'concise' | 'technical';
    userCommand?: string;
    allowRawUrlExplicit?: boolean;
  } = {}
): TtsPipelineStageResult {
  // Execute dedicated TTS preprocessor
  const preprocessed = preprocessTtsSpeechText(rawAiResponse, {
    userCommand: options.userCommand,
    assistantName: options.assistantName,
    personality: options.personality,
    allowRawUrlExplicit: options.allowRawUrlExplicit,
  });

  const formattedText = formatAiResponse(rawAiResponse, options);
  const cleanText = preprocessed.cleanSpeechText;
  const sentences = preprocessed.sentences;

  // Estimate duration (~140 words per minute for calm Bettany cadence)
  const wordCount = cleanText.split(/\s+/).filter(Boolean).length;
  const estimatedDurationSec = Math.max(1, Math.round((wordCount / 140) * 60));

  return {
    rawAiResponse,
    formattedText,
    cleanedText: cleanText,
    sentences,
    metrics: {
      urlsRemoved: preprocessed.metrics.urlsRemoved,
      codeBlocksRemoved: preprocessed.metrics.codeBlocksRemoved,
      markdownStripped: preprocessed.metrics.markdownStripped,
      sentenceCount: sentences.length,
      estimatedDurationSec,
    },
  };
}
