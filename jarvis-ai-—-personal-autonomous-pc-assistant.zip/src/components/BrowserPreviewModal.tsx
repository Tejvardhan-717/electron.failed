import React from 'react';
import { Globe, X, ExternalLink, ArrowLeft, ArrowRight, RotateCw, Search, ShieldCheck } from 'lucide-react';

interface BrowserPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
  pageTitle: string;
  actionLog: string[];
  activeTab: string;
  tabs: string[];
}

export const BrowserPreviewModal: React.FC<BrowserPreviewModalProps> = ({
  isOpen,
  onClose,
  url,
  pageTitle,
  actionLog,
  activeTab,
  tabs,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div
        id="jarvis-browser-automation-modal"
        className="w-full max-w-4xl h-[80vh] rounded-2xl bg-[#0b0f17] border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.7)] flex flex-col overflow-hidden"
      >
        {/* Browser Top Window Frame */}
        <div className="bg-[#070a10] px-4 py-2.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            <span className="text-xs font-mono text-slate-400 ml-2 font-semibold">
              JARVIS PLAYWRIGHT AUTOMATION ENGINE // CHROMIUM
            </span>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded hover:bg-[#121a28] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="bg-[#070a10] px-3 pt-2 border-b border-white/10 flex items-center gap-1 overflow-x-auto">
          {(tabs || []).map((tab, idx) => (
            <div
              key={idx}
              className={`px-3 py-1.5 rounded-t-lg text-xs font-mono flex items-center gap-2 max-w-[200px] truncate border-t border-x ${
                tab === activeTab
                  ? 'bg-[#0c1322] border-cyan-500/40 text-cyan-200'
                  : 'bg-transparent border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Globe className="w-3 h-3 shrink-0 text-cyan-400" />
              <span className="truncate">{tab}</span>
            </div>
          ))}
        </div>

        {/* Address Bar Navigation */}
        <div className="bg-[#0c1322] p-2.5 border-b border-white/10 flex items-center gap-3">
          <div className="flex items-center gap-1 text-slate-400">
            <button className="p-1 rounded hover:bg-slate-800 disabled:opacity-40" disabled>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
            <button className="p-1 rounded hover:bg-slate-800 disabled:opacity-40" disabled>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button className="p-1 rounded hover:bg-slate-800">
              <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>

          {/* URL Input Bar */}
          <div className="flex-1 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#070a10] border border-white/10 text-xs font-mono text-slate-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="text-emerald-400/80">https://</span>
            <span className="truncate text-slate-100">{url.replace(/^https?:\/\//, '')}</span>
          </div>

          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="p-1.5 rounded bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 text-xs font-mono flex items-center gap-1"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Webpage Content Simulation & Inspector */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 bg-[#05070a]">
          {/* Main Visual Render Area */}
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center overflow-y-auto border-r border-white/10">
            <div className="max-w-md p-6 rounded-2xl bg-[#0b0f17] border border-white/10 shadow-xl space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Globe className="w-8 h-8 animate-pulse" />
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#070a10] border border-cyan-500/30 text-cyan-300">
                  AUTOMATED BROWSER SESSION
                </span>
                <h3 className="text-base font-bold text-slate-100 mt-2">{pageTitle}</h3>
                <p className="text-xs text-slate-400 font-mono mt-1 break-all">{url}</p>
              </div>

              <div className="pt-2">
                <a
                  href={url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-bold shadow-lg shadow-cyan-600/30 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Open Direct in Browser Tab
                </a>
              </div>
            </div>
          </div>

          {/* Automation Actions Log */}
          <div className="w-full md:w-80 bg-[#070a10] p-4 flex flex-col font-mono text-xs overflow-hidden">
            <div className="flex items-center gap-2 pb-2 border-b border-white/10 text-cyan-300 font-semibold mb-2">
              <Search className="w-3.5 h-3.5" />
              <span>PLAYWRIGHT TRACE LOG</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
              {(actionLog || []).map((log, idx) => (
                <div
                  key={idx}
                  className="p-2 rounded bg-[#0c1322] border border-white/5 text-[11px] text-slate-300 flex items-start gap-1.5"
                >
                  <span className="text-cyan-400 shrink-0">›</span>
                  <span className="leading-snug">{log}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
