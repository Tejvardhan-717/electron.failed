import React from 'react';
import { AIState, AccentColor } from '../types';
import { Sparkles, Mic, Volume2, Cpu, Maximize2, Shield } from 'lucide-react';

interface MinimizedOrbProps {
  state: AIState;
  onExpand: () => void;
  accentColor?: AccentColor;
  isListening?: boolean;
  voiceLevel?: number;
}

export const MinimizedOrb: React.FC<MinimizedOrbProps> = ({
  state,
  onExpand,
  accentColor = 'blue',
  isListening = false,
  voiceLevel = 0,
}) => {
  return (
    <div
      id="jarvis-minimized-orb"
      onClick={onExpand}
      title="JARVIS OS (Minimized) — Click to restore Command Center"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-2.5 rounded-full bg-[#060a12]/90 border border-cyan-500/40 backdrop-blur-xl shadow-[0_0_30px_rgba(0,210,255,0.35)] cursor-pointer hover:scale-105 transition-all duration-300 group"
    >
      {/* Mini Glowing Core */}
      <div className="relative w-12 h-12 rounded-full flex items-center justify-center">
        {/* Outer Pulsing Aura */}
        <div
          className={`absolute inset-0 rounded-full border border-cyan-400/50 ${
            state === 'THINKING' ? 'animate-spin-fast' : 'animate-spin-slow'
          }`}
        />
        {/* Ambient Glow Bloom */}
        <div
          className="absolute inset-0 rounded-full blur-md bg-cyan-500/30"
          style={{
            transform: `scale(${1 + (voiceLevel / 100) * 0.4})`,
          }}
        />

        {/* Center Iris */}
        <div className="relative w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/50">
          {state === 'LISTENING' ? (
            <Mic className="w-4 h-4 text-white animate-bounce" />
          ) : state === 'SPEAKING' ? (
            <Volume2 className="w-4 h-4 text-white animate-pulse" />
          ) : state === 'THINKING' ? (
            <Cpu className="w-4 h-4 text-white animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4 text-white" />
          )}
        </div>
      </div>

      {/* Label & Status on Hover / Always visible on wide screens */}
      <div className="pr-3 hidden sm:flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-mono font-bold tracking-wider text-slate-100">
            JARVIS
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
        </div>
        <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">
          {state === 'LISTENING'
            ? 'LISTENING...'
            : state === 'SPEAKING'
            ? 'SPEAKING...'
            : 'ONLINE · WAKE WORD ACTIVE'}
        </span>
      </div>

      {/* Expand Icon */}
      <div className="p-1.5 rounded-full bg-white/5 group-hover:bg-cyan-500/20 text-slate-400 group-hover:text-cyan-300 transition-colors">
        <Maximize2 className="w-3.5 h-3.5" />
      </div>
    </div>
  );
};
