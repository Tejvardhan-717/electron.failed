/**
 * J.A.R.V.I.S. DEDICATED PERSISTENT CONVERSATION & VOICE ENGINE
 * 
 * Persistent Conversation State Machine:
 * 
 * SLEEPING
 *     ↓ (Wake word detected: "Hey Jarvis" / "Jarvis")
 * WAKE WORD DETECTED
 *     ↓ (Activation chime + "Yes?")
 * ACTIVATING
 *     ↓
 * ACTIVE CONVERSATION
 *     ↓
 * LISTENING
 *     ↓ (User speaks command: no wake word required)
 * THINKING
 *     ↓
 * EXECUTING (Timer paused during long-running tasks)
 *     ↓
 * SPEAKING (User speech triggers interruption / barge-in)
 *     ↓
 * ACTIVE CONVERSATION  <--- CRITICAL: REMAINS ACTIVE!
 *     ↓ (No user activity for 30s)
 * SLEEPING (Re-enables wake-word detector: Waiting for "Jarvis")
 * 
 * Explicit Exit Commands:
 * - "Goodbye Jarvis", "Go to sleep", "Stop listening", "That's all", "Sleep", "Dismissed"
 *   Immediately transitions ACTIVE CONVERSATION → SLEEPING
 */

import {
  WakeWordEngineState,
  MicrophoneStatus,
  ConversationState,
  SessionMode,
  DeveloperSessionStatus,
} from '../types';
import {
  runTtsPipeline,
  TtsPipelineStageResult,
  PipelineProgressEvent,
} from './ttsPipeline';

interface IWindowSpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: ((this: IWindowSpeechRecognition, ev: Event) => any) | null;
  onerror: ((this: IWindowSpeechRecognition, ev: any) => any) | null;
  onend: ((this: IWindowSpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: IWindowSpeechRecognition, ev: any) => any) | null;
}

export class VoiceService {
  private recognition: IWindowSpeechRecognition | null = null;
  private engineState: WakeWordEngineState = 'IDLE';
  private micStatus: MicrophoneStatus = 'DISCONNECTED';
  private wakeWord = 'jarvis';
  private wakeWordRegex = /\b(hey\s+)?jarvis\b/i;

  // Persistent Conversation Session State
  private sessionStatus: SessionMode = 'SLEEPING';
  private conversationState: ConversationState = 'SLEEPING';
  private inactivitySeconds = 0;
  private readonly inactivityMaxSeconds = 30;
  private isTimerPaused = false;
  private pauseReason: string | undefined = undefined;
  private inactivityInterval: any = null;

  // Explicit Exit Phrases
  private readonly exitCommandRegex =
    /^(goodbye(\s+jarvis)?|bye(\s+jarvis)?|go\s+to\s+sleep|stop\s+listening|that'?s\s+all(\s+jarvis)?|that\s+is\s+all(\s+jarvis)?|sleep(\s+now)?|dismissed(\s+jarvis)?)[.!]?$/i;

  // Audio & Hardware Monitoring
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private currentVolume = 0; // 0 to 100
  private audioLevelCheckInterval: number | null = null;
  private sensitivityThreshold = 15; // 0-100 threshold

  // Callbacks
  private onCommandCallback: ((command: string) => void) | null = null;
  private onInterimCallback: ((interim: string) => void) | null = null;
  private onStateChangeCallback: ((state: WakeWordEngineState) => void) | null = null;
  private onSessionStateCallback: ((convState: ConversationState, sessionMode: SessionMode) => void) | null = null;
  private onInactivityTickCallback: ((seconds: number, max: number, isPaused: boolean, reason?: string) => void) | null = null;
  private onDeveloperStatusCallback: ((status: DeveloperSessionStatus) => void) | null = null;
  private onMicStatusCallback: ((status: MicrophoneStatus) => void) | null = null;
  private onVolumeChangeCallback: ((volume: number) => void) | null = null;
  private onSessionTimeoutCallback: (() => void) | null = null;
  private onWakeWordPromptCallback: (() => void) | null = null;

  private continuousWakeWordActive = true;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;
  private lastSpokenText = '';
  private lastCommand = '';
  private recognitionRestartTimeout: any = null;

  // TTS Pipeline Trace & Real-time Progress Tracking
  private lastPipelineTrace: TtsPipelineStageResult | null = null;
  private onPipelineProgressCallback: ((event: PipelineProgressEvent) => void) | null = null;

  constructor() {
    this.initRecognition();
    this.startInactivityTicker();
  }

  // --- PERSISTENT SESSION INACTIVITY TICKER (30s) ---
  private startInactivityTicker() {
    if (this.inactivityInterval) {
      clearInterval(this.inactivityInterval);
    }

    this.inactivityInterval = setInterval(() => {
      if (this.sessionStatus === 'ACTIVE') {
        if (!this.isTimerPaused && !this.isSpeaking) {
          this.inactivitySeconds++;
          this.notifyInactivityTick();

          // 30-Second Inactivity Timeout
          if (this.inactivitySeconds >= this.inactivityMaxSeconds) {
            this.handleInactivityTimeout();
          }
        } else {
          // Timer is paused (executing task, thinking, or JARVIS speaking)
          this.notifyInactivityTick();
        }
      } else {
        // Sleeping mode
        this.notifyInactivityTick();
      }
    }, 1000);
  }

  private notifyInactivityTick() {
    this.onInactivityTickCallback?.(
      this.inactivitySeconds,
      this.inactivityMaxSeconds,
      this.isTimerPaused || this.isSpeaking,
      this.pauseReason || (this.isSpeaking ? 'JARVIS speaking' : undefined)
    );
    this.notifyDeveloperStatus();
  }

  private notifyDeveloperStatus() {
    const status: DeveloperSessionStatus = this.getDeveloperStatus();
    this.onDeveloperStatusCallback?.(status);
  }

  public getDeveloperStatus(): DeveloperSessionStatus {
    let wakeWordStatus: 'LISTENING' | 'TEMPORARILY_DISABLED' | 'OFF' = 'OFF';
    if (this.sessionStatus === 'ACTIVE') {
      wakeWordStatus = 'TEMPORARILY_DISABLED';
    } else if (this.continuousWakeWordActive) {
      wakeWordStatus = 'LISTENING';
    }

    return {
      microphoneStatus: this.micStatus,
      wakeWordStatus,
      sessionStatus: this.sessionStatus,
      conversationState: this.conversationState,
      inactivitySeconds: this.inactivitySeconds,
      inactivityMaxSeconds: this.inactivityMaxSeconds,
      isTimerPaused: this.isTimerPaused || this.isSpeaking,
      pauseReason: this.isSpeaking ? 'JARVIS speaking' : this.pauseReason,
      lastSpokenText: this.lastSpokenText,
      lastCommand: this.lastCommand,
    };
  }

  /**
   * Resets the 30-second inactivity timer to 0.
   * Must trigger on user speech, command execution, or JARVIS speaking.
   */
  public resetInactivityTimer() {
    this.inactivitySeconds = 0;
    this.notifyInactivityTick();
  }

  /**
   * Pauses the timer during long-running tasks or speaking.
   * Timer will not tick down while tasks run.
   */
  public pauseInactivityTimer(reason?: string) {
    this.isTimerPaused = true;
    this.pauseReason = reason || 'Executing task';
    this.inactivitySeconds = 0;
    this.notifyInactivityTick();
  }

  /**
   * Resumes the timer countdown once task or speech finishes.
   */
  public resumeInactivityTimer() {
    this.isTimerPaused = false;
    this.pauseReason = undefined;
    this.inactivitySeconds = 0;
    this.notifyInactivityTick();
  }

  /**
   * Ends session when 30 seconds of inactivity occurs.
   * Transitions ACTIVE CONVERSATION → SLEEPING.
   * Re-enables wake-word detection ("Waiting for 'Jarvis'...").
   */
  public handleInactivityTimeout() {
    if (this.sessionStatus !== 'ACTIVE') return;

    this.sessionStatus = 'SLEEPING';
    this.setConversationState('SLEEPING');
    this.inactivitySeconds = 0;
    this.isTimerPaused = false;
    this.pauseReason = undefined;

    // Wake word re-enabled
    this.setEngineState('LISTENING_FOR_WAKE_WORD');
    this.onSessionTimeoutCallback?.();
    this.notifyDeveloperStatus();
  }

  /**
   * Handles explicit exit phrases: "Goodbye Jarvis", "Go to sleep", "Stop listening", "That's all", "Sleep".
   */
  public handleExplicitExit(phrase = "That's all") {
    this.sessionStatus = 'SLEEPING';
    this.setConversationState('SLEEPING');
    this.inactivitySeconds = 0;
    this.isTimerPaused = false;
    this.pauseReason = undefined;

    // Re-enable wake-word detector
    this.setEngineState('LISTENING_FOR_WAKE_WORD');
    this.notifyDeveloperStatus();
  }

  /**
   * Manually wake or put session to sleep (useful for debug UI)
   */
  public wakeSession() {
    this.triggerWakeWordDetected();
  }

  public sleepSession() {
    this.handleExplicitExit('Manual sleep');
  }

  // --- STATE GETTERS & SETTERS ---
  public getSessionStatus(): SessionMode {
    return this.sessionStatus;
  }

  public getConversationState(): ConversationState {
    return this.conversationState;
  }

  public setConversationState(newState: ConversationState) {
    if (this.conversationState !== newState) {
      this.conversationState = newState;

      // Sync legacy engine state for backward compatibility
      let legacyState: WakeWordEngineState = 'IDLE';
      switch (newState) {
        case 'SLEEPING':
          legacyState = 'LISTENING_FOR_WAKE_WORD';
          break;
        case 'WAKE_WORD_DETECTED':
          legacyState = 'WAKE_WORD_DETECTED';
          break;
        case 'ACTIVATING':
        case 'THINKING':
        case 'EXECUTING':
          legacyState = 'PROCESSING';
          break;
        case 'ACTIVE_CONVERSATION':
        case 'LISTENING':
          legacyState = 'LISTENING_FOR_COMMAND';
          break;
        case 'SPEAKING':
          legacyState = 'SPEAKING';
          break;
      }

      this.setEngineState(legacyState);
      this.onSessionStateCallback?.(newState, this.sessionStatus);
      this.notifyDeveloperStatus();
    }
  }

  public getEngineState(): WakeWordEngineState {
    return this.engineState;
  }

  private setEngineState(newState: WakeWordEngineState) {
    if (this.engineState !== newState) {
      this.engineState = newState;
      this.onStateChangeCallback?.(newState);
    }
  }

  public getMicrophoneStatus(): MicrophoneStatus {
    return this.micStatus;
  }

  public getCurrentVolume(): number {
    return this.currentVolume;
  }

  public setSensitivityThreshold(val: number) {
    this.sensitivityThreshold = Math.max(1, Math.min(99, val));
  }

  public getSensitivityThreshold(): number {
    return this.sensitivityThreshold;
  }

  public setWakeWord(word: string) {
    this.wakeWord = word.toLowerCase().trim();
    this.wakeWordRegex = new RegExp(`\\b(hey\\s+)?${this.wakeWord}\\b`, 'i');
  }

  private setMicStatus(newStatus: MicrophoneStatus) {
    if (this.micStatus !== newStatus) {
      this.micStatus = newStatus;
      this.onMicStatusCallback?.(newStatus);
      this.notifyDeveloperStatus();
    }
  }

  // --- AUDIO HARDWARE & STREAM ANALYSIS ---
  public async initMicrophone(): Promise<boolean> {
    if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      this.setMicStatus('NO_DEVICE');
      return false;
    }

    try {
      if (this.micStream) {
        this.closeMicrophone();
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.micStream = stream;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioCtx();
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.5;

      const source = this.audioContext.createMediaStreamSource(stream);
      source.connect(this.analyser);

      this.setMicStatus('CONNECTED');
      this.startAudioLevelAnalysis();
      return true;
    } catch (err: any) {
      console.warn('Microphone access rejected or unavailable:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        this.setMicStatus('PERMISSION_DENIED');
      } else {
        this.setMicStatus('ERROR');
      }
      return false;
    }
  }

  public closeMicrophone() {
    if (this.audioLevelCheckInterval) {
      clearInterval(this.audioLevelCheckInterval);
      this.audioLevelCheckInterval = null;
    }

    if (this.micStream) {
      this.micStream.getTracks().forEach((t) => t.stop());
      this.micStream = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }

    this.analyser = null;
    this.currentVolume = 0;
    this.onVolumeChangeCallback?.(0);
    this.setMicStatus('DISCONNECTED');
  }

  private startAudioLevelAnalysis() {
    if (this.audioLevelCheckInterval) {
      clearInterval(this.audioLevelCheckInterval);
    }

    const dataArray = new Uint8Array(128);

    this.audioLevelCheckInterval = window.setInterval(() => {
      if (!this.analyser) return;

      this.analyser.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;
      const normalized = Math.min(100, Math.round((avg / 128) * 100));

      if (Math.abs(normalized - this.currentVolume) > 1) {
        this.currentVolume = normalized;
        this.onVolumeChangeCallback?.(normalized);
      }

      // Check for user speaking / barge-in interruption while JARVIS speaks
      if (normalized > this.sensitivityThreshold) {
        if (this.isSpeaking) {
          // Barge-in interruption
          this.interrupt();
        } else if (this.sessionStatus === 'ACTIVE') {
          // User is actively speaking: reset inactivity countdown
          this.resetInactivityTimer();
        }
      }
    }, 80);
  }

  // --- STARK SOUND CHIMES ---
  public playActivationChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = this.audioContext && this.audioContext.state !== 'closed' ? this.audioContext : new AudioCtx();
      const now = ctx.currentTime;

      // Note 1: High crisp ping (880Hz / A5)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(880, now);
      gain1.gain.setValueAtTime(0.01, now);
      gain1.gain.exponentialRampToValueAtTime(0.25, now + 0.02);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.2);

      // Note 2: Harmonic Stark chime (1760Hz / A6)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1760, now + 0.08);
      gain2.gain.setValueAtTime(0.001, now + 0.08);
      gain2.gain.exponentialRampToValueAtTime(0.2, now + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.3);
    } catch {
      // AudioContext may require gesture
    }
  }

  public playConfirmationChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = this.audioContext && this.audioContext.state !== 'closed' ? this.audioContext : new AudioCtx();
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880, now + 0.08); // A5

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.2, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.26);
    } catch {}
  }

  // --- INTERRUPTION (BARGE-IN) ---
  /**
   * If JARVIS is speaking and the user starts talking:
   * Immediately detect user speech, stop/duck TTS, process the new command.
   */
  public interrupt() {
    if (!this.isSpeaking) return;

    this.stopSpeaking();
    this.resetInactivityTimer();
    this.setConversationState('LISTENING');
  }

  // --- SPEECH RECOGNITION (STT) & PERSISTENT SESSION LOOP ---
  private initRecognition() {
    if (typeof window === 'undefined') return;

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      console.warn('SpeechRecognition API not available in this browser environment.');
      return;
    }

    try {
      this.recognition = new SpeechRecognitionClass();
      if (this.recognition) {
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';

        this.recognition.onstart = () => {
          if (this.sessionStatus === 'SLEEPING') {
            this.setConversationState('SLEEPING');
          } else if (this.conversationState === 'ACTIVE_CONVERSATION') {
            this.setConversationState('LISTENING');
          }
        };

        this.recognition.onend = () => {
          // Restart recognition smoothly if listening is active and not currently in exclusive TTS
          if (this.continuousWakeWordActive && !this.isSpeaking) {
            if (this.recognitionRestartTimeout) {
              clearTimeout(this.recognitionRestartTimeout);
            }
            this.recognitionRestartTimeout = setTimeout(() => {
              try {
                if (this.continuousWakeWordActive && !this.isSpeaking) {
                  this.recognition?.start();
                }
              } catch {
                // Ignore restart race condition
              }
            }, 200);
          }
        };

        this.recognition.onerror = (e: any) => {
          if (e.error === 'not-allowed') {
            this.setMicStatus('PERMISSION_DENIED');
          } else if (e.error === 'no-speech' || e.error === 'aborted') {
            // Normal silence or abort
          }
        };

        this.recognition.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
          }

          const combined = (finalTranscript || interimTranscript).trim();

          // If user starts talking while JARVIS is speaking: INTERRUPT!
          if (this.isSpeaking && combined.length > 0) {
            this.interrupt();
          }

          if (interimTranscript) {
            this.onInterimCallback?.(interimTranscript);
            // User is actively speaking: reset inactivity timer
            if (this.sessionStatus === 'ACTIVE') {
              this.resetInactivityTimer();
              if (this.conversationState === 'ACTIVE_CONVERSATION') {
                this.setConversationState('LISTENING');
              }
            }
          }

          this.handleSpeechInput(combined, !!finalTranscript);
        };
      }
    } catch (err) {
      console.warn('Failed to initialize SpeechRecognition:', err);
    }
  }

  /**
   * Main Speech Input Routing Engine
   * Strictly separates SLEEPING (wake-word requirement) from ACTIVE (persistent conversation).
   */
  private handleSpeechInput(text: string, isFinal: boolean) {
    if (!text || this.isSpeaking) return;

    const lower = text.toLowerCase().trim();
    const hasWakeWord = this.wakeWordRegex.test(lower);

    // =========================================================================
    // SCENARIO A: SESSION IS SLEEPING
    // Must NOT process microphone input as commands. Only wake on "Hey Jarvis".
    // =========================================================================
    if (this.sessionStatus === 'SLEEPING') {
      if (hasWakeWord) {
        // Wake word detected!
        this.triggerWakeWordDetected(text);
      }
      // Any other speech without wake word is ignored while sleeping.
      return;
    }

    // =========================================================================
    // SCENARIO B: SESSION IS ACTIVE (ACTIVE CONVERSATION MODE)
    // No wake word required! Continuous command processing with 30s timeout.
    // =========================================================================
    if (this.sessionStatus === 'ACTIVE') {
      // User is speaking: reset inactivity timer
      this.resetInactivityTimer();

      if (!isFinal || text.length === 0) {
        if (this.conversationState === 'ACTIVE_CONVERSATION') {
          this.setConversationState('LISTENING');
        }
        return;
      }

      let command = text.trim();

      // Check for EXPLICIT EXIT COMMANDS:
      // "Goodbye Jarvis", "Go to sleep", "Stop listening", "That's all", "Sleep"
      if (this.exitCommandRegex.test(command)) {
        this.handleExplicitExit(command);
        this.dispatchExitCommand();
        return;
      }

      // If user repeatedly said "Jarvis" out of habit, strip it cleanly
      if (this.wakeWordRegex.test(command)) {
        command = command.replace(this.wakeWordRegex, '').trim();
        command = command.replace(/^[,:.-]+\s*/, '');
      }

      if (command.length > 0) {
        this.dispatchCommand(command);
      }
    }
  }

  /**
   * Wake-Word detected event: transitions SLEEPING → WAKE WORD DETECTED → ACTIVATING
   */
  public triggerWakeWordDetected(fullText = '') {
    this.setConversationState('WAKE_WORD_DETECTED');
    this.playActivationChime();
    this.resetInactivityTimer();

    // Check if user spoke an immediate command in the same utterance:
    // e.g. "Hey Jarvis, open Notepad" or "Jarvis open Chrome"
    let immediateCommand = fullText.replace(this.wakeWordRegex, '').trim();
    immediateCommand = immediateCommand.replace(/^[,:.-]+\s*/, '');

    if (immediateCommand.length > 1) {
      // Immediate command present: Enter active session and dispatch immediately
      this.sessionStatus = 'ACTIVE';
      this.setConversationState('ACTIVATING');
      setTimeout(() => {
        this.dispatchCommand(immediateCommand);
      }, 150);
      return;
    }

    // User only said "Hey Jarvis" or "Jarvis"
    // Enter ACTIVE CONVERSATION session and prompt "Yes?"
    this.sessionStatus = 'ACTIVE';
    this.setConversationState('ACTIVATING');

    setTimeout(() => {
      if (this.onWakeWordPromptCallback) {
        this.onWakeWordPromptCallback();
      } else {
        // Default JARVIS wake acknowledgment
        this.speak('Yes, sir?', {
          onEnd: () => {
            // Transitions to ACTIVE_CONVERSATION and LISTENING
            this.setConversationState('ACTIVE_CONVERSATION');
            this.setConversationState('LISTENING');
            this.resumeInactivityTimer();
          },
        });
      }
    }, 200);
  }

  /**
   * Dispatches command to task planner / orchestrator
   */
  private dispatchCommand(command: string) {
    this.lastCommand = command;
    this.resetInactivityTimer();
    this.pauseInactivityTimer('Synthesizing command');
    this.setConversationState('THINKING');

    this.onCommandCallback?.(command);
  }

  /**
   * Handles explicit exit command confirmation
   */
  private dispatchExitCommand() {
    this.lastCommand = "That's all";
    this.speak("Understood. I'll be here if you need me.", {
      onEnd: () => {
        this.setConversationState('SLEEPING');
      },
    });
  }

  // --- PUBLIC CONTROL METHODS ---
  public async startContinuousWakeWord(): Promise<boolean> {
    this.continuousWakeWordActive = true;
    await this.initMicrophone();

    if (!this.recognition) {
      this.initRecognition();
    }

    try {
      this.recognition?.start();
      if (this.sessionStatus === 'ACTIVE') {
        this.setConversationState('LISTENING');
      } else {
        this.setConversationState('SLEEPING');
      }
      return true;
    } catch {
      if (this.sessionStatus === 'ACTIVE') {
        this.setConversationState('LISTENING');
      } else {
        this.setConversationState('SLEEPING');
      }
      return true;
    }
  }

  public stopContinuousWakeWord() {
    this.continuousWakeWordActive = false;
    try {
      this.recognition?.stop();
    } catch {}
    this.sessionStatus = 'SLEEPING';
    this.setConversationState('SLEEPING');
    this.setEngineState('IDLE');
  }

  public startManualListening(): boolean {
    this.playActivationChime();
    this.sessionStatus = 'ACTIVE';
    this.resetInactivityTimer();
    this.setConversationState('LISTENING');

    try {
      this.recognition?.start();
      return true;
    } catch {
      return true;
    }
  }

  public startListening(_continuous?: boolean): boolean {
    return this.startManualListening();
  }

  public stopListening() {
    this.stopContinuousWakeWord();
  }

  // --- CALLBACK REGISTRATIONS ---
  public onCommand(cb: (command: string) => void) {
    this.onCommandCallback = cb;
  }

  public onInterim(cb: (interim: string) => void) {
    this.onInterimCallback = cb;
  }

  public onStateChange(cb: (state: WakeWordEngineState) => void) {
    this.onStateChangeCallback = cb;
  }

  public onSessionState(cb: (convState: ConversationState, sessionMode: SessionMode) => void) {
    this.onSessionStateCallback = cb;
  }

  public onInactivityTick(cb: (seconds: number, max: number, isPaused: boolean, reason?: string) => void) {
    this.onInactivityTickCallback = cb;
  }

  public onDeveloperStatus(cb: (status: DeveloperSessionStatus) => void) {
    this.onDeveloperStatusCallback = cb;
  }

  public onSessionTimeout(cb: () => void) {
    this.onSessionTimeoutCallback = cb;
  }

  public onWakeWordPrompt(cb: () => void) {
    this.onWakeWordPromptCallback = cb;
  }

  public onMicStatus(cb: (status: MicrophoneStatus) => void) {
    this.onMicStatusCallback = cb;
  }

  public onVolumeChange(cb: (vol: number) => void) {
    this.onVolumeChangeCallback = cb;
  }

  // --- TTS PIPELINE & SPEECH SYNTHESIS (PAUL BETTANY CALIBRATION) ---
  public getLastPipelineTrace(): TtsPipelineStageResult | null {
    return this.lastPipelineTrace;
  }

  public onPipelineProgress(cb: (event: PipelineProgressEvent) => void) {
    this.onPipelineProgressCallback = cb;
  }

  public processPipeline(text: string): TtsPipelineStageResult {
    const res = runTtsPipeline(text);
    this.lastPipelineTrace = res;
    return res;
  }

  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if (typeof window === 'undefined' || !window.speechSynthesis) return [];
    return window.speechSynthesis.getVoices();
  }

  public findPaulBettanyVoice(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null {
    if (!voices || voices.length === 0) return null;

    // 1. "Daniel" - macOS / iOS / Safari iconic British voice
    const daniel = voices.find(
      (v) => v.name.toLowerCase().includes('daniel') && v.lang.startsWith('en')
    );
    if (daniel) return daniel;

    // 2. Google UK English Male (Chrome / Chromium on Windows, Android, Linux)
    const googleUkMale = voices.find(
      (v) =>
        v.name.includes('UK English Male') ||
        (v.name.toLowerCase().includes('google') &&
          (v.lang === 'en-GB' || v.lang === 'en_GB') &&
          v.name.toLowerCase().includes('male'))
    );
    if (googleUkMale) return googleUkMale;

    // 3. Microsoft George or Ryan (Edge / Windows Natural British English)
    const msGeorgeOrRyan = voices.find(
      (v) =>
        (v.name.includes('George') ||
          v.name.includes('Ryan') ||
          v.name.includes('Oliver') ||
          v.name.includes('Arthur')) &&
        (v.lang === 'en-GB' || v.lang === 'en_GB' || v.lang.startsWith('en'))
    );
    if (msGeorgeOrRyan) return msGeorgeOrRyan;

    // 4. Any British English voice (en-GB / en_GB) excluding female voices
    const britishMale = voices.find(
      (v) =>
        (v.lang === 'en-GB' || v.lang === 'en_GB') &&
        !v.name.toLowerCase().includes('female') &&
        !v.name.toLowerCase().includes('susan') &&
        !v.name.toLowerCase().includes('hazel')
    );
    if (britishMale) return britishMale;

    return voices.find((v) => v.lang.startsWith('en')) || voices[0] || null;
  }

  public speak(
    text: string,
    options: {
      voiceName?: string;
      rate?: number;
      pitch?: number;
      assistantName?: string;
      personality?: 'formal' | 'witty' | 'concise' | 'technical';
      userCommand?: string;
      allowRawUrlExplicit?: boolean;
      onSentenceStart?: (sentence: string, index: number, total: number) => void;
      onStart?: () => void;
      onEnd?: () => void;
    } = {}
  ): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        resolve();
        return;
      }

      this.stopSpeaking();
      this.lastSpokenText = text;

      // EXECUTE TTS PREPROCESSING PIPELINE:
      // AI RESPONSE → TTS PREPROCESSOR → CLEAN SPEECH TEXT → TTS ENGINE
      const pipelineResult = runTtsPipeline(text, {
        assistantName: options.assistantName,
        personality: options.personality,
        userCommand: options.userCommand,
        allowRawUrlExplicit: options.allowRawUrlExplicit,
      });

      this.lastPipelineTrace = pipelineResult;

      this.onPipelineProgressCallback?.({
        stage: 'SENTENCE_SPLITTER',
        currentSentenceIndex: 0,
        totalSentences: pipelineResult.sentences.length,
        activeSentence: pipelineResult.sentences[0] || '',
        progressPercent: 0,
      });

      if (pipelineResult.sentences.length === 0) {
        resolve();
        return;
      }

      const voices = window.speechSynthesis.getVoices();
      let matchedVoice: SpeechSynthesisVoice | null = null;

      if (options.voiceName && options.voiceName !== 'jarvis-bettany') {
        matchedVoice =
          voices.find(
            (v) => v.name.toLowerCase() === options.voiceName?.toLowerCase()
          ) || null;
      }

      if (!matchedVoice) {
        matchedVoice = this.findPaulBettanyVoice(voices);
      }

      this.isSpeaking = true;
      this.setConversationState('SPEAKING');
      this.pauseInactivityTimer('JARVIS speaking');

      // Voice volume waveform simulation
      let speechVolInterval: number | null = window.setInterval(() => {
        if (this.isSpeaking) {
          const simulatedVol = Math.floor(Math.random() * 45) + 35;
          this.currentVolume = simulatedVol;
          this.onVolumeChangeCallback?.(simulatedVol);
        }
      }, 75);

      options.onStart?.();

      const finishSpeech = () => {
        if (speechVolInterval) {
          clearInterval(speechVolInterval);
          speechVolInterval = null;
        }
        this.isSpeaking = false;
        this.currentUtterance = null;
        this.currentVolume = 0;
        this.onVolumeChangeCallback?.(0);

        this.onPipelineProgressCallback?.({
          stage: 'IDLE',
          currentSentenceIndex: pipelineResult.sentences.length,
          totalSentences: pipelineResult.sentences.length,
          activeSentence: '',
          progressPercent: 100,
        });

        options.onEnd?.();

        // =====================================================================
        // CRITICAL STATE TRANSITION:
        // SPEAKING → ACTIVE CONVERSATION
        // NOT: SPEAKING → SLEEPING
        // =====================================================================
        if (this.sessionStatus === 'ACTIVE') {
          this.setConversationState('ACTIVE_CONVERSATION');
          this.setConversationState('LISTENING');
          this.resumeInactivityTimer();
        } else {
          this.setConversationState('SLEEPING');
        }

        // Restart recognition cleanly so next user speech is captured
        if (this.continuousWakeWordActive) {
          setTimeout(() => {
            try {
              this.recognition?.start();
            } catch {
              // ignore
            }
          }, 150);
        }

        resolve();
      };

      // Sequential sentence execution loop
      let sentenceIndex = 0;

      const speakNextSentence = () => {
        if (!this.isSpeaking || sentenceIndex >= pipelineResult.sentences.length) {
          finishSpeech();
          return;
        }

        const currentSentence = pipelineResult.sentences[sentenceIndex];
        const utterance = new SpeechSynthesisUtterance(currentSentence);
        this.currentUtterance = utterance;

        if (matchedVoice) {
          utterance.voice = matchedVoice;
        }

        utterance.rate = options.rate ?? 1.0;
        utterance.pitch = options.pitch ?? 0.92;

        this.onPipelineProgressCallback?.({
          stage: 'VOICE_OUTPUT',
          currentSentenceIndex: sentenceIndex,
          totalSentences: pipelineResult.sentences.length,
          activeSentence: currentSentence,
          progressPercent: Math.round(((sentenceIndex + 1) / pipelineResult.sentences.length) * 100),
        });

        options.onSentenceStart?.(currentSentence, sentenceIndex, pipelineResult.sentences.length);

        utterance.onend = () => {
          sentenceIndex++;
          if (sentenceIndex < pipelineResult.sentences.length && this.isSpeaking) {
            setTimeout(speakNextSentence, 85);
          } else {
            finishSpeech();
          }
        };

        utterance.onerror = () => {
          if (!this.isSpeaking) {
            finishSpeech();
            return;
          }
          sentenceIndex++;
          if (sentenceIndex < pipelineResult.sentences.length) {
            setTimeout(speakNextSentence, 50);
          } else {
            finishSpeech();
          }
        };

        window.speechSynthesis.speak(utterance);
      };

      speakNextSentence();
    });
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
    this.currentUtterance = null;
  }

  public isCurrentlySpeaking(): boolean {
    return this.isSpeaking;
  }
}

export const voiceService = new VoiceService();
