import React, { useEffect, useRef } from 'react';
import { AccentColor } from '../types';
import {
  Terminal,
  Mic,
  MicOff,
  Send,
  X,
  Sparkles,
  Command,
  CheckCircle2,
  FolderOpen,
  Globe,
  Activity,
  Trash2,
  Camera,
} from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  input: string;
  onInputChange: (val: string) => void;
  onSubmit: (cmd: string) => void;
  isListening: boolean;
  onToggleMic: () => void;
  accentColor?: AccentColor;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  input,
  onInputChange,
  onSubmit,
  isListening,
  onToggleMic,
  accentColor = 'blue',
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const quickPrompts = [
    { label: 'Open Chrome', icon: Globe, cmd: 'Jarvis, open Chrome.' },
    { label: 'Open Notepad', icon: Terminal, cmd: 'Jarvis, open Notepad.' },
    { label: 'Open Calculator', icon: Activity, cmd: 'Hey Jarvis, open Calculator.' },
    { label: 'Check CPU & RAM', icon: Activity, cmd: 'Jarvis, tell me my CPU usage.' },
    { label: 'Create Test Folder', icon: FolderOpen, cmd: 'Jarvis, create a folder called JarvisTest on my Desktop.' },
    { label: 'Take Screenshot', icon: Camera, cmd: 'Jarvis, take a screenshot.' },
    { label: 'Clean Temp Files', icon: Trash2, cmd: 'Jarvis, clean up temporary cache files.' },
    { label: 'Close Notepad', icon: X, cmd: 'Jarvis, close Notepad.' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSubmit(input.trim());
      onClose();
    }
  };

  return (
    <div
      id="jarvis-command-palette-backdrop"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="jarvis-command-palette-modal"
        className="w-full max-w-2xl rounded-2xl bg-[#060a12]/95 border border-cyan-500/30 p-4 sm:p-5 shadow-[0_0_50px_rgba(0,210,255,0.2)] flex flex-col space-y-3 animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Command className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono font-bold tracking-widest text-slate-100 uppercase">
              NATURAL LANGUAGE INSTRUCTION
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          {/* Microphone Toggle */}
          <button
            type="button"
            onClick={onToggleMic}
            title={isListening ? 'Stop listening' : 'Start voice input'}
            className={`p-3 rounded-xl font-mono text-xs font-bold flex items-center gap-2 transition-all ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.5)]'
                : 'bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text Input */}
          <div className="flex-1 flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-[#0a1020] border border-white/10 font-mono text-sm text-slate-100 focus-within:border-cyan-500/50">
            <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              placeholder='e.g. "Open Chrome", "Organize Downloads", "Take screenshot"...'
              value={input}
              onChange={(e) => onInputChange(e.target.value)}
              className="w-full bg-transparent focus:outline-none placeholder:text-slate-500 font-sans"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 disabled:hover:bg-cyan-600 transition-all shadow-lg shadow-cyan-600/30 shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Suggested Quick Commands */}
        <div className="space-y-1.5 pt-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider px-1">
            Quick System Commands:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {quickPrompts.map((item, idx) => {
              const Icon = item.icon;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    onSubmit(item.cmd);
                    onClose();
                  }}
                  className="p-2 rounded-lg bg-[#090e1c] border border-white/5 hover:border-cyan-500/40 hover:bg-[#0c1426] text-left text-xs font-mono text-slate-300 transition-all flex items-center gap-2 group truncate"
                >
                  <Icon className="w-3.5 h-3.5 text-cyan-400 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate text-[11px]">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Hotkey Helper */}
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 px-1 pt-1 border-t border-white/5">
          <span>
            Press <kbd className="text-cyan-400 font-semibold">Enter</kbd> to execute
          </span>
          <span>
            Press <kbd className="text-cyan-400 font-semibold">Esc</kbd> to cancel
          </span>
        </div>
      </div>
    </div>
  );
};
