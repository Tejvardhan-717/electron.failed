import React, { useState } from 'react';
import { JarvisSettings } from '../types';
import { Settings, X, Cpu, Mic, Shield, Brain, Palette, Laptop, Check, Download, Info, Volume2, ShieldAlert, Sparkles } from 'lucide-react';
import { voiceService } from '../services/voiceService';
import { TtsPipelineVisualizer } from './TtsPipelineVisualizer';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: JarvisSettings;
  onSaveSettings: (newSettings: JarvisSettings) => void;
  availableVoices: SpeechSynthesisVoice[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  availableVoices,
}) => {
  const [activeTab, setActiveTab] = useState<'ai' | 'voice' | 'security' | 'memory' | 'ui' | 'companion'>('voice');
  const [localSettings, setLocalSettings] = useState<JarvisSettings>(settings);
  const [newFolder, setNewFolder] = useState('');
  const [newExtension, setNewExtension] = useState('');
  const [isPlayingTestAudio, setIsPlayingTestAudio] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings(localSettings);
    onClose();
  };

  const applyPaulBettanyPreset = () => {
    const bettanyVoice = voiceService.findPaulBettanyVoice(availableVoices);
    setLocalSettings((prev) => ({
      ...prev,
      voiceName: bettanyVoice ? bettanyVoice.name : '',
      speechSpeed: 1.0,
      speechPitch: 0.92,
      personality: 'formal',
    }));
  };

  const testPaulBettanyVoice = async () => {
    if (isPlayingTestAudio) {
      voiceService.stopSpeaking();
      setIsPlayingTestAudio(false);
      return;
    }

    setIsPlayingTestAudio(true);
    await voiceService.speak(
      "Good day, sir. I am JARVIS. All systems are operational, and please note that I am operating in a secure sandbox without access to your physical PC.",
      {
        voiceName: localSettings.voiceName,
        rate: localSettings.speechSpeed,
        pitch: localSettings.speechPitch,
        onEnd: () => setIsPlayingTestAudio(false),
      }
    );
  };

  const handleAddFolder = () => {
    if (newFolder && !localSettings.protectedFolders.includes(newFolder.trim())) {
      setLocalSettings((prev) => ({
        ...prev,
        protectedFolders: [...prev.protectedFolders, newFolder.trim()],
      }));
      setNewFolder('');
    }
  };

  const handleRemoveFolder = (folder: string) => {
    setLocalSettings((prev) => ({
      ...prev,
      protectedFolders: prev.protectedFolders.filter((f) => f !== folder),
    }));
  };

  const handleAddExtension = () => {
    if (newExtension && !localSettings.protectedExtensions.includes(newExtension.trim())) {
      setLocalSettings((prev) => ({
        ...prev,
        protectedExtensions: [...prev.protectedExtensions, newExtension.trim()],
      }));
      setNewExtension('');
    }
  };

  const handleRemoveExtension = (ext: string) => {
    setLocalSettings((prev) => ({
      ...prev,
      protectedExtensions: prev.protectedExtensions.filter((e) => e !== ext),
    }));
  };

  const downloadWindowsScript = () => {
    const script = `# JARVIS AI - Local Windows Desktop Companion Bridge
# Run this in Windows PowerShell (Admin recommended for app control)
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   JARVIS AI - Windows PC Companion v1.0   " -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

$AppEndpoint = "http://localhost:3000"
Write-Host "Listening to JARVIS command channel at $AppEndpoint..." -ForegroundColor Green

# Hotkey listener: Ctrl+Space activates JARVIS voice command
Add-Type -AssemblyName System.Windows.Forms
Write-Host "Registered Global Hotkey: [Ctrl + Space]" -ForegroundColor Yellow
Write-Host "System integration active. Keep this PowerShell window open." -ForegroundColor Gray
`;
    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jarvis-windows-bridge.ps1';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div
        id="jarvis-settings-modal"
        className="w-full max-w-3xl h-[85vh] rounded-2xl bg-[#0b0f17] border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.7)] flex flex-col overflow-hidden font-mono text-xs"
      >
        {/* Header */}
        <div className="bg-[#070a10] px-5 py-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-bold tracking-wider text-slate-100 uppercase">
              JARVIS CONFIGURATION MATRIX
            </span>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded hover:bg-[#121a28] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body with Sidebar Tabs */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* Tabs Sidebar */}
          <div className="w-full md:w-52 bg-[#070a10] border-r border-white/10 p-3 space-y-1">
            {[
              { id: 'ai', label: 'AI BRAIN & MODEL', icon: <Cpu className="w-4 h-4" /> },
              { id: 'voice', label: 'VOICE & SPEECH', icon: <Mic className="w-4 h-4" /> },
              { id: 'security', label: 'SAFETY & SECURITY', icon: <Shield className="w-4 h-4" /> },
              { id: 'memory', label: 'MEMORY ENGINE', icon: <Brain className="w-4 h-4" /> },
              { id: 'ui', label: 'HOLOGRAPHIC UI', icon: <Palette className="w-4 h-4" /> },
              { id: 'companion', label: 'WINDOWS DESKTOP', icon: <Laptop className="w-4 h-4" /> },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all ${
                  activeTab === tab.id
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#121a28]'
                }`}
              >
                {tab.icon}
                <span className="truncate">{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tab Content Panel */}
          <div className="flex-1 p-6 overflow-y-auto space-y-5 bg-[#0b0f17]">
            {/* TAB: AI BRAIN */}
            {activeTab === 'ai' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">ASSISTANT NAME:</label>
                  <input
                    type="text"
                    value={localSettings.assistantName}
                    onChange={(e) => setLocalSettings({ ...localSettings, assistantName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:border-sky-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">PERSONALITY STYLE:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'formal', label: 'Calm & Professional (Standard JARVIS)' },
                      { id: 'witty', label: 'Slightly Witty & Intelligent' },
                      { id: 'concise', label: 'Concise & Direct' },
                      { id: 'tactical', label: 'Tactical & Mission-Driven' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setLocalSettings({ ...localSettings, personality: p.id as any })}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          localSettings.personality === p.id
                            ? 'bg-sky-950/60 border-sky-400 text-sky-200'
                            : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">AI ORCHESTRATOR PROVIDER:</label>
                  <div className="p-3 rounded-lg bg-slate-950/80 border border-sky-500/20 text-slate-300 space-y-1">
                    <div className="flex justify-between font-bold text-sky-300">
                      <span>Google Gemini 3.8 Flash (Server-Side Engine)</span>
                      <span className="text-emerald-400">ONLINE</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Utilizes multi-step autonomous planning, tool function calling, and structured intent evaluation. API key securely handled server-side.
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    MAXIMUM AUTOMATED STEPS PER TASK: {localSettings.maxAutomatedSteps}
                  </label>
                  <input
                    type="range"
                    min="3"
                    max="25"
                    value={localSettings.maxAutomatedSteps}
                    onChange={(e) => setLocalSettings({ ...localSettings, maxAutomatedSteps: Number(e.target.value) })}
                    className="w-full accent-sky-400"
                  />
                </div>
              </div>
            )}

            {/* TAB: VOICE & SPEECH */}
            {activeTab === 'voice' && (
              <div className="space-y-4">
                {/* Paul Bettany / Iron Man 3 Voice Profile Preset */}
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-cyan-950/40 via-[#0a1526] to-[#070a10] border border-cyan-500/30 text-slate-200 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span className="font-bold text-xs text-cyan-300 tracking-wide uppercase">
                        MARVEL IRON MAN J.A.R.V.I.S. VOICE (PAUL BETTANY)
                      </span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
                      ACTIVE PROFILE
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Configured to match Paul Bettany's authentic J.A.R.V.I.S. performance from Marvel's Iron Man 3. Uses articulate British English (Daniel / UK Male) calibrated with calm baritone pitch (0.92x) and deliberate tempo (1.0x).
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={applyPaulBettanyPreset}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm shadow-cyan-500/20"
                    >
                      <Check className="w-3.5 h-3.5" /> Apply Bettany Preset
                    </button>

                    <button
                      type="button"
                      onClick={testPaulBettanyVoice}
                      className="px-3 py-1.5 rounded-lg bg-[#132035] hover:bg-[#1a2d4b] border border-cyan-500/30 text-cyan-300 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      {isPlayingTestAudio ? 'Stop Preview' : 'Test Speech Sample'}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">WAKE WORD:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={localSettings.wakeWord}
                      onChange={(e) => setLocalSettings({ ...localSettings, wakeWord: e.target.value })}
                      placeholder="Jarvis"
                      className="flex-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100"
                    />
                    <label className="flex items-center gap-1.5 px-3 rounded-lg bg-slate-900 border border-slate-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={localSettings.wakeWordEnabled}
                        onChange={(e) => setLocalSettings({ ...localSettings, wakeWordEnabled: e.target.checked })}
                        className="rounded bg-slate-950 text-sky-500"
                      />
                      <span>Active</span>
                    </label>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Listening for: &ldquo;Hey {localSettings.wakeWord}&rdquo; or &ldquo;{localSettings.wakeWord}&rdquo;
                  </span>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-slate-300 font-semibold">TEXT-TO-SPEECH VOICE:</label>
                    <span className="text-[10px] text-cyan-400">British Voices Recommended</span>
                  </div>
                  <select
                    value={localSettings.voiceName}
                    onChange={(e) => setLocalSettings({ ...localSettings, voiceName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100"
                  >
                    <option value="">Default British JARVIS (Daniel / Google UK Male / George)</option>
                    {availableVoices
                      .filter((v) => v.lang.startsWith('en'))
                      .map((v) => (
                        <option key={v.name} value={v.name}>
                          {v.name} ({v.lang})
                        </option>
                      ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1 font-semibold">
                      SPEAKING RATE: {localSettings.speechSpeed}x
                    </label>
                    <input
                      type="range"
                      min="0.75"
                      max="1.5"
                      step="0.05"
                      value={localSettings.speechSpeed}
                      onChange={(e) => setLocalSettings({ ...localSettings, speechSpeed: Number(e.target.value) })}
                      className="w-full accent-sky-400"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1 font-semibold">
                      SPEECH PITCH: {localSettings.speechPitch}x
                    </label>
                    <input
                      type="range"
                      min="0.75"
                      max="1.25"
                      step="0.05"
                      value={localSettings.speechPitch}
                      onChange={(e) => setLocalSettings({ ...localSettings, speechPitch: Number(e.target.value) })}
                      className="w-full accent-sky-400"
                    />
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.continuousListening}
                      onChange={(e) => setLocalSettings({ ...localSettings, continuousListening: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Continuous Listening Mode (Background mic standby)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.audioFeedback}
                      onChange={(e) => setLocalSettings({ ...localSettings, audioFeedback: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Futuristic Web Audio sound chimes on activation & execution</span>
                  </label>
                </div>

                {/* TTS SPEECH PIPELINE ARCHITECTURE (AI RESPONSE -> Formatter -> Cleaner -> Splitter -> TTS -> Voice) */}
                <TtsPipelineVisualizer
                  currentVoiceName={localSettings.voiceName}
                  speechSpeed={localSettings.speechSpeed}
                  speechPitch={localSettings.speechPitch}
                />
              </div>
            )}

            {/* TAB: SAFETY & SECURITY */}
            {activeTab === 'security' && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-sky-950/30 border border-sky-500/20 text-slate-300">
                  <div className="flex items-center gap-2 text-sky-300 font-bold mb-1">
                    <Shield className="w-4 h-4" /> MULTI-TIER SAFETY ENGINE
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Level 0/1 actions run safely. Level 2 requires confirmation unless trusted. Level 3 (permanent deletions, restart, admin elevation) always requires explicit approval. Level 4 (credential extraction, malicious code) is strictly forbidden.
                  </p>
                </div>

                {/* Protected Folders */}
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    PROTECTED DIRECTORIES (ALWAYS ASK BEFORE MODIFYING):
                  </label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      placeholder="e.g. C:\Users\Admin\Documents, Desktop, Projects"
                      value={newFolder}
                      onChange={(e) => setNewFolder(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={handleAddFolder}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      Add
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(localSettings.protectedFolders || []).map((f) => (
                      <span
                        key={f}
                        className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 flex items-center gap-1.5"
                      >
                        {f}
                        <button
                          type="button"
                          onClick={() => handleRemoveFolder(f)}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Protected File Patterns */}
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    PROTECTED FILE PATTERNS (SECRETS & KEYS):
                  </label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      placeholder="e.g. *.key, *.pem, *.env, id_rsa"
                      value={newExtension}
                      onChange={(e) => setNewExtension(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={handleAddExtension}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      Add
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(localSettings.protectedExtensions || []).map((ext) => (
                      <span
                        key={ext}
                        className="px-2 py-1 rounded bg-rose-950/40 border border-rose-500/40 text-rose-300 flex items-center gap-1.5"
                      >
                        {ext}
                        <button
                          type="button"
                          onClick={() => handleRemoveExtension(ext)}
                          className="text-slate-500 hover:text-rose-400"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.requireAdminApproval}
                      onChange={(e) => setLocalSettings({ ...localSettings, requireAdminApproval: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Require explicit user authorization for administrator privileges</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.allowTrustedAutoInstall}
                      onChange={(e) => setLocalSettings({ ...localSettings, allowTrustedAutoInstall: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Allow automatic software installations from trusted winget sources</span>
                  </label>
                </div>
              </div>
            )}

            {/* TAB: MEMORY ENGINE */}
            {activeTab === 'memory' && (
              <div className="space-y-4">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 font-semibold">
                  <input
                    type="checkbox"
                    checked={localSettings.enableMemory}
                    onChange={(e) => setLocalSettings({ ...localSettings, enableMemory: e.target.checked })}
                    className="rounded bg-slate-950 text-sky-500"
                  />
                  <span>Enable Autonomous Long-Term Memory</span>
                </label>

                <p className="text-slate-400 text-[11px] leading-relaxed">
                  When enabled, JARVIS retains your preferences, preferred directories, custom aliases, and frequently used applications across reboots. You can review and purge individual memories at any time from the Memory Tab.
                </p>
              </div>
            )}

            {/* TAB: HOLOGRAPHIC UI */}
            {activeTab === 'ui' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-slate-300 mb-2 font-semibold">ARC REACTOR ACCENT COLOR:</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                    {[
                      { id: 'blue', label: 'JARVIS Blue', color: 'bg-cyan-400 border-cyan-400' },
                      { id: 'cyan', label: 'Arc Cyan', color: 'bg-sky-400 border-sky-400' },
                      { id: 'purple', label: 'Purple', color: 'bg-purple-400 border-purple-400' },
                      { id: 'green', label: 'Emerald', color: 'bg-emerald-400 border-emerald-400' },
                      { id: 'red', label: 'Crimson', color: 'bg-rose-500 border-rose-500' },
                      { id: 'white', label: 'Titanium', color: 'bg-slate-200 border-slate-200' },
                      { id: 'amber', label: 'Gold Amber', color: 'bg-amber-400 border-amber-400' },
                    ].map((theme) => (
                      <button
                        key={theme.id}
                        type="button"
                        onClick={() => setLocalSettings({ ...localSettings, accentColor: theme.id as any })}
                        className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                          localSettings.accentColor === theme.id
                            ? 'bg-slate-900 border-cyan-400 ring-1 ring-cyan-400'
                            : 'bg-slate-950 border-slate-800'
                        }`}
                      >
                        <span className={`w-4 h-4 rounded-full ${theme.color}`} />
                        <span className="text-[10px] font-semibold text-slate-300 truncate w-full">{theme.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">ANIMATION INTENSITY:</label>
                  <select
                    value={localSettings.animationIntensity}
                    onChange={(e) => setLocalSettings({ ...localSettings, animationIntensity: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100"
                  >
                    <option value="high">High (Full Orbital Arc Reactor, Canvas Particles & Waveforms)</option>
                    <option value="medium">Balanced</option>
                    <option value="minimal">Minimal (Power Saving)</option>
                  </select>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.soundEffects ?? true}
                      onChange={(e) => setLocalSettings({ ...localSettings, soundEffects: e.target.checked })}
                      className="rounded bg-slate-950 text-cyan-500"
                    />
                    <span>Enable Synthesized Stark HUD Audio Feedback (Web Audio API)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.hudScanlines}
                      onChange={(e) => setLocalSettings({ ...localSettings, hudScanlines: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Enable Futuristic HUD Scanlines Overlay</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={localSettings.startWithWindows}
                      onChange={(e) => setLocalSettings({ ...localSettings, startWithWindows: e.target.checked })}
                      className="rounded bg-slate-950 text-sky-500"
                    />
                    <span>Launch JARVIS automatically on Windows startup</span>
                  </label>
                </div>
              </div>
            )}

            {/* TAB: WINDOWS DESKTOP COMPANION & HOST BOUNDARY */}
            {activeTab === 'companion' && (
              <div className="space-y-4">
                {/* Host PC Isolation Warning Card */}
                <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-slate-200 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-amber-400">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>SECURITY NOTICE: JARVIS CANNOT ACCESS YOUR PHYSICAL PC</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    By design and security architecture, JARVIS operates strictly within a protected web container and <strong>is not able to access your physical PC</strong>, local storage, private folders, or desktop operating system directly. All actions, files, and telemetry in this interface are executed within an isolated sandbox environment.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-sky-950/30 border border-sky-500/30 text-slate-300 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-sky-300">
                    <Laptop className="w-4 h-4" /> WINDOWS 10 / 11 NATIVE PC BRIDGE (OPTIONAL)
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Because this web application cannot touch your local machine directly, connecting to your physical Windows PC requires you to manually download and run an external companion bridge script on your local machine.
                  </p>
                  <button
                    onClick={downloadWindowsScript}
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold flex items-center gap-2 transition-colors"
                  >
                    <Download className="w-4 h-4" /> Download jarvis-windows-bridge.ps1
                  </button>
                </div>

                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                  <span className="font-semibold text-slate-200 block">Package Management via winget:</span>
                  <p>JARVIS executes verified installations via Windows Package Manager:</p>
                  <code className="text-sky-300 bg-slate-900 px-2 py-0.5 rounded block">
                    winget install Microsoft.VisualStudioCode --silent --accept-package-agreements
                  </code>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#070a10] px-5 py-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-[10px] text-slate-500">
            JARVIS MARK 85 OS LAYER // REVISION 4.2
          </span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-[#121a28] text-slate-300 hover:bg-[#1a2538] border border-white/5"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold flex items-center gap-1.5 shadow-md shadow-cyan-600/30"
            >
              <Check className="w-3.5 h-3.5" /> Save Configuration
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
