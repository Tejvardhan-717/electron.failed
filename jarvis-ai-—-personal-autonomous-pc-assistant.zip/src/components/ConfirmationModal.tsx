import React from 'react';
import { ConfirmationRequest, RISK_LEVELS } from '../types';
import { ShieldAlert, AlertTriangle, Check, X, ShieldX, Terminal, FileWarning } from 'lucide-react';

interface ConfirmationModalProps {
  request: ConfirmationRequest | null;
  onConfirm: () => void;
  onReject: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  request,
  onConfirm,
  onReject,
}) => {
  if (!request) return null;

  const riskInfo = RISK_LEVELS[request.riskLevel];
  const isLevel3 = request.riskLevel >= 3;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="jarvis-safety-confirmation-dialog"
        className={`w-full max-w-lg rounded-2xl bg-[#0b0f17] border ${
          isLevel3 ? 'border-rose-500/70 shadow-[0_0_40px_rgba(244,63,94,0.25)]' : 'border-amber-500/70 shadow-[0_0_35px_rgba(245,158,11,0.2)]'
        } p-6 overflow-hidden flex flex-col`}
      >
        {/* Header with Risk Level Badge */}
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-xl ${
                isLevel3 ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              }`}
            >
              {isLevel3 ? <ShieldX className="w-6 h-6" /> : <ShieldAlert className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border ${riskInfo.badgeBg} ${riskInfo.badgeColor}`}
                >
                  {riskInfo.name}
                </span>
                {request.params?.requiresAdmin && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-semibold">
                    ADMIN ELEVATION
                  </span>
                )}
              </div>
              <h3 className="text-lg font-bold text-slate-100 mt-1">
                {request.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onReject}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-[#070a10] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Reason & Intent */}
        <div className="my-4 space-y-3">
          <div className="p-3 rounded-xl bg-[#070a10] border border-white/5 text-sm text-slate-300">
            <span className="font-mono text-xs text-cyan-400 font-semibold block mb-1">
              ACTION PURPOSE // REASON
            </span>
            <p>{request.reason}</p>
          </div>

          {/* Operation Parameters & Tool */}
          <div className="p-3 rounded-xl bg-[#070a10] border border-cyan-500/20 font-mono text-xs text-slate-300">
            <div className="flex items-center gap-2 text-cyan-300 font-semibold pb-1.5 border-b border-white/10">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>TOOL: {request.toolName}()</span>
            </div>
            <div className="mt-2 space-y-1 text-[11px] text-slate-400">
              {Object.entries(request.params || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-slate-500">{k}:</span>
                  <span className="text-slate-200 font-medium truncate max-w-[260px]">
                    {typeof v === 'object' ? JSON.stringify(v) : String(v)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Warnings List */}
          {request.warningDetails && request.warningDetails.length > 0 && (
            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/30 text-xs">
              <div className="flex items-center gap-1.5 text-rose-300 font-bold mb-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>SAFETY ENGINE WARNINGS & AUDIT DETAILS:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-rose-200/90 text-[11px]">
                {(request.warningDetails || []).map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10 mt-auto">
          <button
            onClick={onReject}
            className="px-4 py-2 rounded-xl bg-[#070a10] hover:bg-[#121a28] border border-white/10 text-slate-300 font-mono text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <X className="w-4 h-4" /> Deny & Abort Action
          </button>

          <button
            onClick={onConfirm}
            className={`px-5 py-2 rounded-xl font-mono text-xs font-bold text-white flex items-center gap-2 transition-all shadow-lg ${
              isLevel3
                ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                : 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30'
            }`}
          >
            <Check className="w-4 h-4" /> Authorize Execution
          </button>
        </div>
      </div>
    </div>
  );
};
