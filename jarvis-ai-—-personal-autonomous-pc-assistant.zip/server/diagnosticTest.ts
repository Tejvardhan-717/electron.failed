import os from 'os';
import fs from 'fs';
import path from 'path';
import { RealToolExecutor, getBridgeStatus } from './windowsTools';

export interface DiagnosticStepResult {
  id: string;
  stepNumber: number;
  title: string;
  category:
    | 'Windows API'
    | 'Process control'
    | 'File system'
    | 'Application launch'
    | 'Application close'
    | 'Browser control'
    | 'Screenshot'
    | 'Microphone'
    | 'Wake word';
  passed: boolean;
  message: string;
  details?: string;
  durationMs: number;
}

export interface DiagnosticRunReport {
  timestamp: string;
  overallPassed: boolean;
  bridgeStatus: ReturnType<typeof getBridgeStatus>;
  categorySummary: {
    'Windows API': boolean;
    'Process control': boolean;
    'File system': boolean;
    'Application launch': boolean;
    'Application close': boolean;
    'Browser control': boolean;
    'Screenshot': boolean;
    'Microphone': boolean;
    'Wake word': boolean;
  };
  steps: DiagnosticStepResult[];
  tests: DiagnosticStepResult[];
}

export async function runPcAccessDiagnostic(clientMicrophoneOk = true, clientWakeWordOk = true): Promise<DiagnosticRunReport> {
  const steps: DiagnosticStepResult[] = [];
  const bridge = getBridgeStatus();

  // 1. Read Windows version
  const t1 = Date.now();
  const isWindows = process.platform === 'win32' || bridge.connected;
  const osVer = isWindows ? (bridge.osVersion || `${os.type()} ${os.release()}`) : `${os.type()} ${os.release()} (Container)`;
  steps.push({
    id: 'test-1',
    stepNumber: 1,
    title: 'Read Windows version',
    category: 'Windows API',
    passed: isWindows,
    message: isWindows ? `Detected: ${osVer}` : `Operating System: ${osVer} (Non-Windows host / Bridge not connected)`,
    durationMs: Date.now() - t1,
  });

  // 2. Read CPU
  const t2 = Date.now();
  const cpus = os.cpus();
  const cpuModel = cpus[0]?.model || 'Standard CPU';
  steps.push({
    id: 'test-2',
    stepNumber: 2,
    title: 'Read CPU',
    category: 'Windows API',
    passed: cpus.length > 0,
    message: `Read CPU: ${cpuModel} (${cpus.length} cores)`,
    durationMs: Date.now() - t2,
  });

  // 3. Read RAM
  const t3 = Date.now();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const totalGb = (totalMem / (1024 ** 3)).toFixed(1);
  const usedGb = ((totalMem - freeMem) / (1024 ** 3)).toFixed(1);
  steps.push({
    id: 'test-3',
    stepNumber: 3,
    title: 'Read RAM',
    category: 'Windows API',
    passed: totalMem > 0,
    message: `Read RAM: ${usedGb} GB used of ${totalGb} GB total`,
    durationMs: Date.now() - t3,
  });

  // 4. Detect running processes
  const t4 = Date.now();
  const procRes = await RealToolExecutor.executeTool('get_running_processes', {});
  steps.push({
    id: 'test-4',
    stepNumber: 4,
    title: 'Detect running processes',
    category: 'Process control',
    passed: procRes.success,
    message: procRes.output,
    durationMs: Date.now() - t4,
  });

  // 5. Open Notepad
  const t5 = Date.now();
  const openNotepad = await RealToolExecutor.executeTool('open_application', { application: 'notepad' });
  steps.push({
    id: 'test-5',
    stepNumber: 5,
    title: 'Open Notepad',
    category: 'Application launch',
    passed: openNotepad.success && openNotepad.verified,
    message: openNotepad.output,
    details: openNotepad.verificationSteps?.map((v) => `${v.name}: ${v.message}`).join(' | '),
    durationMs: Date.now() - t5,
  });

  // 6. Verify Notepad process
  const t6 = Date.now();
  steps.push({
    id: 'test-6',
    stepNumber: 6,
    title: 'Verify Notepad process',
    category: 'Application launch',
    passed: openNotepad.verified,
    message: openNotepad.verified ? 'Notepad process PID verified in process table' : 'Notepad process not detected in process table',
    durationMs: Date.now() - t6,
  });

  // 7. Close Notepad
  const t7 = Date.now();
  const closeNotepad = await RealToolExecutor.executeTool('close_application', { application: 'notepad' });
  steps.push({
    id: 'test-7',
    stepNumber: 7,
    title: 'Close Notepad',
    category: 'Application close',
    passed: closeNotepad.success || !openNotepad.verified, // if never opened, close step reflects state
    message: closeNotepad.output,
    durationMs: Date.now() - t7,
  });

  // 8. Verify process closed
  const t8 = Date.now();
  steps.push({
    id: 'test-8',
    stepNumber: 8,
    title: 'Verify process closed',
    category: 'Application close',
    passed: closeNotepad.verified || !openNotepad.verified,
    message: 'Confirmed process closed or absent from process table',
    durationMs: Date.now() - t8,
  });

  // 9. Create temporary folder
  const t9 = Date.now();
  const testFolder = path.join(os.tmpdir(), `jarvis_diag_${Date.now()}`);
  const createFolderRes = await RealToolExecutor.executeTool('create_folder', { path: testFolder });
  steps.push({
    id: 'test-9',
    stepNumber: 9,
    title: 'Create temporary folder',
    category: 'File system',
    passed: createFolderRes.success,
    message: createFolderRes.output,
    durationMs: Date.now() - t9,
  });

  // 10. Verify folder
  const t10 = Date.now();
  const folderExists = fs.existsSync(testFolder);
  steps.push({
    id: 'test-10',
    stepNumber: 10,
    title: 'Verify folder',
    category: 'File system',
    passed: folderExists,
    message: folderExists ? `Verified folder exists at ${testFolder}` : `Folder check failed`,
    durationMs: Date.now() - t10,
  });

  // 11. Delete temporary folder
  const t11 = Date.now();
  const deleteFolderRes = await RealToolExecutor.executeTool('delete_file', { path: testFolder });
  steps.push({
    id: 'test-11',
    stepNumber: 11,
    title: 'Delete temporary folder',
    category: 'File system',
    passed: deleteFolderRes.success,
    message: deleteFolderRes.output,
    durationMs: Date.now() - t11,
  });

  // 12. Verify deletion
  const t12 = Date.now();
  const folderStillExists = fs.existsSync(testFolder);
  steps.push({
    id: 'test-12',
    stepNumber: 12,
    title: 'Verify deletion',
    category: 'File system',
    passed: !folderStillExists,
    message: !folderStillExists ? 'Verified temporary folder no longer exists on filesystem' : 'Folder still present',
    durationMs: Date.now() - t12,
  });

  // 13. Open browser
  const t13 = Date.now();
  const browserRes = await RealToolExecutor.executeTool('open_url', { url: 'https://youtube.com' });
  steps.push({
    id: 'test-13',
    stepNumber: 13,
    title: 'Open browser',
    category: 'Browser control',
    passed: browserRes.success,
    message: browserRes.output,
    durationMs: Date.now() - t13,
  });

  // 14. Verify browser
  const t14 = Date.now();
  steps.push({
    id: 'test-14',
    stepNumber: 14,
    title: 'Verify browser',
    category: 'Browser control',
    passed: browserRes.verified,
    message: browserRes.verified ? 'Browser context verified and ready' : 'Browser verification failed',
    durationMs: Date.now() - t14,
  });

  // 15. Take screenshot
  const t15 = Date.now();
  const screenshotRes = await RealToolExecutor.executeTool('take_screenshot', {});
  steps.push({
    id: 'test-15',
    stepNumber: 15,
    title: 'Take screenshot',
    category: 'Screenshot',
    passed: screenshotRes.success && screenshotRes.verified,
    message: screenshotRes.output,
    durationMs: Date.now() - t15,
  });

  // Client-side passed checks for Microphone and Wake Word
  const categorySummary = {
    'Windows API': steps.filter((s) => s.category === 'Windows API').every((s) => s.passed),
    'Process control': steps.filter((s) => s.category === 'Process control').every((s) => s.passed),
    'File system': steps.filter((s) => s.category === 'File system').every((s) => s.passed),
    'Application launch': steps.filter((s) => s.category === 'Application launch').every((s) => s.passed),
    'Application close': steps.filter((s) => s.category === 'Application close').every((s) => s.passed),
    'Browser control': steps.filter((s) => s.category === 'Browser control').every((s) => s.passed),
    'Screenshot': steps.filter((s) => s.category === 'Screenshot').every((s) => s.passed),
    'Microphone': clientMicrophoneOk,
    'Wake word': clientWakeWordOk,
  };

  const overallPassed = Object.values(categorySummary).every(Boolean);

  return {
    timestamp: new Date().toLocaleTimeString(),
    overallPassed,
    bridgeStatus: bridge,
    categorySummary,
    steps,
    tests: steps,
  };
}
