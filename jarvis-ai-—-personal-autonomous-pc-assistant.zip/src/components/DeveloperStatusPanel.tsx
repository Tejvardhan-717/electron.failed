import React, { useState, useEffect } from 'react';
import { voiceService } from '../services/voiceService';
import { DeveloperSessionStatus, ConversationState } from '../types';
import {
  Activity,
  Mic,
  MicOff,
  Radio,
  Timer,
  Play,
  RotateCcw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  X,
  Volume2,
  Terminal,
  Zap,
} from 'lucide-react';

interface DeveloperStatusPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteCommand?: (cmd: string) => void;
}

export const DeveloperStatusPanel: React.FC<DeveloperStatusPanelProps> = ({
  isOpen,
  onClose,
  onExecuteCommand,
}) => {
  const [status, setStatus] = useState<DeveloperSessionStatus>(
    voiceService.getDeveloperStatus()
  );
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    // Initial fetch
    setStatus(voiceService.getDeveloperStatus());

    // Subscribe to developer status stream
    voiceService.onDeveloperStatus((newStatus) => {
      setStatus({ ...newStatus });
    });
  }, []);

  if (!isOpen) return null;

  const isActive = status.sessionStatus === 'ACTIVE';
  const progressPercent = Math.min(
    100,
    Math.round((status.inactivitySeconds / status.inactivityMaxSeconds) * 100)
  );

  const STATE_SEQUENCE: { state: ConversationState; label: string }[] = [
    { state: 'SLEEPING', label: 'SLEEPING' },
    { state: 'WAKE_WORD_DETECTED', label: 'WAKE DETECTED' },
    { state: 'ACTIVATING', label: 'ACTIVATING' },
    { state: 'ACTIVE_CONVERSATION', label: 'ACTIVE SESSION' },
    { state: 'LISTENING', label: 'LISTENING' },
    { state: 'THINKING', label: 'THINKING' },
    { state: 'EXECUTING', label: 'EXECUTING' },
    { state: 'SPEAKING', label: 'SPEAKING' },
  ];

  return (
    <div
      id="developer-session-status-panel"
      className="fixed bottom-24 right-4 sm:right-6 z-40 w-96 max-w-[calc(100vw-2rem)] rounded-2xl bg-[#060b14]/95 backdrop-blur-xl border border-cyan-500/40 shadow-[0_10px_40px_rgba(0,0,0,0.8),0_0_25px_rgba(0,210,255,0.2)] text-slate-200 overflow-hidden font-mono text-xs transition-all duration-300"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#0a1220] border-b border-cyan-500/30">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/40 text-cyan-400">
            <Radio className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-100 tracking-wider">
                DEVELOPER STATUS
              </span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider ${
                  isActive
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-700/40 text-slate-300 border border-slate-600'
                }`}
              >
                {status.sessionStatus}
              </span>
            </div>
            <span className="text-[10px] text-cyan-400/80">
              Persistent Session Engine & Wake-Word
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors"
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronUp className="w-4 h-4" />
            )}
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors"
            title="Close Status Panel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary Status Card - Matches User Exact Spec */}
      <div className="p-4 space-y-3.5">
        {/* 1. MICROPHONE */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/5">
          <span className="text-[11px] uppercase tracking-wider text-slate-400">
            MICROPHONE
          </span>
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                status.microphoneStatus === 'CONNECTED'
                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                  : 'bg-rose-400'
              }`}
            />
            <span
              className={`font-semibold text-xs ${
                status.microphoneStatus === 'CONNECTED'
                  ? 'text-emerald-300'
                  : 'text-rose-300'
              }`}
            >
              {status.microphoneStatus === 'CONNECTED'
                ? 'Connected'
                : status.microphoneStatus === 'PERMISSION_DENIED'
                ? 'Permission Denied'
                : 'Disconnected'}
            </span>
          </div>
        </div>

        {/* 2. WAKE WORD */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/5">
          <span className="text-[11px] uppercase tracking-wider text-slate-400">
            WAKE WORD
          </span>
          <div className="flex items-center gap-1.5">
            {isActive ? (
              <>
                <span className="w-2.5 h-2.5 rounded-full border border-amber-400 text-amber-400 flex items-center justify-center text-[8px]">
                  ○
                </span>
                <span className="text-amber-300/90 font-medium">
                  Temporarily disabled
                </span>
              </>
            ) : (
              <>
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(0,210,255,0.8)]" />
                <span className="text-cyan-300 font-medium">
                  Listening for &ldquo;Jarvis&rdquo;
                </span>
              </>
            )}
          </div>
        </div>

        {/* 3. SESSION */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/5">
          <span className="text-[11px] uppercase tracking-wider text-slate-400">
            SESSION
          </span>
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isActive
                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse'
                  : 'bg-slate-500'
              }`}
            />
            <span
              className={`font-semibold text-xs ${
                isActive ? 'text-emerald-300' : 'text-slate-400'
              }`}
            >
              {isActive ? 'Active conversation' : 'Sleeping'}
            </span>
          </div>
        </div>

        {/* 4. INACTIVITY TIMER */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] uppercase tracking-wider text-slate-400">
              INACTIVITY
            </span>
            <div className="text-right">
              {isActive ? (
                status.isTimerPaused ? (
                  <span className="text-amber-300 font-bold text-[11px] flex items-center gap-1">
                    <Timer className="w-3 h-3 animate-spin" />
                    PAUSED ({status.pauseReason || 'Executing'})
                  </span>
                ) : (
                  <span className="text-cyan-300 font-bold text-xs">
                    {status.inactivitySeconds} / {status.inactivityMaxSeconds} seconds
                  </span>
                )
              ) : (
                <span className="text-slate-500 text-xs">
                  -- / {status.inactivityMaxSeconds} seconds (Sleeping)
                </span>
              )}
            </div>
          </div>

          {/* Progress Countdown Bar */}
          <div className="w-full bg-[#03060c] rounded-full h-2 border border-white/10 overflow-hidden p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                !isActive
                  ? 'bg-slate-700 w-0'
                  : status.isTimerPaused
                  ? 'bg-amber-400 w-full animate-pulse'
                  : progressPercent > 75
                  ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]'
                  : 'bg-gradient-to-r from-emerald-400 via-cyan-400 to-sky-400'
              }`}
              style={{
                width: isActive && !status.isTimerPaused ? `${progressPercent}%` : undefined,
              }}
            />
          </div>
          {isActive && !status.isTimerPaused && (
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Auto-sleep in {Math.max(0, 30 - status.inactivitySeconds)}s</span>
              <span>Resets on speech or command</span>
            </div>
          )}
        </div>

        {/* Collapsible Detailed Diagnostic Sections */}
        {isExpanded && (
          <div className="pt-2 border-t border-white/5 space-y-3 animate-in fade-in duration-150">
            {/* Active State Machine Node */}
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                EXACT STATE MACHINE:
              </span>
              <div className="grid grid-cols-2 gap-1 text-[10px]">
                {STATE_SEQUENCE.map(({ state, label }) => {
                  const isCurrent = status.conversationState === state;
                  return (
                    <div
                      key={state}
                      className={`px-2 py-1 rounded border transition-all truncate text-center ${
                        isCurrent
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold shadow-[0_0_10px_rgba(0,210,255,0.3)]'
                          : 'bg-white/5 border-white/5 text-slate-500'
                      }`}
                    >
                      {label}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Interactive Protocol Test Suite */}
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                9-STEP TEST DISPATCHER:
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => voiceService.triggerWakeWordDetected()}
                  className="px-2 py-1.5 rounded bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold text-left transition-all"
                >
                  1. "Hey Jarvis" (Wake)
                </button>
                <button
                  onClick={() => onExecuteCommand?.('Open Notepad')}
                  className="px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-[10px] text-left transition-all"
                >
                  2. "Open Notepad"
                </button>
                <button
                  onClick={() => onExecuteCommand?.('Type hello world')}
                  className="px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-[10px] text-left transition-all"
                >
                  3. "Type hello world"
                </button>
                <button
                  onClick={() => onExecuteCommand?.('Close Notepad')}
                  className="px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-[10px] text-left transition-all"
                >
                  4. "Close Notepad"
                </button>
                <button
                  onClick={() => onExecuteCommand?.('Open Calculator')}
                  className="px-2 py-1.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold text-left transition-all"
                >
                  5. "Open Calculator" (No wake)
                </button>
                <button
                  onClick={() => voiceService.handleInactivityTimeout()}
                  className="px-2 py-1.5 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] text-left transition-all"
                >
                  6. Fast-forward 30s Timeout
                </button>
                <button
                  onClick={() => onExecuteCommand?.("That's all")}
                  className="px-2 py-1.5 rounded bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-[10px] text-left transition-all"
                >
                  8. "That's all" (Exit)
                </button>
                <button
                  onClick={() => voiceService.resetInactivityTimer()}
                  className="px-2 py-1.5 rounded bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-[10px] text-left transition-all"
                >
                  Reset Timer (0s)
                </button>
              </div>
            </div>

            {/* Interruption / Barge-in trigger */}
            {voiceService.isCurrentlySpeaking() && (
              <button
                onClick={() => voiceService.interrupt()}
                className="w-full py-1.5 rounded-lg bg-rose-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-[0_0_12px_rgba(244,63,94,0.6)] animate-pulse"
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                INTERRUPT JARVIS (Barge-in)
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
