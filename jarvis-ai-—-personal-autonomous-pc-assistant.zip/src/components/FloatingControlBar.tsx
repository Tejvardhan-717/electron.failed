import React from 'react';
import { AccentColor } from '../types';
import {
  Mic,
  MicOff,
  Terminal,
  Layers,
  Brain,
  Settings as SettingsIcon,
  MessageSquare,
  Activity,
  Shield,
  Zap,
} from 'lucide-react';

interface FloatingControlBarProps {
  isListening: boolean;
  onToggleMic: () => void;
  onOpenCommand: () => void;
  onToggleTasks: () => void;
  isTasksOpen: boolean;
  hasActiveTask?: boolean;
  onToggleConversation: () => void;
  isConversationOpen: boolean;
  onToggleHud: () => void;
  isHudOpen: boolean;
  onOpenMemory: () => void;
  onOpenSettings: () => void;
  onOpenDiagnostics?: () => void;
  accentColor?: AccentColor;
}

export const FloatingControlBar: React.FC<FloatingControlBarProps> = ({
  isListening,
  onToggleMic,
  onOpenCommand,
  onToggleTasks,
  isTasksOpen,
  hasActiveTask = false,
  onToggleConversation,
  isConversationOpen,
  onToggleHud,
  isHudOpen,
  onOpenMemory,
  onOpenSettings,
  onOpenDiagnostics,
  accentColor = 'blue',
}) => {
  return (
    <div
      id="jarvis-floating-control-bar"
      className="fixed bottom-6 inset-x-0 z-30 flex justify-center px-4 pointer-events-none"
    >
      <div className="pointer-events-auto p-1.5 sm:p-2 rounded-2xl bg-[#060a12]/85 backdrop-blur-2xl border border-white/10 shadow-[0_10px_40px_rgba(0,0,0,0.7)] flex items-center gap-1 sm:gap-2 transition-all duration-300 hover:border-cyan-500/30">
        {/* MICROPHONE BUTTON */}
        <button
          onClick={onToggleMic}
          title={isListening ? 'Mute Microphone' : 'Activate Voice Listening'}
          className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all ${
            isListening
              ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse shadow-[0_0_20px_rgba(244,63,94,0.6)]'
              : 'bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 shadow-[0_0_12px_rgba(0,210,255,0.2)]'
          }`}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          <span className="hidden md:inline tracking-wider">
            {isListening ? 'LISTENING' : 'MICROPHONE'}
          </span>
        </button>

        {/* COMMAND BUTTON */}
        <button
          onClick={onOpenCommand}
          title="Open Command Input Palette (or press /)"
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold text-slate-300 hover:text-cyan-300 hover:bg-white/5 border border-transparent hover:border-white/10 transition-all"
        >
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline">COMMAND</span>
        </button>

        {/* CONVERSATION TRANSCRIPT BUTTON */}
        <button
          onClick={onToggleConversation}
          title="Toggle Conversation Stream"
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold transition-all ${
            isConversationOpen
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-300 hover:text-cyan-300 hover:bg-white/5 border border-transparent hover:border-white/10'
          }`}
        >
          <MessageSquare className="w-4 h-4 text-cyan-400" />
          <span className="hidden lg:inline">TRANSCRIPTS</span>
        </button>

        {/* TASKS BUTTON */}
        <button
          onClick={onToggleTasks}
          title="Toggle Live Task Panel"
          className={`relative flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold transition-all ${
            isTasksOpen
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-300 hover:text-cyan-300 hover:bg-white/5 border border-transparent hover:border-white/10'
          }`}
        >
          <Layers className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline">TASKS</span>
          {hasActiveTask && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          )}
        </button>

        {/* HOLOGRAPHIC HUD TELEMETRY BUTTON */}
        <button
          onClick={onToggleHud}
          title="Toggle Holographic System Telemetry"
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold transition-all ${
            isHudOpen
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-300 hover:text-cyan-300 hover:bg-white/5 border border-transparent hover:border-white/10'
          }`}
        >
          <Activity className="w-4 h-4 text-cyan-400" />
          <span className="hidden lg:inline">HUD TELEMETRY</span>
        </button>

        {/* MEMORY BUTTON */}
        <button
          onClick={onOpenMemory}
          title="Open Memory Manager"
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold text-slate-300 hover:text-purple-300 hover:bg-purple-500/10 border border-transparent hover:border-purple-500/30 transition-all"
        >
          <Brain className="w-4 h-4 text-purple-400" />
          <span className="hidden sm:inline">MEMORY</span>
        </button>

        {/* DIAGNOSTICS & BRIDGE */}
        {onOpenDiagnostics && (
          <button
            onClick={onOpenDiagnostics}
            title="PC Diagnostics & Windows Bridge"
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-semibold text-slate-300 hover:text-emerald-300 hover:bg-emerald-500/10 border border-transparent hover:border-emerald-500/30 transition-all"
          >
            <Shield className="w-4 h-4 text-emerald-400" />
            <span className="hidden xl:inline">BRIDGE</span>
          </button>
        )}

        {/* SETTINGS BUTTON */}
        <button
          onClick={onOpenSettings}
          title="System Settings"
          className="p-2.5 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-white/10 transition-colors"
        >
          <SettingsIcon className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
