#!/usr/bin/env python3
"""
J.A.R.V.I.S. MARK 85 - Python Windows Bridge Agent
Uses psutil, subprocess, os, and win32 APIs (if available) to execute and verify Windows operations.
"""

import sys
import time
import os
import subprocess
import json
try:
    import urllib.request
    import urllib.parse
except ImportError:
    pass

SERVER_URL = os.environ.get("JARVIS_SERVER_URL", "http://localhost:3000")

def send_post(endpoint, data):
    url = f"{SERVER_URL}{endpoint}"
    req = urllib.request.Request(
        url,
        data=json.dumps(data).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))

def send_get(endpoint):
    url = f"{SERVER_URL}{endpoint}"
    with urllib.request.urlopen(url, timeout=8) as response:
        return json.loads(response.read().decode("utf-8"))

def execute_and_verify(tool_name, params):
    start_time = time.time()
    
    if tool_name == "open_application":
        app = params.get("application") or params.get("appName") or params.get("name", "")
        exe = app.lower()
        if "chrome" in exe:
            exe = "chrome"
        elif "notepad" in exe:
            exe = "notepad"
        elif "calc" in exe:
            exe = "calc"
        elif "code" in exe:
            exe = "code"

        # Execute
        try:
            subprocess.Popen([exe], shell=True)
        except Exception as e:
            return {
                "success": False,
                "verified": False,
                "state": "FAILED",
                "output": f"Failed to execute launch for {app}: {str(e)}"
            }

        # Verify: check running processes
        found_pid = None
        for _ in range(10):
            time.sleep(0.4)
            try:
                # Windows tasklist or ps
                output = subprocess.check_output(f'tasklist /FI "IMAGENAME eq {exe}.exe"', shell=True).decode()
                if f"{exe}.exe" in output.lower():
                    found_pid = True
                    break
            except Exception:
                pass

        if found_pid:
            return {
                "success": True,
                "verified": True,
                "state": "COMPLETED",
                "output": f"Successfully launched {app}. Confirmed running in Windows process table.",
                "durationMs": int((time.time() - start_time) * 1000)
            }
        else:
            return {
                "success": False,
                "verified": False,
                "state": "FAILED",
                "output": f"{app} did not open successfully. I tried to launch it, but Windows did not confirm that it started.",
                "error": "Process verification timeout",
                "durationMs": int((time.time() - start_time) * 1000)
            }

    elif tool_name == "create_folder":
        folder_path = params.get("path") or params.get("folderPath", "Test")
        if "desktop" in folder_path.lower():
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            folder_name = folder_path.lower().replace("desktop", "").replace("on my desktop", "").strip("\\/ ")
            folder_path = os.path.join(desktop, folder_name or "Test")

        os.makedirs(folder_path, exist_ok=True)
        if os.path.isdir(folder_path):
            return {
                "success": True,
                "verified": True,
                "state": "COMPLETED",
                "output": f"Folder created and verified on Windows Desktop: {folder_path}",
                "durationMs": int((time.time() - start_time) * 1000)
            }
        else:
            return {
                "success": False,
                "verified": False,
                "state": "FAILED",
                "output": "The folder could not be created.",
                "durationMs": int((time.time() - start_time) * 1000)
            }

    elif tool_name == "delete_file":
        file_path = params.get("path") or params.get("filePath", "")
        if "desktop" in file_path.lower():
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            name = file_path.lower().replace("desktop", "").strip("\\/ ")
            file_path = os.path.join(desktop, name)

        if not os.path.exists(file_path):
            return {
                "success": False,
                "verified": True,
                "state": "FAILED",
                "output": f"File {file_path} was not found on the filesystem."
            }

        if os.path.isdir(file_path):
            import shutil
            shutil.rmtree(file_path)
        else:
            os.remove(file_path)

        if not os.path.exists(file_path):
            return {
                "success": True,
                "verified": True,
                "state": "COMPLETED",
                "output": f"Successfully deleted {os.path.basename(file_path)}. Verified that it no longer exists on disk."
            }
        else:
            return {
                "success": False,
                "verified": False,
                "state": "FAILED",
                "output": "Failed to delete file. The file still exists on disk."
            }

    return {
        "success": False,
        "verified": False,
        "state": "FAILED",
        "output": f"Tool {tool_name} not implemented in python agent."
    }

def main():
    print("=" * 60)
    print(" J.A.R.V.I.S. PYTHON WINDOWS BRIDGE AGENT v2.0")
    print("=" * 60)
    print(f"Connecting to JARVIS server at {SERVER_URL}...")

    try:
        reg_info = {
            "hostName": os.environ.get("COMPUTERNAME", "PC-Host"),
            "osVersion": sys.platform,
            "username": os.environ.get("USERNAME", "User")
        }
        res = send_post("/api/bridge/register", reg_info)
        print(f"[✓] Connected and registered with Bridge ID: {res.get('bridgeId')}")
    except Exception as e:
        print(f"[!] Warning: Could not reach {SERVER_URL}: {e}")

    print("Listening for verified tool instructions...")
    while True:
        try:
            task = send_get("/api/bridge/poll")
            if task and task.get("id"):
                tool = task.get("toolName")
                params = task.get("params", {})
                print(f"[*] Executing tool: {tool}")
                result = execute_and_verify(tool, params)
                send_post("/api/bridge/complete", {"taskId": task.get("id"), "result": result})
                print(f"[✓] Verified and returned result for {tool}")
        except Exception:
            pass
        time.sleep(1)

if __name__ == "__main__":
    main()
