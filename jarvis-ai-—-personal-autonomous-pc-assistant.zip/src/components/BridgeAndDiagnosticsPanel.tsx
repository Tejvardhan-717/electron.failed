import React, { useState, useEffect } from 'react';
import {
  PcAccessTestReport,
  BridgeStatus,
  WakeWordEngineState,
  MicrophoneStatus,
  DeveloperSessionStatus,
} from '../types';
import { voiceService } from '../services/voiceService';
import {
  Shield,
  CheckCircle2,
  XCircle,
  Loader2,
  Terminal,
  Activity,
  Mic,
  MicOff,
  Cpu,
  FolderCheck,
  Globe,
  Camera,
  Play,
  Copy,
  Check,
  Download,
  AlertTriangle,
  RefreshCw,
  X,
  Volume2,
  Sliders,
  FileCode,
  CheckCheck,
  Search,
  Code,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface BridgeAndDiagnosticsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onRunCommand: (cmd: string) => void;
}

export const BridgeAndDiagnosticsPanel: React.FC<BridgeAndDiagnosticsPanelProps> = ({
  isOpen,
  onClose,
  onRunCommand,
}) => {
  const [activeTab, setActiveTab] = useState<'bridge' | 'diagnostics' | 'wakeword' | 'registry'>('diagnostics');
  const [bridgeStatus, setBridgeStatus] = useState<BridgeStatus>({
    connected: false,
    connectionType: 'sandbox_container',
  });
  const [isPollingBridge, setIsPollingBridge] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedNodeCmd, setCopiedNodeCmd] = useState(false);

  // Tool Registry & Argument Validation State
  const [registeredTools, setRegisteredTools] = useState<any[]>([]);
  const [selectedToolForValidation, setSelectedToolForValidation] = useState<string>('create_folder');
  const [validationInputJson, setValidationInputJson] = useState<string>(
    JSON.stringify({ path: 'Desktop/JarvisWorkspace' }, null, 2)
  );
  const [validationResult, setValidationResult] = useState<any>(null);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [registryFilter, setRegistryFilter] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Diagnostic Report State
  const [report, setReport] = useState<PcAccessTestReport | null>(null);
  const [isRunningTest, setIsRunningTest] = useState(false);

  // Wake-Word & Mic State
  const [engineState, setEngineState] = useState<WakeWordEngineState>(voiceService.getEngineState());
  const [micStatus, setMicStatus] = useState<MicrophoneStatus>(voiceService.getMicrophoneStatus());
  const [volume, setVolume] = useState<number>(voiceService.getCurrentVolume());
  const [threshold, setThreshold] = useState<number>(voiceService.getSensitivityThreshold());
  const [devStatus, setDevStatus] = useState<DeveloperSessionStatus>(voiceService.getDeveloperStatus());

  useEffect(() => {
    if (!isOpen) return;

    // Check bridge status and load registered tools
    fetchBridgeStatus();
    fetchRegisteredTools();
    const bridgeInterval = setInterval(fetchBridgeStatus, 2500);

    // Subscribe to voice service events
    voiceService.onStateChange(setEngineState);
    voiceService.onMicStatus(setMicStatus);
    voiceService.onVolumeChange(setVolume);
    voiceService.onDeveloperStatus(setDevStatus);
    setDevStatus(voiceService.getDeveloperStatus());

    return () => {
      clearInterval(bridgeInterval);
    };
  }, [isOpen]);

  const fetchRegisteredTools = async () => {
    try {
      const res = await fetch('/api/bridge/tools');
      if (res.ok) {
        const data = await res.json();
        setRegisteredTools(data.tools || []);
      }
    } catch {
      // ignore
    }
  };

  const handleTestArgumentValidation = async () => {
    setIsValidating(true);
    try {
      let parsedParams = {};
      try {
        parsedParams = JSON.parse(validationInputJson);
      } catch (e: any) {
        setValidationResult({
          valid: false,
          errors: [`JSON Syntax Error in input parameters: ${e.message}`],
          sanitizedArgs: {},
        });
        setIsValidating(false);
        return;
      }

      const res = await fetch('/api/bridge/tools/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolName: selectedToolForValidation,
          params: parsedParams,
        }),
      });

      if (res.ok) {
        const result = await res.json();
        setValidationResult(result);
      }
    } catch (err: any) {
      setValidationResult({
        valid: false,
        errors: [`Network or server error during validation: ${err.message}`],
      });
    } finally {
      setIsValidating(false);
    }
  };

  const setValidationPreset = (tool: string, payload: Record<string, any>) => {
    setSelectedToolForValidation(tool);
    setValidationInputJson(JSON.stringify(payload, null, 2));
    setValidationResult(null);
  };

  const fetchBridgeStatus = async () => {
    try {
      setIsPollingBridge(true);
      const res = await fetch('/api/bridge/status');
      if (res.ok) {
        const data = await res.json();
        setBridgeStatus(data);
      }
    } catch {
      // ignore
    } finally {
      setIsPollingBridge(false);
    }
  };

  const runFullDiagnostic = async () => {
    setIsRunningTest(true);
    try {
      const micOk = micStatus === 'CONNECTED';
      const wakeWordOk = engineState !== 'IDLE';

      const res = await fetch('/api/diagnostic/run-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ microphoneOk: micOk, wakeWordOk: wakeWordOk }),
      });

      if (res.ok) {
        const data: PcAccessTestReport = await res.json();
        setReport(data);
      }
    } catch (err) {
      console.error('Failed to run diagnostics:', err);
    } finally {
      setIsRunningTest(false);
    }
  };

  const handleTestMic = async () => {
    await voiceService.initMicrophone();
    setMicStatus(voiceService.getMicrophoneStatus());
  };

  const handleTestChime = () => {
    voiceService.playActivationChime();
  };

  const handleSimulateWakeWord = () => {
    voiceService.triggerWakeWordDetected('Hey Jarvis, open Notepad');
  };

  const copyBridgeCommand = () => {
    navigator.clipboard.writeText('powershell -ExecutionPolicy Bypass -File .\\jarvis_bridge.ps1');
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div
      id="jarvis-diagnostics-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200"
    >
      <div className="bg-[#070c14] border border-cyan-500/40 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-[0_0_50px_rgba(0,210,255,0.2)] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#09121f]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-wide text-slate-100 uppercase">
                  JARVIS System Diagnostics & PC Control Bridge
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  VERIFIED HARDWARE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                15-Step Windows Verification Engine & Local Wake-Word Monitor
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-white/5 bg-[#080e18] text-xs font-mono">
          <button
            onClick={() => setActiveTab('diagnostics')}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'diagnostics'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <Activity className="w-4 h-4" />
            15-Step PC Access Diagnostic
          </button>

          <button
            onClick={() => setActiveTab('wakeword')}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'wakeword'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <Mic className="w-4 h-4" />
            Wake-Word & Mic Engine
            <span
              className={`w-2 h-2 rounded-full ${
                micStatus === 'CONNECTED' ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
              }`}
            />
          </button>

          <button
            onClick={() => setActiveTab('bridge')}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'bridge'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Windows Host Bridge
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded ${
                bridgeStatus.connected
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}
            >
              {bridgeStatus.connected ? 'CONNECTED' : 'DISCONNECTED'}
            </span>
          </button>

          <button
            onClick={() => {
              setActiveTab('registry');
              fetchRegisteredTools();
            }}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'registry'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            Tool Registry & Security
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {registeredTools.length || 14} TOOLS
            </span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: 15-STEP DIAGNOSTIC */}
          {activeTab === 'diagnostics' && (
            <div className="space-y-4">
              {/* Diagnostic Run Action Banner */}
              <div className="p-4 rounded-xl bg-[#0d1624] border border-cyan-500/30 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    Windows PC Access & Tool Verification Suite
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Tests real Windows APIs, Process Control, File System, Browser, Screenshot, and Wake Word.
                  </p>
                </div>

                <button
                  onClick={runFullDiagnostic}
                  disabled={isRunningTest}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all disabled:opacity-50 shadow-[0_0_15px_rgba(0,210,255,0.3)]"
                >
                  {isRunningTest ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Executing 15 Verification Steps...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      Run Full PC Diagnostic
                    </>
                  )}
                </button>
              </div>

              {/* Diagnostic Results List */}
              {report ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono px-1">
                    <span className="text-slate-400">
                      Report generated: {report.timestamp}
                    </span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded ${
                        report.overallPassed
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {report.overallPassed ? 'ALL TESTS PASSED' : 'PARTIAL PASS (HOST BRIDGE RECOMMENDED)'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {(report.tests || report.steps || []).map((t, idx) => {
                      const isPassed = t.passed === true || t.status === 'passed';
                      const isFailed = t.passed === false || t.status === 'failed';
                      const messageText = t.message || t.details || t.error || (isPassed ? 'Verified OK' : 'Check failed');

                      return (
                        <div
                          key={t.id || `diag-${idx}`}
                          className={`p-3 rounded-xl border text-xs font-mono flex items-start justify-between gap-3 ${
                            isPassed
                              ? 'bg-emerald-950/15 border-emerald-500/30 text-slate-200'
                              : isFailed
                              ? 'bg-rose-950/20 border-rose-500/30 text-slate-200'
                              : 'bg-slate-900/50 border-white/10 text-slate-400'
                          }`}
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-cyan-300">
                                #{t.stepNumber || idx + 1} {t.category}
                              </span>
                              {t.durationMs !== undefined && (
                                <span className="text-[10px] text-slate-400">
                                  {t.durationMs}ms
                                </span>
                              )}
                            </div>
                            <div className="font-semibold text-slate-100 mt-1 truncate">
                              {t.title}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5 break-words">
                              {messageText}
                            </div>
                          </div>

                          <div className="shrink-0 pt-0.5">
                            {isPassed && (
                              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                            )}
                            {isFailed && (
                              <XCircle className="w-5 h-5 text-rose-400" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-10 rounded-2xl bg-[#09111c] border border-white/5 text-center flex flex-col items-center">
                  <Activity className="w-12 h-12 text-cyan-400/40 mb-3 animate-pulse" />
                  <h4 className="text-sm font-semibold text-slate-200">
                    No Diagnostic Report Generated Yet
                  </h4>
                  <p className="text-xs text-slate-400 max-w-sm mt-1 mb-4">
                    Click &ldquo;Run Full PC Diagnostic&rdquo; to execute the 15-step native Windows verification suite.
                  </p>
                  <button
                    onClick={runFullDiagnostic}
                    disabled={isRunningTest}
                    className="px-4 py-2 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono text-xs hover:bg-cyan-500/30 transition-all flex items-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5" /> Start 15-Step Test
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: WAKE-WORD & MICROPHONE ENGINE */}
          {activeTab === 'wakeword' && (
            <div className="space-y-6">
              {/* Developer Status Panel Card (User Specification) */}
              <div className="p-5 rounded-2xl bg-[#070e1a] border border-cyan-500/40 shadow-[0_0_25px_rgba(0,210,255,0.15)] font-mono">
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-cyan-500/30">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
                    <span className="font-bold text-slate-100 text-sm tracking-wider">
                      DEVELOPER STATUS: PERSISTENT SESSION
                    </span>
                  </div>
                  <span
                    className={`text-xs px-2 py-0.5 rounded font-bold uppercase ${
                      devStatus.sessionStatus === 'ACTIVE'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-700/40 text-slate-300 border border-slate-600'
                    }`}
                  >
                    {devStatus.sessionStatus}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  {/* MICROPHONE */}
                  <div className="p-3 rounded-xl bg-[#03060c] border border-white/10">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                      MICROPHONE
                    </span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          devStatus.microphoneStatus === 'CONNECTED'
                            ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                            : 'bg-rose-400'
                        }`}
                      />
                      <span
                        className={`font-semibold text-xs ${
                          devStatus.microphoneStatus === 'CONNECTED'
                            ? 'text-emerald-300'
                            : 'text-rose-300'
                        }`}
                      >
                        {devStatus.microphoneStatus === 'CONNECTED'
                          ? 'Connected'
                          : devStatus.microphoneStatus === 'PERMISSION_DENIED'
                          ? 'Permission Denied'
                          : 'Disconnected'}
                      </span>
                    </div>
                  </div>

                  {/* WAKE WORD */}
                  <div className="p-3 rounded-xl bg-[#03060c] border border-white/10">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                      WAKE WORD
                    </span>
                    <div className="flex items-center gap-2">
                      {devStatus.sessionStatus === 'ACTIVE' ? (
                        <>
                          <span className="w-2.5 h-2.5 rounded-full border border-amber-400 text-amber-400 flex items-center justify-center text-[8px]">
                            ○
                          </span>
                          <span className="text-amber-300 font-medium text-xs">
                            Temporarily disabled
                          </span>
                        </>
                      ) : (
                        <>
                          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(0,210,255,0.8)]" />
                          <span className="text-cyan-300 font-medium text-xs">
                            Listening for &ldquo;Jarvis&rdquo;
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* SESSION */}
                  <div className="p-3 rounded-xl bg-[#03060c] border border-white/10">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                      SESSION
                    </span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          devStatus.sessionStatus === 'ACTIVE'
                            ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse'
                            : 'bg-slate-500'
                        }`}
                      />
                      <span
                        className={`font-semibold text-xs ${
                          devStatus.sessionStatus === 'ACTIVE'
                            ? 'text-emerald-300'
                            : 'text-slate-400'
                        }`}
                      >
                        {devStatus.sessionStatus === 'ACTIVE'
                          ? 'Active conversation'
                          : 'Sleeping'}
                      </span>
                    </div>
                  </div>

                  {/* INACTIVITY */}
                  <div className="p-3 rounded-xl bg-[#03060c] border border-white/10">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1.5">
                      INACTIVITY
                    </span>
                    <div className="text-xs font-bold">
                      {devStatus.sessionStatus === 'ACTIVE' ? (
                        devStatus.isTimerPaused ? (
                          <span className="text-amber-300">
                            PAUSED ({devStatus.pauseReason || 'Task Running'})
                          </span>
                        ) : (
                          <span className="text-cyan-300">
                            {devStatus.inactivitySeconds} / {devStatus.inactivityMaxSeconds} seconds
                          </span>
                        )
                      ) : (
                        <span className="text-slate-500">
                          -- / {devStatus.inactivityMaxSeconds}s (Sleeping)
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* State Progression Bar */}
                <div className="mb-4">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-2">
                    STATE MACHINE FLOW:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-1.5 text-center text-[10px]">
                    {[
                      { state: 'SLEEPING', label: '1. SLEEP' },
                      { state: 'WAKE_WORD_DETECTED', label: '2. WAKE DET' },
                      { state: 'ACTIVATING', label: '3. ACTIVATE' },
                      { state: 'ACTIVE_CONVERSATION', label: '4. ACTIVE' },
                      { state: 'LISTENING', label: '5. LISTEN' },
                      { state: 'THINKING', label: '6. THINK' },
                      { state: 'EXECUTING', label: '7. EXECUTE' },
                      { state: 'SPEAKING', label: '8. SPEAK' },
                    ].map((item) => {
                      const isActive = devStatus.conversationState === item.state;
                      return (
                        <div
                          key={item.state}
                          className={`p-2 rounded-lg border transition-all truncate ${
                            isActive
                              ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-bold shadow-[0_0_12px_rgba(0,210,255,0.4)]'
                              : 'bg-white/5 border-white/5 text-slate-500'
                          }`}
                        >
                          {item.label}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
                  <button
                    onClick={() => voiceService.triggerWakeWordDetected()}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-semibold"
                  >
                    Simulate "Hey Jarvis"
                  </button>
                  <button
                    onClick={() => voiceService.handleExplicitExit("That's all")}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-semibold"
                  >
                    Simulate "That's all"
                  </button>
                  <button
                    onClick={() => voiceService.handleInactivityTimeout()}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-semibold"
                  >
                    Force 30s Timeout
                  </button>
                  <button
                    onClick={() => voiceService.resetInactivityTimer()}
                    className="px-3 py-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-300 text-xs font-semibold"
                  >
                    Reset Timer
                  </button>
                </div>
              </div>

              {/* Microphone Hardware & Live Volume Bar */}
              <div className="p-4 rounded-xl bg-[#09111c] border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-300">Microphone Status:</span>
                    <span
                      className={`text-xs font-mono px-2 py-0.5 rounded font-bold ${
                        micStatus === 'CONNECTED'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : micStatus === 'PERMISSION_DENIED'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {micStatus}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleTestMic}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                    >
                      <Mic className="w-3.5 h-3.5" />
                      Test Microphone
                    </button>
                    <button
                      onClick={handleTestChime}
                      className="px-3 py-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      Play Activation Chime
                    </button>
                    <button
                      onClick={handleSimulateWakeWord}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                    >
                      <Play className="w-3.5 h-3.5" />
                      Test Wake Trigger
                    </button>
                  </div>
                </div>

                {/* Real-time Level Meter */}
                <div>
                  <div className="flex justify-between text-xs font-mono text-slate-400 mb-1.5">
                    <span>LIVE INPUT AUDIO LEVEL:</span>
                    <span className="text-cyan-400 font-bold">{volume}%</span>
                  </div>
                  <div className="w-full bg-[#05080e] rounded-full h-3 p-0.5 border border-white/10 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-75 ${
                        volume > threshold
                          ? 'bg-gradient-to-r from-emerald-500 via-cyan-400 to-sky-400 shadow-[0_0_10px_rgba(0,210,255,0.5)]'
                          : 'bg-slate-600'
                      }`}
                      style={{ width: `${Math.min(100, volume)}%` }}
                    />
                  </div>
                </div>

                {/* Sensitivity Slider */}
                <div className="pt-2">
                  <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                    <span className="flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5" /> Detection Threshold:
                    </span>
                    <span className="text-cyan-300 font-bold">{threshold}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="80"
                    value={threshold}
                    onChange={(e) => {
                      const val = parseInt(e.target.value, 10);
                      setThreshold(val);
                      voiceService.setSensitivityThreshold(val);
                    }}
                    className="w-full accent-cyan-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: WINDOWS HOST BRIDGE */}
          {activeTab === 'bridge' && (
            <div className="space-y-6">
              {/* Host Status Card */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  bridgeStatus.connected
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                    : 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2.5 rounded-lg border ${
                      bridgeStatus.connected
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                    }`}
                  >
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold">
                      {bridgeStatus.connected
                        ? `Connected to Host: ${bridgeStatus.hostName}`
                        : 'Windows Host Bridge Not Connected'}
                    </h3>
                    <p className="text-xs opacity-80 mt-0.5">
                      {bridgeStatus.connected
                        ? `OS: ${bridgeStatus.osVersion || 'Windows'} | User: ${bridgeStatus.username || 'Host'} | Latency: ${bridgeStatus.latencyMs || 25}ms`
                        : 'Run jarvis_bridge.ps1 on your Windows machine to allow real host PC automation.'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={fetchBridgeStatus}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
                  title="Refresh Status"
                >
                  <RefreshCw className={`w-4 h-4 ${isPollingBridge ? 'animate-spin' : ''}`} />
                </button>
              </div>

              {/* Instructions on how to run */}
              <div className="p-5 rounded-xl bg-[#09111c] border border-white/10 space-y-4">
                <h4 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                  QUICK CONNECT GUIDE:
                </h4>

                <ol className="text-xs text-slate-300 space-y-3 list-decimal list-inside font-mono">
                  <li>
                    Download the companion bridge service onto your Windows machine or Electron app:
                    <div className="flex flex-wrap items-center gap-2 mt-2 ml-4">
                      <a
                        href="/api/bridge/download/node"
                        download="jarvis_bridge.js"
                        className="px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download jarvis_bridge.js (Node.js Service)
                      </a>
                      <a
                        href="/api/bridge/download/ps1"
                        download="jarvis_bridge.ps1"
                        className="px-3 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download jarvis_bridge.ps1 (PowerShell)
                      </a>
                      <a
                        href="/api/bridge/download/py"
                        download="jarvis_agent.py"
                        className="px-3 py-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-mono flex items-center gap-1.5 transition-all"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download jarvis_agent.py (Python)
                      </a>
                    </div>
                  </li>
                  <li>
                    Run the Node.js Bridge Service on your Windows computer:
                    <div className="mt-2 ml-4 p-3 rounded-lg bg-black/60 border border-white/10 flex items-center justify-between">
                      <code className="text-emerald-300">
                        node jarvis_bridge.js
                      </code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText('node jarvis_bridge.js');
                          setCopiedNodeCmd(true);
                          setTimeout(() => setCopiedNodeCmd(false), 2000);
                        }}
                        className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-slate-200 text-xs flex items-center gap-1 transition-colors"
                      >
                        {copiedNodeCmd ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> Copy
                          </>
                        )}
                      </button>
                    </div>
                  </li>
                  <li>
                    Or run PowerShell if Node.js is not installed on host:
                    <div className="mt-2 ml-4 p-3 rounded-lg bg-black/60 border border-white/10 flex items-center justify-between">
                      <code className="text-cyan-300">
                        powershell -ExecutionPolicy Bypass -File .\jarvis_bridge.ps1
                      </code>
                      <button
                        onClick={copyBridgeCommand}
                        className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-slate-200 text-xs flex items-center gap-1 transition-colors"
                      >
                        {copiedCmd ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> Copy
                          </>
                        )}
                      </button>
                    </div>
                  </li>
                  <li>
                    The bridge will authenticate, register your Windows OS APIs, and execute all verified commands with multi-step hardware confirmation!
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 4: TOOL REGISTRY & ARGUMENT VALIDATION */}
          {activeTab === 'registry' && (
            <div className="space-y-6">
              {/* Architecture & Registry Overview Banner */}
              <div className="p-4 rounded-xl bg-[#0c1626] border border-cyan-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-cyan-400" />
                    <h3 className="text-sm font-bold text-slate-100">
                      Windows Tool Registry & Security Engine
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                    Centralized registry defining strongly-typed schemas, path traversal guards,
                    risk level classifications (Levels 0–4), and execution verification for all Windows OS tools.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-right">
                    <span className="text-[10px] text-slate-400 block font-mono">REGISTERED TOOLS</span>
                    <span className="text-sm font-mono font-bold text-cyan-300">
                      {registeredTools.length} Active
                    </span>
                  </div>
                  <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-right">
                    <span className="text-[10px] text-slate-400 block font-mono">VALIDATION ENGINE</span>
                    <span className="text-sm font-mono font-bold text-emerald-400">
                      Strict Schema
                    </span>
                  </div>
                </div>
              </div>

              {/* Interactive Split View: Left = Argument Validation Console, Right = Registered Tools Catalog */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Argument Validation Console */}
                <div className="lg:col-span-5 space-y-4">
                  <div className="p-4 rounded-xl bg-[#09111c] border border-white/10 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Code className="w-4 h-4 text-cyan-400" />
                        <h4 className="text-xs font-mono font-bold text-slate-200 uppercase">
                          Live Argument Validator
                        </h4>
                      </div>
                      <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                        POST /api/bridge/tools/validate
                      </span>
                    </div>

                    {/* Tool Selector */}
                    <div>
                      <label className="text-[11px] font-mono text-slate-400 block mb-1">
                        Select Target Tool:
                      </label>
                      <select
                        value={selectedToolForValidation}
                        onChange={(e) => {
                          const tName = e.target.value;
                          setSelectedToolForValidation(tName);
                          const t = registeredTools.find((item) => item.name === tName);
                          if (t) {
                            const sample: Record<string, any> = {};
                            t.parameters.forEach((p: any) => {
                              sample[p.name] = p.defaultValue !== undefined ? p.defaultValue : p.type === 'number' ? 0 : p.type === 'boolean' ? false : 'sample_value';
                            });
                            setValidationInputJson(JSON.stringify(sample, null, 2));
                            setValidationResult(null);
                          }
                        }}
                        className="w-full px-3 py-2 rounded-lg bg-black/60 border border-white/15 text-slate-200 text-xs font-mono focus:outline-none focus:border-cyan-500"
                      >
                        {registeredTools.map((t) => (
                          <option key={t.name} value={t.name}>
                            {t.name} (Risk Level {t.riskLevel})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Quick Security & Traversal Test Presets */}
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 block mb-1.5">
                        Test Scenarios & Security Attacks:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          onClick={() =>
                            setValidationPreset('create_folder', { path: 'Desktop/JarvisWorkspace' })
                          }
                          className="px-2 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-[10px] font-mono transition-all"
                        >
                          ✓ Valid Folder
                        </button>
                        <button
                          onClick={() =>
                            setValidationPreset('create_folder', { path: '../../windows/system32/config/sam' })
                          }
                          className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] font-mono transition-all"
                        >
                          ⚠ Path Traversal Attack
                        </button>
                        <button
                          onClick={() => setValidationPreset('create_folder', {})}
                          className="px-2 py-1 rounded bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-[10px] font-mono transition-all"
                        >
                          ⚠ Missing Param
                        </button>
                        <button
                          onClick={() =>
                            setValidationPreset('open_url', { url: 'https://youtube.com' })
                          }
                          className="px-2 py-1 rounded bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-[10px] font-mono transition-all"
                        >
                          ✓ Valid URL
                        </button>
                        <button
                          onClick={() =>
                            setValidationPreset('open_url', { url: 'javascript:alert(1)' })
                          }
                          className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] font-mono transition-all"
                        >
                          ⚠ Malicious Protocol
                        </button>
                        <button
                          onClick={() =>
                            setValidationPreset('run_powershell', { command: 'Remove-Item -Recurse C:\\Windows' })
                          }
                          className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] font-mono transition-all"
                        >
                          ⚠ Shell Injection
                        </button>
                      </div>
                    </div>

                    {/* JSON Input */}
                    <div>
                      <label className="text-[11px] font-mono text-slate-400 block mb-1">
                        Input Parameters (JSON):
                      </label>
                      <textarea
                        value={validationInputJson}
                        onChange={(e) => setValidationInputJson(e.target.value)}
                        rows={6}
                        className="w-full px-3 py-2 rounded-lg bg-black/60 border border-white/15 text-slate-200 text-xs font-mono focus:outline-none focus:border-cyan-500"
                        spellCheck={false}
                      />
                    </div>

                    {/* Validate Action Button */}
                    <button
                      onClick={handleTestArgumentValidation}
                      disabled={isValidating}
                      className="w-full py-2 px-4 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                    >
                      {isValidating ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Validating Schema & Paths...
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="w-4 h-4" />
                          Validate Tool Arguments
                        </>
                      )}
                    </button>

                    {/* Validation Results Display */}
                    {validationResult && (
                      <div
                        className={`p-3.5 rounded-lg border text-xs font-mono space-y-2 ${
                          validationResult.valid
                            ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                            : 'bg-rose-950/20 border-rose-500/40 text-rose-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold flex items-center gap-1.5">
                            {validationResult.valid ? (
                              <>
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                VALIDATION PASSED
                              </>
                            ) : (
                              <>
                                <XCircle className="w-4 h-4 text-rose-400" />
                                SECURITY / SCHEMA VIOLATION
                              </>
                            )}
                          </span>
                        </div>

                        {/* Error details if invalid */}
                        {!validationResult.valid && validationResult.errors && (
                          <div className="space-y-1 pt-1 border-t border-rose-500/20">
                            {validationResult.errors.map((err: string, idx: number) => (
                              <div key={idx} className="text-[11px] text-rose-200">
                                • {err}
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Sanitized arguments output if valid */}
                        {validationResult.valid && (
                          <div className="pt-1 border-t border-emerald-500/20">
                            <span className="text-[10px] text-slate-400 block mb-1">
                              Sanitized & Normalized Arguments:
                            </span>
                            <pre className="p-2 rounded bg-black/60 text-[11px] text-emerald-300 overflow-x-auto">
                              {JSON.stringify(validationResult.sanitizedArgs, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Registered Tools Catalog */}
                <div className="lg:col-span-7 space-y-4">
                  {/* Search and Category Filters */}
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="relative flex-1 w-full">
                      <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search registered tools..."
                        value={registryFilter}
                        onChange={(e) => setRegistryFilter(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#09111c] border border-white/10 text-slate-200 text-xs font-mono focus:outline-none focus:border-cyan-500"
                      />
                    </div>

                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="w-full sm:w-44 px-3 py-2 rounded-lg bg-[#09111c] border border-white/10 text-slate-200 text-xs font-mono focus:outline-none focus:border-cyan-500"
                    >
                      <option value="all">All Categories</option>
                      <option value="system">system</option>
                      <option value="filesystem">filesystem</option>
                      <option value="automation">automation</option>
                      <option value="browser">browser</option>
                      <option value="telemetry">telemetry</option>
                      <option value="software">software</option>
                      <option value="power">power</option>
                    </select>
                  </div>

                  {/* Tool Cards List */}
                  <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                    {registeredTools
                      .filter((tool) => {
                        const matchesCategory = categoryFilter === 'all' || tool.category === categoryFilter;
                        const matchesSearch =
                          !registryFilter ||
                          tool.name.toLowerCase().includes(registryFilter.toLowerCase()) ||
                          tool.description.toLowerCase().includes(registryFilter.toLowerCase());
                        return matchesCategory && matchesSearch;
                      })
                      .map((tool) => {
                        const riskBadge =
                          tool.riskLevel === 0
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : tool.riskLevel === 1
                            ? 'bg-sky-500/15 text-sky-400 border-sky-500/30'
                            : tool.riskLevel === 2
                            ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                            : tool.riskLevel === 3
                            ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                            : 'bg-red-950 text-red-500 border-red-500/50';

                        return (
                          <div
                            key={tool.name}
                            className="p-4 rounded-xl bg-[#09111c] border border-white/10 hover:border-cyan-500/30 transition-all space-y-3"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-sm font-mono font-bold text-slate-100">
                                    {tool.name}
                                  </span>
                                  <span
                                    className={`text-[9px] px-2 py-0.5 rounded border font-mono uppercase ${riskBadge}`}
                                  >
                                    Level {tool.riskLevel}
                                  </span>
                                  <span className="text-[9px] px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 font-mono uppercase">
                                    {tool.category}
                                  </span>
                                  {tool.requiresAdmin && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                                      Admin
                                    </span>
                                  )}
                                  {tool.undoSupported && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40 font-mono">
                                      Reversible
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-slate-400 mt-1">
                                  {tool.description}
                                </p>
                              </div>

                              <button
                                onClick={() => {
                                  setSelectedToolForValidation(tool.name);
                                  const sample: Record<string, any> = {};
                                  tool.parameters.forEach((p: any) => {
                                    sample[p.name] = p.defaultValue !== undefined ? p.defaultValue : p.type === 'number' ? 0 : p.type === 'boolean' ? false : 'sample_value';
                                  });
                                  setValidationInputJson(JSON.stringify(sample, null, 2));
                                  setValidationResult(null);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-mono flex items-center gap-1 transition-all"
                              >
                                Test
                              </button>
                            </div>

                            {/* Parameter Schema Table */}
                            {tool.parameters && tool.parameters.length > 0 && (
                              <div className="pt-2 border-t border-white/5">
                                <span className="text-[10px] font-mono text-slate-400 block mb-1">
                                  PARAMETER SCHEMA:
                                </span>
                                <div className="overflow-x-auto">
                                  <table className="w-full text-left text-[11px] font-mono">
                                    <thead>
                                      <tr className="text-slate-500 border-b border-white/5">
                                        <th className="pb-1">Name</th>
                                        <th className="pb-1">Type</th>
                                        <th className="pb-1">Required</th>
                                        <th className="pb-1">Details & Guard</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-white/5">
                                      {tool.parameters.map((p: any) => (
                                        <tr key={p.name} className="text-slate-300">
                                          <td className="py-1 font-semibold text-cyan-300">
                                            {p.name}
                                          </td>
                                          <td className="py-1 text-slate-400">{p.type}</td>
                                          <td className="py-1">
                                            {p.required ? (
                                              <span className="text-rose-400 font-bold">Yes</span>
                                            ) : (
                                              <span className="text-slate-500">No</span>
                                            )}
                                          </td>
                                          <td className="py-1 text-slate-400">
                                            {p.description}
                                            {p.sanitizePath && (
                                              <span className="ml-1 text-[9px] text-amber-400 bg-amber-500/10 px-1 py-0.5 rounded border border-amber-500/30">
                                                Path Traversal Guard
                                              </span>
                                            )}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-white/10 bg-[#09121f] flex items-center justify-between text-xs font-mono text-slate-400">
          <span>JARVIS HOST INTERFACE v3.2 — AUTONOMOUS WITH STRICT VERIFICATION</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
